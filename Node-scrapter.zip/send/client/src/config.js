const config = {
  serverUrl: 'http://localhost:8080',
  googleMapApiKey:"AIzaSyD_D-qlxBqeXuIakps7rOsEVGZPYP3n3IM&libraries=places"
};
module.exports = config;