import React, { useState } from "react";
import Page from "./Page";
import Axios from "axios";
import { ToastContainer, toast } from 'react-toastify'
function HomeGuest() {
  const [itemURL, setItemURL] = useState();
  const [name, setName] = useState();
  const [username, setUsername] = useState();
  const [email, setEmail] = useState();
  const [password1, setPassword1] = useState();
  const [password2, setPassword2] = useState();

  async function handleSubmit(e) {
    e.preventDefault();
    //alert("hello");
    try {
      await Axios.post("/users/register", {
        name,
        username,
        email,
        password1,
        password2
        //location: "Dublin, Ireland",
        //picture: "This is a picture of me"
      });
      toast.success('User was successfully registered.', {
        position: toast.POSITION.TOP_RIGHT,
      })
      console.log("User was successfully created.");
    } catch (e) {
      toast.error('Register was failed.', {
        position: toast.POSITION.TOP_RIGHT,
      })
      //console.log(e.response.data);
      console.log(e.response.data);
    }
  }

  return (
    <Page title="Welcome!" wide={true}>
       <ToastContainer autoClose={3000} />
      <div className="row align-items-center">
        <div className="col-lg-7 py-3 py-md-5">
          <h1 className="display-4">Log in to add items to a list</h1>
          <p className="lead text-muted">Details here...</p>
        </div>
        <div className="col-lg-5 pl-lg-5 pb-3 py-lg-5">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="username-register" className="text-muted mb-1">
                <small>Name</small>
              </label>              
              <input
                onChange={(e) => setName(e.target.value)}
                id="name-register"
                name="name"                
                type="text"
                className="form-control"
                placeholder="Your full name"
                autoComplete="off"
              />
            </div>
            <div className="form-group">
              <label htmlFor="username-register" className="text-muted mb-1">
                <small>Username</small>
              </label>
              <input
                onChange={(e) => setUsername(e.target.value)}
                id="username-register"
                name="username"
                className="form-control"
                type="text"
                placeholder="Pick a username"
                autoComplete="off"
              />
            </div>
            <div className="form-group">
              <label htmlFor="email-register" className="text-muted mb-1">
                <small>Email</small>
              </label>
              <input
                onChange={(e) => setEmail(e.target.value)}
                id="email-register"
                name="email"
                className="form-control"
                type="text"
                placeholder="you@example.com"
                autoComplete="off"
              />
            </div>
            <div className="form-group">
              <label htmlFor="password-register" className="text-muted mb-1">
                <small>Password</small>
              </label>
              <input
                onChange={(e) => setPassword1(e.target.value)}
                id="password-register"
                name="password1"
                className="form-control"
                type="password"
                placeholder="Create a password"
              />
            </div>
            <div className="form-group">
              <label htmlFor="password-register" className="text-muted mb-1">
                <small>Password</small>
              </label>
              <input
                onChange={(e) => setPassword2(e.target.value)}
                id="password-register"
                name="password2"
                className="form-control"
                type="password"
                placeholder="Confirm your password"
              />
            </div>
            <button
              type="submit"
              className="py-3 mt-4 btn btn-lg btn-success btn-block"
            >
              Sign up
            </button>
          </form>
        </div>
      </div>
    </Page>
  );
}

export default HomeGuest;
