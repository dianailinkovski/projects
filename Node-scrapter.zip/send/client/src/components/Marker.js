import React from 'react';
import markerPng from "../img/pin1.png";
class Marker extends React.Component {
  constructor(props) {
    super(props); 
  } 
 
  render() { 

    return (    
          <div style={{position:'relative'}}>           
           <img style={{
             position: 'absolute',
           top: '-46px',
           left: '-15px'}} src={markerPng}></img>            
          </div>
      
    );
  }
}

export default Marker
 

