import React, { useEffect, useContext } from "react";
import Page from "./Page";
import StateContext from "../StateContext";

function Home() {
  const appState = useContext(StateContext);

  return (
    <Page title="My Home">
      <h2 className="text-center">
        Hello <strong>{appState.user.username}</strong>, you've nothing going
        on'.
      </h2>
      <p className="lead text-muted text-center">Home needs to be populated</p>
    </Page>
  );
}

export default Home;
