import React, { useContext, useState } from "react";
import { Button } from "react-bootstrap";
import StateContext from "../StateContext";
import Axios from "axios";

function AddButton(props) {
  const appState = useContext(StateContext);
  const currentname = appState.user.username;
  const token = appState.user.token
  let { userid, name, username, email } = props.friendInfo;
  const [isFriend, setIsFriend] = useState();

  async function addPerson(e) {
    e.preventDefault();
    console.log("Add button clicked for " + username);

    //alert("hello");

    try {
      await Axios.put("/users/friends/" + currentname, {
        userid,
        name,
        username,
        email
      }, {
          headers: {
            Authorization: token,
            'Content-Type': 'application/json'
          }
        });
      console.log(
        "New User FRIEND was successfully created for " + currentname
      );
      console.log("isFriend = " + appState.isFriend);
      window.location.reload(false);
    } catch (e) {
      //console.log(e.response.data);
      console.log(e);
    }
  }

  return (
    <div>
      <Button variant="success" className="addButton" onClick={addPerson}>
        Add
      </Button>{" "}
    </div>
  );
}

export default AddButton;
