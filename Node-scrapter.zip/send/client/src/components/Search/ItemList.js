import React, { useEffect, useState } from "react";
import Axios from "axios";
import { Link, useRouteMatch } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";

import Page from "../Page";
import BootstrapTable from "react-bootstrap-table-next";
function ItemList() {
  const [datalist, setDatalist] = useState([]);
  const [rawData, setRawData] = useState([]);
  const [userList, setUserList] = useState([]);
  const [searchTxt, setSearchTxt] = useState("");

  const match = useRouteMatch();
  const columns = [
    {
      dataField: "_id",
      hidden: true,
    },

    {
      dataField: "userName",
      text: "User Name",
      sort: true,
    },
    {
      dataField: "itemName",
      text: "Item Name",
      sort: true,
    },
    {
      dataField: "itemBrand",
      text: "Item Brand",
      sort: true,
    },
    {
      dataField: "itemPicture",
      text: "Item Picture",
      style: { textAlign: "center" },
      formatter: (cell, row) => {
        return (
          <img
            src={row.itemPicture}
            style={{ width: "80px", height: "auto" }}
          ></img>
        );
      },
    },
    {
      dataField: "itemPrice",
      text: "Item Price",
      sort: true,
    },
    {
      dataField: "supplierEmail",
      text: "Supplier Email",
      sort: true,
    },
    {
      dataField: "supplierPhoneNo",
      text: "Supplier Phone",
      sort: true,
    },
    {
      dataField: "sid",
      hidden: true,
      sort: true,
    },
    {
      dataField: "",
      text: "Action",

      formatter: (cell, row) => {
        return (
          <Link to={`/edit-item/${row._id}`}>
            <button
              className="btn  btn-success"
              onClick={(cell) => {
                // console.log(row)
              }}
            >
              Show
            </button>
          </Link>
        );
      },
    },
  ];
  useEffect(() => {
    async function getLists(users) {
      try {
        Axios.defaults.headers.get["Authorization"] = localStorage.getItem(
          "mfcToken"
        );
        const response = await Axios.get("/items/itemlist").then((res) => {
          var rows = [];
          setRawData(res.data.data);
          res.data.data.map((row, index) => {
            if (searchTxt == "") {
              return;
            }

            var temp = {};
            temp._id = row._id;
            temp.itemPrice = row.itemPrice;
            temp.itemName = row.itemName;
            temp.itemBrand = row.itemBrand;
            temp.itemPicture = row.itemPicture;
            temp.itemDescription = row.itemDescription;
            users.map((user, index) => {
              if (user._id == row.userId) {
                temp.userName = user.username;
              }
            });
            temp.supplierName = row.supplier[0].supplierName;
            temp.supplierEmail = row.supplier[0].supplierEmail;
            temp.supplierPhoneNo = row.supplier[0].supplierPhoneNo;
            temp.sid = row.supplier[0]._id;
            rows.push(temp);
          });
          //  console.log(rows,'tttt');
          setDatalist(rows);
        });
      } catch (error) {
        console.log(error.response, "err");
        var err_txt = "";
        if (error.response == undefined) {
          err_txt = "Internal Server error!";
        } else {
          err_txt = error.response.data.msg;
        }
        toast.error(error.response.data.msg, {
          position: toast.POSITION.TOP_RIGHT,
        });
      }
    }
    async function getUserLists() {
      try {
        Axios.defaults.headers.get["Authorization"] = localStorage.getItem(
          "mfcToken"
        );
        const response = await Axios.get("/users").then((res) => {
          setUserList(res.data.data);
          getLists(res.data.data);
        });
      } catch (error) {
        console.log(error.response, "err");
        var err_txt = "";
        if (error.response == undefined) {
          err_txt = "Internal Server error!";
        } else {
          err_txt = error.response.data.msg;
        }
        toast.error(error.response.data.msg, {
          position: toast.POSITION.TOP_RIGHT,
        });
      }
    }
    getUserLists();
  }, []);
  async function searchUser(e) {
    setSearchTxt(e.target.value);
    var rows = [];
    var userIds = [];
    userList.map((user, index) => {
      if (user.username.includes(e.target.value)) {
        userIds.push(user._id);
      }
    });
    rawData.map((row, index) => {
      if (userIds.indexOf(row.userId) == -1 || e.target.value == "") {
        return;
      }

      var temp = {};
      temp._id = row._id;
      temp.itemPrice = row.itemPrice;
      temp.itemName = row.itemName;
      temp.itemBrand = row.itemBrand;
      temp.itemPicture = row.itemPicture;
      temp.itemDescription = row.itemDescription;
      userList.map((user, index) => {
        if (user._id == row.userId) {
          temp.userName = user.username;
        }
      });
      temp.supplierName = row.supplier[0].supplierName;
      temp.supplierEmail = row.supplier[0].supplierEmail;
      temp.supplierPhoneNo = row.supplier[0].supplierPhoneNo;
      temp.sid = row.supplier[0]._id;
      rows.push(temp);
    });
    //  console.log(rows,'tttt');
    setDatalist(rows);
  }
  return (
    <Page title="Item List">
      <ToastContainer autoClose={3000} />
      <div className="row" style={{ marginBottom: "15px" }}>
        <div className="col-md-9 text-right">
          <label className="control-label">
            Search By User Name:<span className="symbol required"></span>
          </label>
        </div>
        <div className="col-md-3 text-right">
          <input
            type="text"
            className="form-control"
            value={searchTxt}
            onChange={(event) => {
              searchUser(event);
            }}
            placeholder="Search text"
          ></input>
        </div>
      </div>

      <BootstrapTable keyField="_id" data={datalist} columns={columns} />
      {datalist.length == 0 ? (
        <p style={{ textAlign: "center" }}>There is nothing!</p>
      ) : (
        ""
      )}
    </Page>
  );
}

export default ItemList;
