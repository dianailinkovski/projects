import React, { useContext, useState } from "react";
import { Button } from "react-bootstrap";
import StateContext from "../StateContext";
import Axios from "axios";

function DeleteButton(props) {
  //console.log("DeleteButton friendInfo.username" + props.username);
  const appState = useContext(StateContext);
  const loggedInUser = appState.user.username;
  const token = appState.user.token
  let { username, userid } = props.friendInfo;
  const [isFriend, setIsFriend] = useState();

  async function deletePerson(e) {
    e.preventDefault();
    console.log("Delete button clicked for " + username);

    try {
      await Axios.delete("/users/friends/" + loggedInUser + "/" + username, {
          headers: {
            Authorization: token,
            'Content-Type': 'application/json'
          }
        });
      // , {
      //   loggedInUser,
      //   username
      // });
      console.log(
        "Old FRIEND " +
          username +
          " was successfully deleted for " +
          loggedInUser
      );
      console.log("isFriend = " + appState.isFriend);
      window.location.reload(false);
    } catch (e) {
      //console.log(e.response.data);
      console.log(e);
    }
  }

  return (
    <div>
      <Button variant="danger" className="deleteButton" onClick={deletePerson}>
        Delete
      </Button>{" "}
    </div>
  );
}

export default DeleteButton;
