import React, { useState, useEffect, setState, useContext, Link } from "react";
import { Card, CardGroup, CardDeck, Button, Grid } from "react-bootstrap";
import Page from "./Page";
import UserCard from "./UserCard";
//import { useParams } from "react-router-dom";
import Axios from "axios";
import StateContext from "../StateContext";
import bodyParser from "body-parser";

const jsonParser = bodyParser.json();

function ListUsers() {
  const appState = useContext(StateContext);
  const username = appState.user.username;
  let isFriend = appState.isFriend;

  const [friends, setFriends] = useState();
  const cardsArray = [];
  const [itemURL, setItemURL] = useState();
  const [itemName, setItemName] = useState();
  const [brand, setBrand] = useState();
  const [supplier, setSupplier] = useState();
  const [image, setImage] = useState();
  const [users, setUserList] = useState();

  //alert("hello");
  //console.log("In list-users, Current user is " + username);

  useEffect(() => {
    async function getUsers() {
      try {
        //console.log("Trying to get userList....");
        const response = await Axios.get("/users").then((res) => {
          //console.log(res);
          //console.log("res.data = ");
          //console.log(res.data);
          const users = res.data;
          appState.users = res.data;
          setUserList({ users });
        });
      } catch (error) {
        console.error(error);
      }
    }
    getUsers();
  }, []);

  useEffect(() => {
    async function getMyFriends() {
      try {
        //console.log("Trying to get userList....");
        await Axios.get("/users/friends/" + username).then((res) => {
          // console.log("res =");
          // console.log(res);
          // console.log("res.data = ");
          // console.log(res.data);
          //console.log("My Friends = " + res.data.friends);
          //console.log(res.data.friends);
          const friends = res.data.friends;
          appState.friends = res.data.friends;
          //console.log("appState.friends");
          //console.log(appState.friends);
          setFriends({ friends });
        });
      } catch (error) {
        console.error(error);
      }
    }
    getMyFriends();
  }, []);

  // appState.users.map((user) => console.log("username = " + user.username));
  // appState.friends.map((friend) =>
  //   console.log("Friend username = " + friend.username)
  // );
  // console.log("users = ");
  // console.log(appState.users);
  // console.log("friends = ");
  // console.log(appState.friends);

  function createUserCard(contact) {
    if (contact.username === username) return null;
    // Don't want to display the user loggedIN card
    else {
      return (
        <container fluid>
          <div className="row">
            <div className="column">
              <UserCard
                key={contact.id}
                name={contact.name}
                img={contact.picture}
                username={contact.username}
                email={contact.email}
              />
            </div>
          </div>
        </container>
      );
    }
  }

  //users.map((user) => (

  // const getUserArray = async () => {
  //   try {
  //     console.log("Trying to get userList....");
  //     const response = await Axios.get("/");
  //     console.log(response);
  //   } catch (err) {
  //     console.error(err);
  //   }
  // await Axios.get("/")
  //   .then((res) => {
  //     console.log(res);
  //   })
  //   .catch((error) => {
  //     console.log(error);
  //   })
  //   .then(() => {
  //     const userList = res.data;
  //     userList.map((user) => {
  //       return <h3>{user}</h3>;
  //     });
  //   });
  // };
  // console.log(getUserArray);
  // const userList = getUserArray().then(() => {
  //   userList.map((user) => {
  //     return <h3>{user}</h3>;
  //   });
  // console.log("res =");
  // console.log(jsonParser(res.data));
  // users = res.data;
  // console.log("users =  ");
  // console.log(users);
  // console.log("users = ");
  // console.log(users);
  // console.log("res.data.wishlist = ");
  // console.log(res.data.wishlist);
  // const wishList = res.data.wishlist;
  // appState.wishList = res.data.wishlist;
  // console.log("appState.wishList");
  // console.log(appState.wishList);
  // setWishList({ wishList });
  // });

  return (
    <Page title="List Users" wide={true}>
      <CardDeck>
        {appState.users && appState.users.length > 0
          ? appState.users.map(createUserCard)
          : // appState.users.map((user) => (
            //     <container fluid>
            //       <div>
            //         <div className="row">
            //           <div className="column">
            //             <Card
            //               style={{ width: "18rem" }}
            //               className="bg-dark text-black"
            //             >
            //               <Card.Img
            //                 src="https://picsum.photos/200/300"
            //                 alt="Card image"
            //               />
            //               <Card.ImgOverlay>
            //                 <Card.Title>{user.username}</Card.Title>
            //                 <Card.Text>
            //                   This is a wider card with supporting text below as a
            //                   natural lead-in to additional content. This content
            //                   is a little bit longer.
            //                 </Card.Text>
            //                 <Card.Text>Last updated 3 mins ago</Card.Text>
            //               </Card.ImgOverlay>
            //             </Card>
            //           </div>
            //         </div>
            //       </div>
            //     </container>
            //   ))
            console.log("Array Empty")}
      </CardDeck>
    </Page>
  );
}

export default ListUsers;
