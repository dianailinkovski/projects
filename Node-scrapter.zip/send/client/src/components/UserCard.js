import React, { useEffect, useState, useContext } from "react";
import Container from "./Container";
import Avatar from "./Avatar";
import Detail from "./Detail";
import AddButton from "./AddButton";
import DeleteButton from "./DeleteButton";
import { Button } from "react-bootstrap";
import StateContext from "../StateContext";
import Axios from "axios";

function UserCard(props) {
  const appState = useContext(StateContext);
  const username = appState.user.username;

  const [friends, setFriends] = useState();
  const cardsArray = [];
  const [itemURL, setItemURL] = useState();
  const [itemName, setItemName] = useState();
  const [brand, setBrand] = useState();
  const [supplier, setSupplier] = useState();
  const [image, setImage] = useState();
  const [users, setUserList] = useState();
  //const [isFriend, setIsFriend] = useState();
  //appState.isFriend = false;
  var isAfriend = false;
  var itsMe = false;

  // console.log("props");
  console.log("isFriend = " + appState.isFriend);
  // console.log("props.username = " + props.username);

  // async function getMyFriends() {
  //   try {
  //     console.log("Trying to get friends....");
  //     await Axios.get("/users/friends/" + username).then((res) => {
  //       //console.log("res =");
  //       //console.log(res);
  //       //console.log("res.data = ");
  //       //console.log(res.data);
  //       //console.log("res.data.friends = ");
  //       //console.log(res.data.friends);
  //       const friends = res.data.friends;
  //       appState.friends = res.data.friends;
  //       console.log("appState.friends");
  //       console.log(appState.friends);
  //       setFriends({ friends });
  //     });
  //   } catch (error) {
  //     console.error(error);
  //   }
  // }
  //appState.users.map((user) => console.log("username = " + user.username));
  if (appState.friends !== null) {
    appState.friends.map((friend) => {
      //console.log("Friend username = " + friend.username);
      if (props.username === appState.user.username) {
        //console.log("It's me, don't display my card");
        itsMe = true;
      }
      if (props.username === friend.username) {
        isAfriend = true;
        // console.log(
        //   "I'm " +
        //     appState.user.username +
        //     " and " +
        //     friend.username +
        //     " is a friend."
        //);
      }
    });
  }
  //console.log("Props username = " + props.username);
  //console.log("-----------------");

  // console.log("friends = ");
  // console.log(appState.friends);
  // console.log("Your friends username is... " + appState.friends.username);

  if (itsMe) return null;

  return (
    <div className="userCard" style={{ width: "20rem", flex: 1 }}>
      <div className="top">
        <h3 className="name">{props.name}</h3>
        <Avatar img={props.img} />
      </div>
      <div className="bottom">
        <Detail detailInfo={props.username} />
        <Detail detailInfo={props.email} />
        {isAfriend ? (
          <DeleteButton friendInfo={props} />
        ) : (
          <AddButton friendInfo={props} />
        )}
      </div>
    </div>
  );
}

export default UserCard;
