import React, { useEffect, useContext, useState } from "react";
import Axios from "axios";
import { useHistory, useParams } from "react-router-dom";
import GoogleMapReact from "google-map-react";
import Page from "../Page";
import { ToastContainer, toast } from "react-toastify";
import StateContext from "../../StateContext";
import Marker from "../Marker";
import { getByDisplayValue } from "@testing-library/react";

function EditItem() {
  const history = useHistory();
  const appState = useContext(StateContext);
  const [itemBrand, setItemBrand] = useState("");
  const [itemName, setItemName] = useState("");
  const [itemDescription, setItemDescription] = useState("");
  const [itemPrice, setItemPrice] = useState("");
  const [itemPicture, setItemPicture] = useState("");
  const [itemSupplierName, setItemSupplierName] = useState("");
  const [itemSupplierEmail, setItemSupplierEmail] = useState("");
  const [itemSupplierAddress, setItemSupplierAddress] = useState("");
  const [itemSupplierPhoneNumber, setItemSupplierPhoneNumber] = useState("");
  const [itemSupplierLat, setItemSupplierLat] = useState("");
  const [itemSupplierLot, setItemSupplierLot] = useState("");
  const [supplierId, setSupplierId] = useState("");
  const [itemUrl, setItemUrl] = useState("");
  const [lat, setLat] = useState(0);
  const [longi, setLongi] = useState(0);
  const { id } = useParams();
  const [editable, setEditable] = useState(false);
  const [itemUserId, setItemUserid] = useState("");

  async function getById(id) {
    var sendData = {};
    Axios.defaults.headers.get["Authorization"] = localStorage.getItem(
      "mfcToken"
    );
    try {
      const response = await Axios.get("/items/getByid/" + id);
      console.log(response.data, "this is response");
      // var scraped_data=response.data.data;
      setItemBrand(response.data.item.itemBrand);
      setItemName(response.data.item.itemName);
      setItemDescription(response.data.item.itemDescription);
      setItemPrice(response.data.item.itemPrice);
      setItemSupplierName(response.data.supplier.supplierName);
      setItemSupplierEmail(response.data.supplier.supplierEmail);
      setItemSupplierPhoneNumber(response.data.supplier.supplierPhoneNo);
      setItemSupplierAddress(response.data.supplier.supplierAddress);
      setItemPicture(response.data.item.itemPicture);
      setSupplierId(response.data.supplier._id);
      setItemUrl(response.data.item.itemURl);
      setLongi(response.data.supplier.itemSupplierLongi);
      setLat(response.data.supplier.itemSupplierLat);
      setItemUserid(response.data.item.userId);
      // setEditable(false);
    } catch (e) {
      //  console.log(e.response.data.msg)
      toast.error(e.response.data.msg, {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  }

  async function deleteItem() {
    Axios.defaults.headers.delete["Authorization"] = localStorage.getItem(
      "mfcToken"
    );
    try {
      await Axios.delete("/items/delete/" + id);
      toast.success("Deleted Sucessfully!", {
        position: toast.POSITION.TOP_RIGHT,
      });
      history.push("/show-item");
    } catch (e) {
      toast.error("Delete Failed", {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  }
  async function saveItem() {
    var sendData = {};
    sendData.itemBrand = itemBrand;
    sendData.itemName = itemName;
    sendData.itemDescription = itemDescription;
    sendData.itemPrice = itemPrice;
    sendData.itemSupplierName = itemSupplierName;
    sendData.itemSupplierEmail = itemSupplierEmail;
    sendData.itemSupplierPhoneNumber = itemSupplierPhoneNumber;
    sendData.itemSupplierAddress = itemSupplierAddress;
    sendData.itemPicture = itemPicture;
    sendData.supplierId = supplierId;
    sendData.itemId = id;
    sendData.itemURl = itemUrl;
    sendData.lat = lat;
    sendData.longi = longi;

    sendData.userId = localStorage.getItem("mfcUserId");
    Axios.defaults.headers.post["Authorization"] = localStorage.getItem(
      "mfcToken"
    );
    try {
      const response = await Axios.post("/items/save", sendData);
      setEditable(false);
      toast.success(response.data.msg, {
        position: toast.POSITION.TOP_RIGHT,
      });
    } catch (e) {
      toast.error("Save Failed", {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  }
  useEffect(() => {
    console.log("ggd", id);
    getById(id);
  }, []);
  return (
    <Page title="My Home">
      <ToastContainer autoClose={3000} />
      <div className="row align-items-center">
        <div
          className="col-lg-8 col-md-12 py-md-5 py-3"
          style={{ paddingBottom: "1rem!important" }}
        >
          <div className="row">
            <div className="col-md-3 col-sm-12 text-right">
              <label className="control-label">
                Item Name<span className="symbol required"></span>
              </label>
            </div>
            <div className="col-md-8 col-sm-10">
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  value={itemName}
                  onChange={(event) => {
                    setItemName(event.target.value);
                  }}
                ></input>
              </div>
            </div>
            <div className="col-md-1 pl-1 col-sm-2">
              <span className="symbol required">
                <i className="fa fa-pen"></i>
              </span>
            </div>
          </div>
          <div className="row">
            <div className="col-md-3 col-sm-12 text-right">
              <label className="control-label">
                Item Price<span className="symbol required"></span>
              </label>
            </div>
            <div className="col-md-8 col-sm-10">
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  value={itemPrice}
                  onChange={(event) => {
                    setItemPrice(event.target.value);
                  }}
                ></input>
              </div>
            </div>
            <div className="col-md-1 pl-1 col-sm-2">
              <span className="symbol required">
                <i className="fa fa-pen"></i>
              </span>
            </div>
          </div>
          <div className="row">
            <div className="col-md-3 text-right">
              <label className="control-label">
                Item Brand<span className="symbol required"></span>
              </label>
            </div>
            <div className="col-md-8">
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  value={itemBrand}
                  onChange={(event) => {
                    setItemBrand(event.target.value);
                  }}
                ></input>
              </div>
            </div>
            <div className="col-md-1 pl-1">
              <span className="symbol required">
                <i className="fa fa-pen"></i>
              </span>
            </div>
          </div>
          <div className="row">
            <div className="col-md-3 text-right">
              <label className="control-label">
                Item Picture<span className="symbol required"></span>
              </label>
            </div>
            <div className="col-md-8">
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  value={itemPicture}
                  onChange={(event) => {
                    setItemPicture(event.target.value);
                  }}
                ></input>
              </div>
            </div>
            <div className="col-md-1 pl-1">
              <span className="symbol required">
                <i className="fa fa-pen"></i>
              </span>
            </div>
          </div>
          <div className="row">
            <div className="col-md-3 text-right">
              <label className="control-label">
                Item Description<span className="symbol required"></span>
              </label>
            </div>
            <div className="col-md-8">
              <div className="form-group">
                <textarea
                  name="description"
                  className="form-control"
                  value={itemDescription}
                  onChange={(event) => {
                    setItemDescription(event.target.value);
                  }}
                ></textarea>
              </div>
            </div>
            <div className="col-md-1 pl-1">
              <span className="symbol required">
                <i className="fa fa-pen"></i>
              </span>
            </div>
          </div>
          <div className="row">
            <div className="col-md-3 text-right">
              <label className="control-label">
                Supplier Name<span className="symbol required"></span>
              </label>
            </div>
            <div className="col-md-8">
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  value={itemSupplierName}
                  onChange={(event) => {
                    setItemSupplierName(event.target.value);
                  }}
                ></input>
              </div>
            </div>
            <div className="col-md-1 pl-1">
              <span className="symbol required">
                <i className="fa fa-pen"></i>
              </span>
            </div>
          </div>
          <div className="row">
            <div className="col-md-3 text-right">
              <label className="control-label">
                Supplier Address<span className="symbol required"></span>
              </label>
            </div>
            <div className="col-md-8">
              <div className="form-group">
                <textarea
                  name="description"
                  className="form-control"
                  value={itemSupplierAddress}
                  onChange={(event) => {
                    setItemSupplierAddress(event.target.value);
                  }}
                  disabled={editable}
                ></textarea>
              </div>
            </div>
            <div className="col-md-1 pl-1">
              <span className="symbol required">
                <i className="fa fa-pen"></i>
              </span>
            </div>
          </div>
          <div className="row">
            <div className="col-md-3 text-right">
              <label className="control-label">
                Supplier Email<span className="symbol required"></span>
              </label>
            </div>
            <div className="col-md-8">
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  value={itemSupplierEmail}
                  onChange={(event) => {
                    setItemSupplierEmail(event.target.value);
                  }}
                ></input>
              </div>
            </div>
            <div className="col-md-1 pl-1">
              <span className="symbol required">
                <i className="fa fa-pen"></i>
              </span>
            </div>
          </div>
          <div className="row">
            <div className="col-md-3 text-right">
              <label className="control-label">
                Supplier Phone#<span className="symbol required"></span>
              </label>
            </div>
            <div className="col-md-8">
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  value={itemSupplierPhoneNumber}
                  onChange={(event) => {
                    setItemSupplierPhoneNumber(event.target.value);
                  }}
                ></input>
              </div>
            </div>
            <div className="col-md-1 pl-1">
              <span className="symbol required">
                <i className="fa fa-pen"></i>
              </span>
            </div>
          </div>
          {/* <div className="row">
                  <div className="col-md-3 text-right">      
                      <label className="control-label">Supplier Web link<span className="symbol required"></span></label>
                  </div>
                  <div className="col-md-7">
                    <div className="form-group">
                    <input type="text" className="form-control" disabled={editable}></input>                      
                    </div>
                  </div>
                  <div className="col-md-2 pl-1">                   
                    <span className="symbol required"><i className="fa fa-pen" ></i></span>    
                  </div>
           </div> */}
          <div className="row">
          <div className="col-md-8">{itemUserId}</div>
            {
              itemUserId==localStorage.getItem("mfcUserId")?  <div className="col-md-4">
              <button className="btn  btn-success" onClick={saveItem}>
                Save
              </button>

              <button
                className="btn  btn-danger"
                onClick={deleteItem}
                style={{ marginLeft: "10px" }}
              >
                Delete
              </button>
            </div>:""
            }
           
          </div>
        </div>

        <div className="col-lg-4 pl-lg-5 pb-3 py-lg-5">
          <div className="row">
            <div
              className="col-md-12 "
              style={{ border: "1px solid green", marginBottom: "15px" }}
            >
              <img
                src={itemPicture}
                style={{ height: "312px", width: "100%" }}
              ></img>
            </div>
          </div>
          <div className="col-md-12 " style={{ height: "252px" }}></div>
        </div>
      </div>
    </Page>
  );
}

export default EditItem;
