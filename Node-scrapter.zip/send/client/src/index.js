import React, { useState, useReducer, useEffect } from "react";
import ReactDOM from "react-dom";
import { useImmerReducer } from "use-immer";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import Axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.css';
//import authenticate from './common/Authenticate'
// My Components
import Header from "./components/Header";
import HomeGuest from "./components/HomeGuest";
import Home from "./components/Home";
import Footer from "./components/Footer";
import About from "./components/About";
import Terms from "./components/Terms";
import AddItem from "./components/AddItem";
import EditItem from "./components/Items/EditItem";
import FlashMessages from "./components/FlashMessages";
import Profile from "./components/Profile";
import ListUsers from "./components/ListUsers";
import ItemList from "./components/Items/ItemList";

import ShowItemList from "./components/Search/ItemList";

import StateContext from "./StateContext";
import DispatchContext from "./DispatchContext";
import config from './config';
Axios.defaults.baseURL = config.serverUrl;

function Main() {
  const initialState = {
    loggedIn: Boolean(localStorage.getItem("mfcToken")),
    isFriend: Boolean(false),
    users: [],
    flashMessages: [],
    friends: [],
    wishList: [],
    events: [],
    user: {
      token: localStorage.getItem("mfcToken"),
      username: localStorage.getItem("mfcUsername"),
      avatar: localStorage.getItem("mfcAvatar"),
      userId:localStorage.getItem("mfcUserId")
    },
    groupName: ""
  };

  function ourReducer(draft, action) {
    switch (action.type) {
      case "login":
        // console.log("got here1 with " + action.data);
        draft.loggedIn = true;
        draft.user = action.data;
        return;
      case "logout":
        draft.loggedIn = false;
        return;
      case "flashMessage":
        draft.flashMessages.push(action.value);
        return;
    }
  }

  const [state, dispatch] = useImmerReducer(ourReducer, initialState);

  useEffect(() => {
    // console.log("state.loggedIn = " + state.loggedIn,state.user);
    if (state.loggedIn) {
      localStorage.setItem("mfcToken", state.user.token);
      localStorage.setItem("mfcUsername", state.user.username);
      localStorage.setItem("mfcUserId", state.user.userId);
      localStorage.setItem("mfcAvatar", state.user.avatar);
    } else {
      localStorage.removeItem("mfcToken");
      localStorage.removeItem("mfcUsername");
      localStorage.removeItem("mfcAvatar");
      localStorage.removeItem("mfcUserId");
    }
  }, [state.loggedIn]);

  return (
    <StateContext.Provider value={state}>
      <DispatchContext.Provider value={dispatch}>
        <BrowserRouter>
          {/* <FlashMessages messages={state.flashMessages} /> */}
          <Header />
          <Switch>
            <Route path="/" exact>
              {state.loggedIn ? <Home /> : <HomeGuest />}
            </Route>
            <Route path="/about-us">
              <About />
            </Route>
            <Route path="/terms">
              <Terms />
            </Route>
            <Route path="/profile">
              <Profile />
            </Route>
            {/* <Route path="/list-users">
              <ListUsers />
            </Route> */}
            <Route path="/add-item">
            {state.loggedIn ? <AddItem /> : <HomeGuest />}
             </Route>
             <Route path="/show-item">
             {state.loggedIn ? <ItemList /> : <HomeGuest />}              
            </Route>
            <Route path="/search-item">
             {state.loggedIn ? <ShowItemList /> : <HomeGuest />}              
            </Route>
            <Route path="/edit-item/:id">             
              {state.loggedIn ?  <EditItem /> : <HomeGuest />}     
            </Route>
          </Switch>
          <Footer />
        </BrowserRouter>
      </DispatchContext.Provider>
    </StateContext.Provider>
  );
}

ReactDOM.render(<Main />, document.querySelector("#root"));

if (module.hot) {
  module.hot.accept();
}
