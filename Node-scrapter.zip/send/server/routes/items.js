const express = require("express");
const router = express.Router();
const http = require("http");
const axios = require("axios");
const cheerio = require("cheerio");
const NodeGeocoder = require("node-geocoder");

const Item = require("../models/Item");
const Supplier = require("../models/Supplier");
const options = {
  provider: process.env.provider, //google, opencage
  httpAdapter: "https", // Default
  //apiKey: 'AIzaSyD_D-qlxBqeXuIakps7rOsEVGZPYP3n3IM', // now google for Mapquest, OpenCage, Google Premier
  apiKey: process.env.geocodeApiKey, //"9edc68e232b34471b3cea272db03fb53", // it's opencage api key now
  formatter: null,
};

async function fetchHTML(url) {
  const { data } = await axios.get(url);
  return cheerio.load(data);
}

router.get("/", (req, res) => {
  res.send("We are on ITEM route");
});

router.post("/new", async (req, res) => {
  //console.log(req.body.url);
  let scrap_url = req.body.url;
  let response = {};
  response.itemName = "";
  response.itemPrice = "";
  response.itemDescription = "";
  response.itemPicture = "";
  response.itemSupplierAddress = "";
  response.itemSupplierName = "";
  response.itemSupplierEmail = "";
  response.itemSupplierPhoneNumber = "";
  response.itemBrand = "";
  if (scrap_url.includes("jasmine.ie")) {
    var $ = await fetchHTML(scrap_url);
	

    response.itemName = $("meta[property='og:title']").attr("content");
    var price_amount = $("meta[property='og:price:amount']").attr("content");
    var price_currency= $("meta[property='og:price:currency']").attr("content");
    response.itemPrice = price_amount+price_currency;
    response.itemDescription = $("meta[property='og:description']").attr("content");
    response.itemPicture = $("meta[property='og:image']").attr("content");
  
    var $$ = await fetchHTML("https://jasmine.ie/pages/about-us");
    var p_temp = $$("div.container").find("p");
    
    var p_temp_txt = $$(p_temp[8]).text();
    p_temp_txt = p_temp_txt.split("Email:");
    response.itemSupplierAddress = $$(p_temp[7])
      .text()
      .replace("Jasmine Design,", "");
    response.itemSupplierName = "Jasmine";
    response.itemSupplierEmail = p_temp_txt[1].trim();
    response.itemSupplierPhoneNumber = p_temp_txt[0].replace("Tel:", "");
    response.itemBrand = $("meta[property='og:site_name']").attr("content");  
  } else if (scrap_url.includes("www.cyclesuperstore.ie")) {
    var $ = await fetchHTML(scrap_url);

    const urlElems = $("div.rcProductDetBrands");
    for (let i = 0; i < $("div.rcProductDetBrands").length; i++) {
      response.itemBrand = $(urlElems[i]).text().replace("Brand:", "");
    }
    response.itemName = $("h1.rcProductDetTitle").text();
    response.itemDescription = $("#DescriptionTabCont").text();
    let childElems = $("div.contactInfo").children();
    let tel_email = $(childElems[0]).text();
    tel_email = tel_email.split("/");
    response.itemSupplierName = $(childElems[1])
      .text()
      .replace("©", "")
      .replace("2018", "");
    response.itemSupplierEmail = tel_email[1].replace("Mail:", "").trim();
    response.itemSupplierPhoneNumber = tel_email[0].replace("Tel:", "").trim();

    var $$ = await fetchHTML(
      "https://www.cyclesuperstore.ie/shop/pc/viewContent.asp?idpage=1#address"
    );

    var p_temp = $$("div#address").find("h4");
    for (let i = 0; i < $$("div#address").find("h4").length; i++) {
      //console.log($$(p_temp[i]).text(),i);
    }
    //console.log($$(p_temp[0]).text());
    response.itemSupplierAddress =
      "Cycle SuperStore FrameWorks Building  31 Airton Road Tallaght, Dublin 24 D24 AW96";
    response.itemSupplierLat = "";
    response.itemSupplierLot = "";
    response.itemPicture =
      "https://www.cyclesuperstore.ie/shop/pc/" +
      $("#DetMainImage").attr("src");
    response.itemSupplierWebLink = "";
    response.itemPrice = $("div.rcProductDetPrice").text();
  } else if (scrap_url.includes("www.360cycles.ie")) {
    var $ = await fetchHTML(scrap_url);

    response.itemName = $("h1").text();
    response.itemPrice = $("#item-price").text().trim();
    response.itemBrand = $("div.spec-line").text().replace("Brand:", "").trim();
    response.itemDescription = $("div.product-fullcontent").text().trim();
    var $$ = await fetchHTML("https://www.360cycles.ie/service/about/");
    var p_temp = $$("div.page-title").find("p");
    response.itemSupplierName = p_temp ? $$(p_temp[0]).text() : "";
    response.itemSupplierEmail = "info@360cycles.ie";
    response.itemSupplierPhoneNumber = $$("div.phone").text().trim();
    response.itemSupplierAddress = $$("li.address")
      .text()
      .replace(", D03 WP78", "");
    response.itemSupplierLat = "";
    response.itemSupplierLot = "";
    response.itemPicture = $("#productpageimages")
      .children()
      .first()
      .attr("href");
    response.itemSupplierWebLink = ""; //
    //console.log(response.itemPicture);
  } else if (scrap_url.includes("https://www.elverys.ie")) {
    var $ = await fetchHTML(scrap_url);
    response.itemName = $("h2.js-productName").text();
    response.itemPrice = $("div.new-price").text().trim();
    response.itemBrand = "";
    response.itemDescription = $("div.productDescriptionText").text().trim();
    var $$ = await fetchHTML("https://www.elverys.ie/elverys/en/contactUsPage");
    var p_temp = $$("div.content").find("p");
    response.itemSupplierName = "Elverys";
    response.itemSupplierEmail = $$(p_temp[1]).find("a").text();
    response.itemSupplierPhoneNumber = $$(p_temp[0]).text().substr(14, 13);
    response.itemSupplierAddress = $$(p_temp[3]).text().trim();
    response.itemSupplierLat = "";
    response.itemSupplierLot = "";
    var ul_temp = $("ul.pdpslider").find("li");
    response.itemPicture =
      "https://www.elverys.ie" + $(ul_temp[0]).find("img").attr("src");
    response.itemSupplierWebLink = ""; //
  }
  // if you want to scrap a new web site , pleae put the some code like above
  //  for example: else if(scrap_url.includes(site's domain)){
  //   
  // 
  // }

  if (response.itemSupplierAddress != "") {
    const geocoder = NodeGeocoder(options);
    const address = response.itemSupplierAddress; //'2600 Clifton Ave, Cincinnati, Ohio 45220'; // Go Bearcats!
    const results = await geocoder.geocode(address);
    //console.log(results);
    if (results[0] != undefined) {
      response.lat = results[0].latitude;
      response.longi = results[0].longitude;
    } else {
      response.lat = 0;
      response.longi = 0;
    }
  }
  res.status(200).json({ data: response, msg: "scrapping finished!" });
});

router.post("/save", async (req, res) => {
  let supplier = {};
  supplier.supplierName = req.body.itemSupplierName;
  supplier.supplierAddress = req.body.itemSupplierAddress;
  supplier.supplierEmail = req.body.itemSupplierEmail;
  supplier.supplierPhoneNo = req.body.itemSupplierPhoneNumber;
  supplier.itemSupplierLat = req.body.lat;
  supplier.itemSupplierLongi = req.body.longi;
  let item = {};
  item.userId = req.body.userId;
  item.itemBrand = req.body.itemBrand;
  item.itemName = req.body.itemName;
  item.itemDescription = req.body.itemDescription;
  item.itemPrice = req.body.itemPrice;
  item.itemPicture = req.body.itemPicture;
  item.itemURl = req.body.itemURl;

  var exit = await Item.findOne(
    { itemURl: req.body.itemURl, userId: item.userId },
    function (err, itemInfo) {}
  );

  if (exit) {
    let itemId = exit._id;
    let supplierId = exit.supplierId;
    await Supplier.findByIdAndUpdate(supplierId, supplier, async function (
      err,
      supplierInfo
    ) {
      if (err) {
        res.status(500).json({ msg: "Update Failed" });
        return;
      } else {
        await Item.findByIdAndUpdate(itemId, item, function (err, itemInfo) {
          if (err) {
            res.status(500).json({ msg: "Update Failed" });
            return;
          } else {
            res.status(200).json({ msg: "Update successfully" });
            return;
          }
        });
      }
    });
  } else {
    await Supplier.create(supplier, async function (err, result) {
      if (err) {
        res.status(500).json({ msg: "Internal server error" });
        return;
      } else {
        item.supplierId = result._id;
        await Item.create(item, async function (err, item) {
          if (err) {
            res.status(500).json({ msg: "Internal server error" });
          } else {
            supplier.itemID = item._id;
            await Supplier.findByIdAndUpdate(result._id, supplier, function (
              err,
              userInfo
            ) {
              if (err) {
                throw err;
              } else {
                res.status(200).json({ msg: "Saved successfully" });
              }
            });
            // res.status(200).json({ data: {}, msg: "Saved successfully" });
          }
        });
      }
      //item.userId=
    });
  }
});

router.get("/itemlist", async (req, res) => {
  let result = await Item.aggregate([
    {
      $lookup: {
        from: "suppliers",
        localField: "supplierId",
        foreignField: "_id",
        as: "supplier",
      },
    },
  ]);
  res.status(200).json({ msg: "list found!", data: result });
});

router.get("/getByid/:id", async (req, res) => {
  let item = await Item.findById(req.params.id, async function (err, item) {
    if (err) {
      res.status(400).json({ msg: "not found!" });
    }
  });
  Supplier.findById(item.supplierId, async function (err, supplier) {
    if (err) {
      res.status(400).json({ msg: "not found!" });
    } else {
      res.status(200).json({ msg: "found!", item: item, supplier: supplier });
    }
  });
});

router.delete("/delete/:id", async (req, res) => {
  let result = await Item.findByIdAndRemove(req.params.id, function (
    err,
    item
  ) {
    if (err) res.status(400).json({ msg: "Delete failed!" });
    else {
      Supplier.findByIdAndRemove(item.supplierId, function (err, supplier) {
        if (err) res.status(400).json({ msg: "Delete failed!" });
        else res.status(200).json({ msg: " deleted successfully!" });
      });
      // res.status(200).json({ msg: "Asset deleted successfully!", data:null});
    }
  });
});
module.exports = router;
