const express = require("express");
const axios = require("axios");
const router = express.Router();
const jwt = require('jsonwebtoken');	
const bcrypt = require("bcryptjs");
// const {expiredAfter,secretKey}= require('../config/config');
const User = require("../models/User");
//const checkObjectId = require("../middleware/checkObjectId");
const { check, validationResult } = require("express-validator");


/*
router.get("/", (req, res) => {
  res.send("We are on USERS route");
});
*/

// Check the Register route
router.get("/register", (req, res) => {
  res.send("This is a new USER REGISTRATION");
});

// Register a new user
router.post(
  "/register",
  [
    //res.send("This is a new USER REGISTRATION");
    check("name", "Name is required").notEmpty(),
    check("username", "Username is required").notEmpty(),
    check("email", "Name is required").notEmpty(),
    check("email", "Name is not valid").isEmail(),
    check("password1", "Password is required").notEmpty(),
    check("password2", "Password is required").notEmpty()
  ],
  async (req, res) => {
    const errors = validationResult(req);

    const user = await User.findOne({
      username: req.body.username
    });
    if (user)
      return res
        .status(403)
        .json({ msg: "You are already registered, go to LOGIN" });

    if (!(req.body.password1 === req.body.password1)) {
      console.log("Passwords don't match...!!");
      return res.json(user);
    } else {
      if (!errors.isEmpty()) {
        return res.status(422).json({ errors: errors.array() });
      } else {
        const user = new User({
          name: req.body.name,
          username: req.body.username,
          password1: req.body.password1,
          email: req.body.email,
          location: req.body.location,
          picture: req.body.picture
        });
        console.log(user);

        bcrypt.genSalt(10, (err, salt) => {
          bcrypt.hash(user.password1, salt, (err, hash) => {
            if (err) {
              console.log(err);
            }
            user.password1 = hash;
            user.save((err) => {
              if (err) {
                console.log(err);
                res.status(401).json({msg: "Registered was failed", data:null});
                return;
              } else {
                res.status(200).json({msg: "User was registered sucessfully", data:null});
                console.log("You're Registered...!!");
                //res.redirect("/user/login");
              }
            });
          });
        });
      }
    }
  }
);

// Login route
/*router.get("/login", (req, res) => {
  res.send("This is the LOGIN page");
});
*/

// Login User
router.post("/login", async (req, res) => {

  if(req.body.password==null || req.body.username==null){
    res.status(400).json({ msg: "Bad Request!", data:null});
    return
  } 
  User.findOne({username: req.body.username}, function(err, userInfo){   
        if (err) {
          res.status(500).json({ msg: 'Internal server error' });
        } else {

          if(userInfo != null && bcrypt.compareSync(req.body.password, userInfo.password1)) {
         const token = jwt.sign({id: userInfo._id,expiredAt: new Date().getTime() + parseInt(process.env.expiredAfter),username:userInfo.username}, process.env.secretKey); 
         
          res.status(200).json({username: req.body.username,userId:userInfo._id, token:token});	
          }else{            
            res.status(400).json({msg: "Invalid email/password!", data:null});

          }
        }
      });
});

// @route    GET /users
// @desc     Get all profiles
// @access   Public
router.get("/", async (req, res) => {
  //console.log("GEt all users");

  //res.send("We are on USERS route");
  try {
    const users = await User.find();
    // if (!users) return res.status(400).json({ msg: "Users not found" });
    return res.status(200).json({data:users});
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route    GET /:username
// @desc     Get all profiles
// @access   Public
router.get("/:username", async ({ params: { username } }, res) => {
  //res.send("We are on USERS route looking for " + username);
  try {
    const user = await User.findOne({
      username: username
      //password: password
    });

    if (!user) return res.status(400).json({ msg: "User not found" });
    return res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route    GET /users/friends
// @desc     Get all profiles
// @access   Public
router.get("/friends", async (req, res) => {
  //console.log("Get all friends");

  //res.send("We are on USERS/FRIENDS route");
  try {
    const friends = await User.friends.find();

    if (!friends) return res.status(400).json({ msg: "Friends not found" });
    return res.json(friends);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route    PUT /friends/:username
// @desc     Add FRIENDS item
// @access   Private
router.put("/friends/:username", async (req, res) => {
  //res.send("We are on PUT route looking for " + username);
  const currentUser = req.params.username;
  console.log(
    "We are on the PUT users/friends/:username route for " + currentUser
  );

  try {
    const user = await User.findOne({
      username: currentUser
    });
    if (!user) return res.status(400).json({ msg: "User not found" });

    const newFriend = {
      //id: req.body.id,
      name: req.body.name,
      username: req.body.username,
      email: req.body.email
    };

    console.log(
      "We're adding " +
        newFriend.name +
        newFriend.username +
        newFriend.email +
        " for " +
        currentUser +
        " also known as " +
        user.username
    );

    user.friends.unshift(newFriend);
    user
      .save()
      .then((data) => {
        res.json(data);
      })
      .catch((err) => {
        res.json({ message: err });
      });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route    delete /friends/:username
// @desc     Delete FRIENDS item
// @access   Private
router.delete("/friends/:username/:friend", async (req, res) => {
  //res.send("We are on PUT route looking for " + username);
  const loggedInUser = req.params.username; // current logged in user
  const connectedFriend = req.params.friend; // friend to be deleted
  let friendID = "";
  console.log(
    "We are on the DELETE users/friends/:username route for " +
      loggedInUser +
      " deleting his friend " +
      connectedFriend
  );

  try {
    const user = await User.findOne({
      username: loggedInUser
    });
    if (!user) return res.status(400).json({ msg: "User not found" });

    console.log(
      "We're deleting " +
        connectedFriend +
        //deleteFriend.username +
        " for " +
        loggedInUser +
        " also known as " +
        user.username
    );

    // Find the ID of the friend, so we can delete him.
    // Couldn't figure out how to delete friend by "username"
    user.friends.map((friend) => {
      //console.log("Friend username = " + friend.username);
      if (friend.username === connectedFriend) {
        friendID = friend._id;
        console.log("friend._id is " + friendID);
      }
    });

    user.friends.pull(friendID);
    user
      .save()
      .then((data) => {
        res.json(data);
      })
      .catch((err) => {
        res.json({ message: err });
      });

    // user.friends.findOneAndUpdate(
    //   query,
    //   { $pull: { username: friend } },
    //   function (err, data) {
    //     if (err) {
    //       return res.status(500).json({ error: "error in deleting address" });
    //     }

    //     res.json(data);
    //   }
    // );
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route    Get /friends/:username
// @desc     Retrieve FRIENDS items
// @access   Private
router.get("/friends/:username", async (req, res) => {
  //res.send("We are on PUT route looking for " + username);
  const username = req.params.username;
  // console.log(
  //   "We are on the GET users/friends/:username route for " + username
  // );

  try {
    const user = await User.findOne({
      username: username
    });
    if (!user) {
      return res.status(400).json({ msg: "User not found" });
    } else {
      //console.log(user.friends);
      res.json(user);
      //res.send("Here's the friends...");
    }
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route    PUT /circles/:username
// @desc     Add CIRCLES item
// @access   Private
router.put("/circles/:username", async (req, res) => {
  //res.send("We are on PUT route looking for " + username);
  const currentUser = req.params.username;
  console.log(
    "We are on the PUT users/circles/:username route for " + currentUser
  );

  try {
    const user = await User.findOne({
      username: currentUser
    });
    if (!user) return res.status(400).json({ msg: "User not found" });

    const newCircle = {
      //id: req.body.id,
      circleName: req.body.groupName,
      circleList: req.body.groupList
    };

    console.log(
      "We're adding " +
        newCircle.circleName +
        " " +
        newCircle.circleList +
        " for " +
        currentUser +
        " also known as " +
        user.username
    );

    user.circles.unshift(newCircle);
    user
      .save()
      .then((data) => {
        res.json(data);
      })
      .catch((err) => {
        res.json({ message: err });
      });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// LOGOUT
router.get("/logout", function (req, res) {
  console.log("logout");

  req.logout();
  res.redirect("/");
});

module.exports = router;
