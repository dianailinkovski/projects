const express = require("express");
const http = require("http");
const cors = require("cors");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
// const flash = require("connect-flash");
// const session = require("express-session");
require("dotenv/config");
// const config=require("./config/database");
const { authenticate, authError } = require('./middleware/index');
const app = express();
const server = http.createServer(app);
const PORT = process.env.port;
const IOPORT = 8081;

// Import Routes
const usersRoute = require("./routes/users");
const itemsRoute = require("./routes/items");

// MIDDLEWARE - when we hit a route, these are the functions to execute
app.use(bodyParser.json());
app.use(cors());
app.options("*", cors());
app.use("/users", usersRoute);
app.use("/items", [authenticate, authError],itemsRoute);
//app.use(passport.initialize());
//app.use(passport.session());

// Global Variable - Set if USER is logged in
app.get("*", (req, res, next) => {
  res.locals.user = req.user || null;
  next();
});

// ROUTES
app.get("/", (req, res) => {
  res.send("We are on HOME route");
});
// Connect to DB
mongoose.connect(
 process.env.database,
  { useNewUrlParser: true, useUnifiedTopology: true },
  () => console.log("connected to DB!")
);

server.listen(IOPORT, () => console.log(`IOServer has started listening.`));
// Listening to Server
app.listen(PORT, () => console.log(`APPServer has started listening.`,PORT));
