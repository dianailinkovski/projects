const mongoose = require("mongoose");

const ItemSchema = mongoose.Schema({
  
  userId:{
    type:String,
    required:true
  },
  supplierId:{
    type: mongoose.Schema.Types.ObjectId,  
  },
  itemBrand: {
    type: String,   
  },
  itemName: {
    type: String,    
  },
  itemDescription: {
    type: String
  },
  itemPrice: {
    type: String
  },
  itemPicture: {
    type: String  
  },
  itemURl: {
    type: String  
  },
  // itemSupplierName: {
  //   type:String
  // },
  // itemSupplierEmail: {
  //   type:String
  // },  
  // itemSupplierAddress: {
  //   type:String
  // },
  // itemSupplierPhoneNumber: {
  //   type:String
  // },
  
  // itemSupplierWebLink: { //location of supplier
  //   type:String
  // },
  itemAddedDate: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model("Item", ItemSchema);
