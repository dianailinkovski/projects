const mongoose = require("mongoose");

const UserSchema = mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  username: {
    type: String,
    required: true
  },
  password1: {
    type: String,
    required: true
  },
  password2: {
    type: String
  },
  email: {
    type: String,
    required: true
    //unique: true
  },
  location: {
    type: String
    //required: true
  },
  dob: {
    type: Date,
    default: Date.now
  },
  picture: {
    type: String
    //required: true
  },
  myItems: [
    {
      brand: {
        type: String,
        required: true
      },
      itemName: {
        type: String,
        required: true
      },
      itemID: {
        // type: Schema.Types.ObjectId,
        // ref: "Item"
      },
      itemSupplier: {
        // type: Schema.Types.ObjectId,
        // ref: "Supplier"
      },
      itemAddedDate: {
        type: Date,
        default: Date.now
      }
    }
  ]
});

module.exports = mongoose.model("User", UserSchema);
