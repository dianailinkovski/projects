const mongoose = require("mongoose");

const SupplierSchema = mongoose.Schema({
  supplierName: {
    type: String,
    required: true
  },
  supplierAddress: {
    type: String,
    required: true
  },
  supplierEmail: {
    type: String,
    required: true
  },
  supplierPhoneNo: {
    type: String,
    required: true
  },
  itemID: {
   // type: String,
    type: mongoose.Schema.Types.ObjectId,
   // ref: "Item"
  },
  itemSupplierLat: { //location of supplier
    type:String
  },
  itemSupplierLongi: { //location of supplier
    type:String
  },
  // itemAddedDate: {
  //   type: Date,
  //   default: Date.now
  // },
  supplierAddedDate: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model("Supplier", SupplierSchema);
