
module.exports= {
  port:8080,
  secretKey : 'secretKey',
  expiredAfter: 60 * 60 * 1000 *24*30,
  
};
