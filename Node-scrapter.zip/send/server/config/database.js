module.exports = {
  database: "mongodb://localhost/scraper",
  secret: "myLittleSecret"
};
