import axios from 'axios'
import md5 from 'md5'
import CONFIG from '../constants/config'
import * as CONSTS from '../constants/const'

axios.defaults.headers.get['Content-Type'] = 'application/json'

export const getNewAuthToken = ( password) => {
  return dispatch => {

    if(password=="zellatech" || password=="connectwise"){
      localStorage.setItem("user_id",password);
      dispatch({ type: CONSTS.GET_NEW_TOKEN_SUCCESS, payload:password })
    }
    else{
      dispatch({ type: CONSTS.FAIL_AUTH_REQUEST, payload: "failed" })
     }  
    
  }
}
export const getUserData = () => {
  return dispatch => {   
     dispatch({ type: CONSTS.GET_USER_DATA, payload: "user_data" })    
    
  }
}
export const resetAuth = () => {
  return dispatch => {   
     dispatch({ type: CONSTS.RESET_AUTH_TOKEN, payload: null })    
    
  }
}
