import React, { useState, useEffect, useRef } from 'react'
import { connect } from 'react-redux'
import PerfectScrollbar from 'react-perfect-scrollbar'
import { ToastContainer, toast } from 'react-toastify';
import { resetAuth } from '../../actions/auth.action'
import { Link } from "react-router-dom";
import _ from 'lodash'
// import {
//   sendMessage,
//   getMessage,
//   getAllNumbers,
//   getPrintMessage,
//   setMemberNum,
//   newMssage,
//   deleteConversation,
//   getCallForward,
// } from '../../actions/message.action'

import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Tooltip,
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
} from 'reactstrap'

import './Home.css'
import axios from 'axios'
import CONFIG from '../../constants/config'

// import { getUserData } from '../../actions/auth.action'
import classnames from 'classnames'

const Home = props => {
  const [nextQuestions, setNextQuestions] = React.useState(false);
  const {
    history,    
  } = props
  const logout=()=>{
    localStorage.removeItem('user_id');
    props.resetAuth();
    history.push('/')
  }
 const selectMV=(event)=>{
    if(event.target.value=="")
      setNextQuestions(false);
    else
       setNextQuestions(true);    
 }
  return (
     <div >
    {/* // <div className={"dark"}> */}
      <ToastContainer autoClose={8000} />  
      <header className="header-bar bg-dark1 shadow" style={{background:'#fff !important'}}>     
      <div className="container d-flex flex-column flex-md-row align-items-center p-3">
        <h4 className="my-0 mr-md-auto font-weight-normal">
          <Link to="/" className="text-white">
            Motor Vessels 
          </Link>
        </h4>  
        <div className="row align-items-center">
        <div className="col-md mr-0 pr-md-0 mb-3 mb-md-0">         
        </div>
        <div className="col-md mr-0 pr-md-0 mb-3 mb-md-0">          
        </div>
        <div className="col-md-auto">
          <button className="btn btn-info btn-sm"
          onClick={logout}
          >Log out</button>
        </div>
      </div>     
      </div>
    </header>   
      
    <div className={"container  py-md-5 container--narrow"}>
       {/* <div className="row align-items-center" >          
            <div className="col-md-8">
                <div className="form-group">
                <label className="control-label">First Question:</label>
                 <textarea name="description" className="form-control" 
                 rows={3} height="auto"
                 ></textarea>
              </div>
            </div>
        </div> */}
        <div className="row align-items-center" >    
            <div className="col-md-6">
                <div className="form-group">
                <label className="control-label">I am having problems with…</label>
                <select name="Motors" id="Motors" className="custom-select" onChange={selectMV}>
                <option value=""></option>
                <option value="Arnie Christiansen">Arnie Christiansen</option>
                <option value="Baxter Southern">Baxter Southern</option>
                <option value="Bill Stegbauer">Bill Stegbauer</option>
                <option value="Bobby Jones">Bobby Jones</option>
                <option value="Capt Richard Sides">Capt Richard Sides</option>
                <option value="Capt Sam Yount">Capt Sam Yount</option>
                <option value="Charles Southern">Charles Southern</option>
                <option value="Cheryl Stegbauer">Cheryl Stegbauer</option>
                <option value="David Stegbauer">David Stegbauer</option>
                <option value="Dennis Collins">Dennis Collins</option>
                <option value="Frank Hollomon">Frank Hollomon</option>
                <option value="Frank Stegbauer">Frank Stegbauer</option>
                <option value="Frank T Stegbauer">Frank T Stegbauer</option>
                <option value="Joanne Stegbauer">Joanne Stegbauer</option>
                <option value="HR Kirtley">HR Kirtley</option>
                <option value="Kevin Conway">Kevin Conway</option>
                <option value="Larry Tilley">Larry Tilley</option>
                <option value="Laura Elizabeth">Laura Elizabeth</option>
                <option value="Laura Tamble">Laura Tamble</option>
                <option value="Mary Elizabeth">Mary Elizabeth</option>
                <option value="Paula Fortier">Paula Fortier</option>
                <option value="Robert Ingle">Robert Ingle</option>
                <option value="Scott Stegbauer">Scott Stegbauer</option>
                <option value="The Colonel">The Colonel</option>
                <option value="The Colonel Cell">The Colonel Cell</option>
                <option value="Theresa Echols">Theresa Echols</option>
                <option value="Tommy Parrish">Tommy Parrish</option>               
              </select>
              </div>
            </div>
        </div>
        {
          nextQuestions?<div>
          <div className="row align-items-center" >          
          <div className="col-md-8">
              <div className="form-group">
              <label className="control-label">Second Question:</label>
               <textarea name="description" className="form-control" 
               rows={2} height="auto"                  ></textarea>
            </div>
          </div>
       </div>
       <div className="row align-items-center" >          
          <div className="col-md-8">
              <div className="form-group">
              <label className="control-label">Three Question:</label>
               <textarea name="description" className="form-control" 
               rows={2} height="auto"
               ></textarea>
            </div>
          </div>
       </div>
       <div className="row align-items-center" >          
          <div className="col-md-8">
              <div className="form-group">
              <label className="control-label">Fourth Question:</label>
               <textarea name="description" className="form-control" 
               rows={2} height="auto"
               ></textarea>
            </div>
          </div>
       </div>
       </div>:<div></div>
        }
        
        
    </div>
      {/* <div className="layout container md-5">      
        <div className="content light">
         </div>
      </div> */}
    </div>
  )
}

const mapStateToProps = state => ({
  auth: state.auth,
  
})
const mapDispatchToProps = dispatch => ({ 
  resetAuth: () =>
    dispatch(resetAuth()),
})
export default connect(mapStateToProps, mapDispatchToProps)(Home)
