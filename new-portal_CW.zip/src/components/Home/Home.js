import React, { useState, useEffect, useRef } from 'react'
import { connect } from 'react-redux'
import PerfectScrollbar from 'react-perfect-scrollbar'
import { ToastContainer, toast } from 'react-toastify';
import axios from 'axios'
import { Link } from "react-router-dom";
import _ from 'lodash';
import { resetAuth } from '../../actions/auth.action';


// import {
//   sendMessage,
//   getMessage,
//   getAllNumbers,
//   getPrintMessage,
//   setMemberNum,
//   newMssage,
//   deleteConversation,
//   getCallForward,
// } from '../../actions/message.action'

import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter, 
} from 'reactstrap'

import './Home.css'

import CONFIG from '../../constants/config'

// import { getUserData } from '../../actions/auth.action'
import classnames from 'classnames'
import { send } from 'react-ga';

const email_list={'MV STC TEST':'administrator@southerntowing.net','STC MV Test2':'administrator@southerntowing.Microsoft.com',
'Arnie Christiansen':'mv.arne.christiansen@southerntowing.net','Baxter Southern':'mv.baxter.southern@southerntowing.net',
'Bill Stegbauer':'mv.bill.stegbauer@southerntowing.net','Bobby Jones':'mv.bobby.jones@southerntowing.net','Capt Richard Sides':'mv.capt.richardsides@southerntowing.net',
'Capt Sam Yount':'mv.capt.sam.yount@southerntowing.net','Charles Southern':'mv.charles.southern@southerntowing.net','Cheryl Stegbauer':'mv.cheryl.stegbauer@southerntowing.net',
'David Stegbauer':'mv.david.stegbauer@southerntowing.net','Dennis Collins':'mv.dennis.collins@southerntowing.net','Frank Hollomon':'mv.frank.hollomon@southerntowing.net','Frank Stegbauer':'mv.frank.stegbauer@southerntowing.net',
'Frank T Stegbauer':'mv.frank.t.stegbauer@southerntowing.net','Joanne Stegbauer':'mv.joanne.stegbauer@southerntowing.net','Kevin Conway':'mv.kevin.conway@southerntowing.net',
'Larry Tilley':'mv.larry.tilley@southerntowing.net','Laura Elizabeth':'mv.laura.elizabeth@southerntowing.net','Laura Tamble':'mv.laura.tamble@southerntowing.net',
'Mary Elizabeth':'mv.mary.elizabeth@southerntowing.net','Paula Fortier':'mv.paula.fortier@southerntowing.net','Robert Ingle':'mv.robert.ingle@southerntowing.net',
'Scott Stegbauer':'mv.scott.stegbauer@southerntowing.net','The Colonel':'mv.the.colonel@southerntowing.net','Theresa Echols':'mv.theresa.echols@southerntowing.net',
'Tommy Parrish':'mv.tommy.parish@southerntowing.net'};
const Home = props => {
  const [nextQuestions, setNextQuestions] = React.useState(false);
  const [disableMotorVessel,setDisableMotorVessel]=React.useState(false);
  const [disableName,setDisableName]=React.useState(true);
  const [disableProblem,setDisableProblem]=React.useState(true);
  const [disableNavigate,setDisableNavigate]=React.useState(true);
  const [disableDescribe,setDisableDescribe]=React.useState(true);
  const [disableSubmit,setDisableSubmit]=React.useState(true);
  const [fistQuestion,setFistQuestion]=React.useState('');
  const [motorVessel,setMotorVessel]=React.useState('');
  const [havingProblem,setHavingProblem]=React.useState('');
  const [safeNavigation,setSafeNavigation]=React.useState('');
  const [describeTxt,setDescribeTxt]=React.useState('');
  const [yourname,setYourname]=React.useState('');
  const [modal,setModal]=React.useState(false);
  const [notifyStr,setNotifyStr]=React.useState('');
  const {
    history,    
  } = props
  const logout=()=>{
    localStorage.removeItem('user_id');
    props.resetAuth();
    history.push('/')
  }
 const selectMV=(event)=>{
  setDisableProblem(event.target.value!=""?false:true);       
  setMotorVessel(event.target.value);
  if(event.target.value==""){
      setDisableProblem(true);
      setHavingProblem("");

      setSafeNavigation("");
      setDisableNavigate(true);

      setDisableDescribe(true);
      setDescribeTxt("");
      setDisableSubmit(true);

      setYourname("");
      setDisableName(true);
  }
  
 }
 const selectProblem=(event)=>{
  setDisableNavigate(event.target.value!=""?false:true);
  setHavingProblem(event.target.value);
  if(event.target.value==""){
      setSafeNavigation("");
      setDisableNavigate(true);

      setDisableDescribe(true);
      setDescribeTxt("");
      setDisableSubmit(true);
      
      setYourname("");
      setDisableName(true);
  }

 }
 const selectNavigate=(event)=>{
  setDisableDescribe(event.target.value!=""?false:true);
  setSafeNavigation(event.target.value);

  if(event.target.value==""){   

    setDisableDescribe(true);
    setDescribeTxt("");
    setDisableSubmit(true);

    setYourname("");
    setDisableName(true);
}

 }
 const questionChange=(event)=>{
    setFistQuestion(event.target.value);
    setDisableMotorVessel(event.target.value!=""?false:true);
    if(event.target.value==""){
      setMotorVessel("");
      setDisableMotorVessel(true);

      setDisableProblem(true);
      setHavingProblem("");

      setSafeNavigation("");
      setDisableNavigate(true);

      setDisableDescribe(true);
      setDescribeTxt("");

      setDisableSubmit(true);
    }
 }
 const  onSubmit=async ()=>{

 
  axios.defaults.headers.common['Authorization'] = CONFIG.Authorization;
  axios.defaults.headers.common['clientId'] = CONFIG.clientId;
  // const URL = `${CONFIG.corsURL}${CONFIG.API_URL}/service/tickets/282533`
  const URL = `${CONFIG.corsURL}${CONFIG.API_URL}/service/tickets`

  var sendData={};
  var agency_str="";
  if(safeNavigation=="No"){
    sendData.summary="EMERGENCY "+havingProblem;
    agency_str="EMERGENCY ";
    sendData.priority={"id": 6,
                      "name": "Priority 1 - Emergency"};
  }
  else{
    sendData.summary=havingProblem;
    agency_str="";
  }


  sendData.company={
            "id": 19436,
            "identifier": "SouthernTowing",
            "name": "Southern Towing"
};
sendData.contactEmailAddress=email_list[motorVessel];
sendData.status={
  "id": 670,
   "name": "New (Portal)"
}




let ticketId=null;
  await axios
            .post(URL, sendData)
            .then(res => {             
              console.log(res.data,'this is res');
                  ticketId=res.data.id;
            }) 

  var sendData2={};
  let  notes="Problem: "+agency_str+havingProblem+", ";
  notes=notes+"Motor Vessel: "+motorVessel+", " 
  notes=notes+"Are you able to safely navigate?: "+safeNavigation;
  notes=notes+", Describe the issue: "+describeTxt;
  notes=notes+", Name: "+yourname;
  sendData2.ticketId=ticketId;
  sendData2.text=notes;
  sendData2.detailDescriptionFlag=true;
  sendData2.internalAnalysisFlag=false;
  sendData2.resolutionFlag=false;

  const URL2 = `${CONFIG.corsURL}${CONFIG.API_URL}/service/tickets/${ticketId}/notes`



  axios.defaults.headers.common['Content-Type'] = 'application/json';

  await axios
  .post(URL2, sendData2)
  .then(res => {             
    console.log(res.data,'this is res2');
        
  }) 
          //  .get(URL)
          //   .then(res => {             
          //     console.log(res.data,'this is res');
          //   })       
          setModal(true);
          setNotifyStr('Your issue has been reported. Please write down and reference ticket # '+ticketId);
         

  // toast.success('Your issue has been reported. Please write down and reference ticket # '+ticketId, {
  //   position: toast.POSITION.TOP_RIGHT,
  // })
 }
 const changeDescribe=(event)=>{
  setDescribeTxt(event.target.value);
  if(event.target.value==""){
    setDisableSubmit(true);
    setDisableName(true);
    setYourname('');
  }
  else{
    setDisableName(false);
  }
 }
 const changeYourname=(event)=>{
  setYourname(event.target.value);
   if(event.target.value==""){
     setDisableSubmit(true);     
   }
   else{    
     setDisableSubmit(false);
   }
 }
 const toggle = () => setModal(!modal);
  return (
     <div >
    {/* // <div className={"dark"}> */}
      <ToastContainer autoClose={8000} />  
      <header className="header-bar bg-dark1 shadow" style={{background:'#fff !important'}}>     
      <div className="container d-flex flex-column flex-md-row align-items-center p-3">
        <h4 className="my-0 mr-md-auto font-weight-normal">
          <Link to="/" className="text-white">
            Motor Vessels 
          </Link>
        </h4>  
        <div className="row align-items-center">
        <div className="col-md mr-0 pr-md-0 mb-3 mb-md-0">         
        </div>
        <div className="col-md mr-0 pr-md-0 mb-3 mb-md-0">          
        </div>
        <div className="col-md-auto">
          <button className="btn btn-info btn-sm"
          onClick={logout}
          >Log out</button>
        </div>
      </div>     
      </div>
    </header>   
      
    <div className={"container  py-md-5 container--narrow"}>
    {/* <div className="row align-items-center" >          
            <div className="col-md-8">
                <div className="form-group">
                <label className="control-label">First question: </label>
                 <textarea name="description" className="form-control" 
                 onChange={(event)=>{questionChange(event)}}
                 rows={2} height="auto"
                 ></textarea>
              </div>
            </div>
        </div> */}
    <div className="row align-items-center" >    
            <div className="col-md-6">
                <div className="form-group">
                <label className="control-label">Please select a Motor Vessels</label>
                <select name="Motors" value={motorVessel} id="Motors" className="custom-select" onChange={selectMV} disabled={disableMotorVessel}>
                <option value=""></option>
                <option value="Arnie Christiansen">Arnie Christiansen</option>
                <option value="Baxter Southern">Baxter Southern</option>
                <option value="Bill Stegbauer">Bill Stegbauer</option>
                <option value="Bobby Jones">Bobby Jones</option>
                <option value="Capt Richard Sides">Capt Richard Sides</option>
                <option value="Capt Sam Yount">Capt Sam Yount</option>
                <option value="Charles Southern">Charles Southern</option>
                <option value="Cheryl Stegbauer">Cheryl Stegbauer</option>
                <option value="David Stegbauer">David Stegbauer</option>
                <option value="Dennis Collins">Dennis Collins</option>
                <option value="Frank Hollomon">Frank Hollomon</option>
                <option value="Frank Stegbauer">Frank Stegbauer</option>
                <option value="Frank T Stegbauer">Frank T Stegbauer</option>
                <option value="Joanne Stegbauer">Joanne Stegbauer</option>
                {/* <option value="HR Kirtley">HR Kirtley</option> */}
                <option value="Kevin Conway">Kevin Conway</option>
                <option value="Larry Tilley">Larry Tilley</option>
                <option value="Laura Elizabeth">Laura Elizabeth</option>
                <option value="Laura Tamble">Laura Tamble</option>
                <option value="Mary Elizabeth">Mary Elizabeth</option>
                <option value="Paula Fortier">Paula Fortier</option>
                <option value="Robert Ingle">Robert Ingle</option>
                <option value="Scott Stegbauer">Scott Stegbauer</option>
                <option value="The Colonel">The Colonel</option>
                {/* <option value="The Colonel Cell">The Colonel Cell</option> */}
                <option value="Theresa Echols">Theresa Echols</option>
                <option value="Tommy Parrish">Tommy Parrish</option>               
                <option value="MV STC TEST">MV STC TEST</option>               
                <option value="STC MV Test2">STC MV Test2</option>
              </select>
              </div>
            </div>
        </div>
        <div className="row align-items-center" >    
            <div className="col-md-6">
                <div className="form-group">
                <label className="control-label">I am having problems with…</label>
                <select value={havingProblem} className="custom-select" onChange={selectProblem} disabled={disableProblem}>
                <option value=""></option>
                <option value="General Computer issues">General Computer issues (no internet, monitor issues, etc)</option>
                <option value="RosePoint">RosePoint</option>
                <option value="Email">Email</option>
                <option value="AIS">AIS</option>
                <option value="GPS">GPS</option>
                <option value="Cameras">Cameras</option>
                <option value="Printer/Scanner">Printer/Scanner</option>
                <option value="Radio">Radio</option>
                <option value="STC Ops">STC Ops</option>
                <option value="Voyage Planning Software (TowWorks)">Voyage Planning Software (TowWorks)</option>
                <option value="Other">Other</option>                              
              </select>
              </div>
            </div>
        </div>

        <div className="row align-items-center" >    
            <div className="col-md-6">
                <div className="form-group">
                <label className="control-label">Are you able to safely navigate?</label>
                <select value={safeNavigation} className="custom-select" onChange={selectNavigate} disabled={disableNavigate}>
                <option value=""></option>
                <option value="Yes">Yes</option>
                <option value="No">No</option>                                             
              </select>
              </div>
            </div>
        </div>
        <div className="row align-items-center" >          
            <div className="col-md-8">
                <div className="form-group">
                <label className="control-label">Describe the issue: </label>
                 <textarea name="description" className="form-control" 
                 onChange={(event)=>{changeDescribe(event)}}
                 value={describeTxt}
                 disabled={disableDescribe}
                 rows={5} height="auto"
                 ></textarea>
              </div>
            </div>
        </div>
        <div className="row align-items-center" >          
            <div className="col-md-4">
                <div className="form-group">
                <label className="control-label">Your Name: </label>
                <input
                  type="text"
                  name="yourname"
                  className="form-control"
                  placeholder="Please put your name."
                  disabled={disableName}
                  value={yourname}
                  onChange={(event)=>changeYourname(event)}
                  required
                />
              </div>
            </div>
        </div>
        <div className="row align-items-center" >          
            <div className="col-md-8">
            <button className="btn btn-dark" onClick={onSubmit} disabled={disableSubmit}>Submit</button>
            </div>
        </div>        
    </div>
      {/* <div className="layout container md-5">      
        <div className="content light">
         </div>
      </div> */}
      <Modal
        isOpen={modal}
        toggle={toggle}
        className={`light-modal modal-dialog modal-dialog-centered modal-dialog-zoom`}
      >
        {/* <ModalHeader toggle={toggle}></ModalHeader> */}
        <ModalBody>
          <h5>{notifyStr}</h5>          
        </ModalBody>
        <ModalFooter>         
          <Button color="success" onClick={toggle}>Ok</Button>
        </ModalFooter>
      </Modal>
    </div>
  )
}

const mapStateToProps = state => ({
  auth: state.auth,
  
})
const mapDispatchToProps = dispatch => ({ 
  resetAuth: () =>
    dispatch(resetAuth()),
})
export default connect(mapStateToProps, mapDispatchToProps)(Home)
