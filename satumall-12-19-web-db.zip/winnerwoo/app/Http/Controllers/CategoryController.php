<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Brand;
use Illuminate\Support\Facades\Validator;
use App\Models\Items;
use App\Models\Article;

class CategoryController extends Controller
{

    private  $current_model;
    public function __construct(){
        $this->current_model=new Category();
    }

    public function index(){
        $data=$this->current_model->getCategorylist();
        return view('admin.category_list')->withData($data);
    }

    public function addcategory($id){
        $model_list=$this->current_model->getmodellist();
        $category_list=$this->current_model->getallcategorylist(); // all category list

        $model_option="";


        foreach($model_list as $list){
            if($list->modelid==1)
                $model_option.="<option  value=".$list->modelid.">".$list->name."</option>";
            else
                $model_option.="<option  value=".$list->modelid.">".$list->name."</option>";
        }

        $count=0;
        $option_array=array();
        $option_list='';
        foreach($category_list as $item){
            // $item->order_cat;
            $order_group=explode(".",$item->order_cat);
             $sel_str="";
            if($id==$item->cateid)
                $sel_str="selected";
            if(count($order_group)==1){
                $option_list.="<option value=".$item->cateid." $sel_str >".$item->name."</option>";
            }
            else if(count($order_group)==2){
                $option_list.="<option value=".$item->cateid." $sel_str >"."   ├─ ".$item->name."</option>";
            }
            else if(count($order_group)==3){
              //  $option_list.="<option value=".$item->cateid." $sel_str>"."     │    ├─".$item->name."</option>";
            }
        }

        return view('admin.add_category', compact('model_option','option_list'));
    }

    public function editcategory($id){
        $model_list=$this->current_model->getmodellist();


        $get_cat_item=$this->current_model->getcalitem($id); // one  category array
        $category_list=Category::where('model',$get_cat_item->model)->get();

        $model_option="";
        foreach($model_list as $list){
            if($list->modelid==$get_cat_item->model)
                $model_option.="<option selected value=".$list->modelid.">".$list->name."</option>";
            else
                $model_option.="<option  value=".$list->modelid.">".$list->name."</option>";
        }
       // $parent_order=Category::select('*')->where('cateid','=',$id)->first();
        $count=0;
        $option_array=array();
        $option_list='';
        foreach($category_list as $item){
            // $item->order_cat;
            $order_group=explode(".",$item->order_cat);
             $sel_str="";
            if($get_cat_item->parentid==$item->cateid)
                $sel_str="selected";
            if(count($order_group)==1){
                $option_list.="<option value=".$item->cateid." $sel_str >".$item->name."</option>";

            }
            else if(count($order_group)==2){
                $option_list.="<option value=".$item->cateid." $sel_str >"."   ├─ ".$item->name."</option>";
            }
            else if(count($order_group)==3){
               // $option_list.="<option value=".$item->cateid." $sel_str>"."     │    ├─".$item->name."</option>";

            }
        }

        return view('admin.edit_category', compact('model_option','option_list','get_cat_item'));
    }

    public function savecategory(Request $request){

        $this->validate($request, [
            //'model_name'        => 'required',
            'category_name'         => 'required|max:255',
            ]);
        $setting=array(
            'thumb'=>'',
            'des'=>$request->description,
            'template'=>'',
            'content'=>'',
            'meta_title'=>'',
            'meta_keywords'=>'',
            'meta_description'=>'',
        );
        $setting=serialize($setting);
        $category=new Category();


        if(!is_null($request->uppper_name)){
            $parent_order=Category::select('*')->where('cateid','=',$request->uppper_name)->first();
            $last_id=Category::select('cateid')->orderBy('cateid','DESC')->first();
            $last_id=$last_id->cateid+1;
            $order_cat=$parent_order->order_cat.".0".$last_id;
        }
        else{
            $last_id=Category::select('cateid')->orderBy('cateid','DESC')->first();
            $last_id=$last_id->cateid+1;
            $order_cat="0".$last_id;
            $request->uppper_name=0;
        }


        $category->parentid=$request->uppper_name;
        $category->channel=0;
        $category->model=$request->model_name;
        $category->name=$request->category_name;
         $category->catdir=$request->category_name;
        $category->url="";
        $category->info=$setting;
        $category->order=1;
        $category->property=$request->class_attribute;
        $category->order_cat=$order_cat;
        $category->save();
        \Session::flash('success_message', trans('admin.success_add'));
        return redirect('panel/admin/cloud/category_management');

    }
    public function updatecategory(Request $request){

       $this->validate($request, [
           // 'uppper_name'         => 'required',
            'category_name'         => 'required|max:255',
          //  'category_english_name'         => 'required|max:255',
        ]);

        $setting=array(
            'thumb'=>'',
            'des'=>$request->description,
            'template'=>'',
            'content'=>'',
            'meta_title'=>'',
            'meta_keywords'=>'',
            'meta_description'=>'',
        );
        $setting=serialize($setting);

        if(!is_null($request->uppper_name)){
            $parent_order=Category::select('*')->where('cateid','=',$request->uppper_name)->first();
            $order_cat=$parent_order->order_cat.".0".$request->cate_id;

            Category::where( 'cateid', $request->cate_id )
                ->update( array(
                    'name'=>$request->category_name,"info"=>$setting,'model'=>$request->model_name,'parentid'=>$request->uppper_name,'info'=>$setting,'order_cat'=>$order_cat ) );
        }
        else{
            $last_id=Category::select('cateid')->orderBy('cateid','DESC')->first();
            $last_id=$last_id->cateid+1;
            $order_cat="0".$request->cate_id;


            Category::where( 'cateid', $request->cate_id )
                ->update( array(
                    'name'=>$request->category_name,"info"=>$setting,'model'=>$request->model_name,'parentid'=>0,'info'=>$setting,'order_cat'=>$order_cat  ) );
        }




        \Session::flash('success_message', trans('admin.success_update'));
        return redirect('panel/admin/cloud/category_management');
    }
    public function deletecategory($id){

        $flag=Items::where('cateid',$id)->get();
        if($flag->count()>0){
            \Session::flash('token_mismatch', "Because this category was being used in other record, can't delete it.");
            return redirect('panel/admin/cloud/category_management');
        }
        $flag=Article::where('cateid',$id)->get();
        if($flag->count()>0){
            \Session::flash('token_mismatch', "Because this category was being used in other record, can't delete it.");
            return redirect('panel/admin/cloud/category_management');
        }
        $model = Category::where('cateid', '=', $id)->delete();
        $model = Category::where('parentid', '=', $id)->delete();


        \Session::flash('success_message', trans('misc.success_delete'));
        return redirect('panel/admin/cloud/category_management');
    }
}
