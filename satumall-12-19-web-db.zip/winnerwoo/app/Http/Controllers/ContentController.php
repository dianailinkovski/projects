<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use App\Models\Article;
use App\Models\Category;
use Illuminate\Http\Request;
use Image;
//use Illuminate\Support\Facades\Validator;


class ContentController extends Controller
{



    public function index(){
        $data = Article::all();
        return view('admin.articlelist')->withData($data);
    }
    public function contentAddarticle()
    {
        $categorys=Category::select('*')->where('model','!=','1')->where('parentid','!=','0')->orderByRaw('order_cat ASC')->get();
               $option_list="";
               foreach($categorys as $item){
                   // $item->order_cat;
                   $order_group=explode(".",$item->order_cat);
                   $sel_str="";

                   if(count($order_group)==1){
                       $option_list.="<option value=".$item->cateid." $sel_str >".$item->name."</option>";
                   }
                   else if(count($order_group)==2){
                       $option_list.="<option value=".$item->cateid." $sel_str >"."   ├─ ".$item->name."</option>";
                   }
                   else if(count($order_group)==3){
                       $option_list.="<option value=".$item->cateid." $sel_str>"."   │    ├─".$item->name."</option>";
                   }
               }


        return view('admin.addarticle', compact('option_list'));
        //return view('welcome');
    }
    public function savecontentAddarticle(Request $request){
        $rules = array(
            'category'        => 'required',
            'article_title'        => 'required',
            'content'        => 'required',
        );
        $this->validate($request, $rules);

        $nowtime = date('Y_m_d');
        $temp="public/eshop/upload/temp/";
        $path="public/eshop/upload/content_img/".$nowtime."/";

        if (!file_exists($path)) {
            mkdir($path, 0777);

        }

        $picarry_flag=0;
        $picarr=array();
        if($request->hasFile('imglists')){
            $image_list=$request->file('imglists');

            foreach($image_list as $img){
                $extension              = $img->getClientOriginalExtension();
                $type_mime_shot   = $img->getMimeType();
                $sizeFile                 = $img->getSize();
                $thumbnail              = $nowtime.'-'.str_random(32).'.'.$extension;

                if( $img->move($temp, $thumbnail) ) {

                    $image = Image::make($temp.$thumbnail);

                    if(   $image->width() <200  && $image->height() < 200 ) {

                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);

                    } else {
                        $image->fit(300, 300)->save($temp.$thumbnail);

                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);
                    }

                }// End File

                $picarr[]=$path.$thumbnail;

            }
            $picarry_flag=1;

        }


        $thumb_flag=0;
        if( $request->hasFile('thumbnail') )	{

            $extension              = $request->file('thumbnail')->getClientOriginalExtension();
            $type_mime_shot   = $request->file('thumbnail')->getMimeType();
            $sizeFile                 = $request->file('thumbnail')->getSize();
            $thumbnail              = $nowtime.'-'.str_random(12).'.'.$extension;

            if( $request->file('thumbnail')->move($temp, $thumbnail) ) {

                $image = Image::make($temp.$thumbnail);

                if(  $image->width() > 640 && $image->height() > 640 ) {

                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);

                } else {
                    $image->fit(640, 640)->save($temp.$thumbnail);

                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);
                }

            }// End File
            $thumb_flag=1;
        } // HasFile

        $model=new Article();
        $model->cateid=$request->category;
       // $model->author=$request->author;
        $model->title=$request->article_title;
      if($thumb_flag)
            $model->thumb=$path.$thumbnail;

        //if($picarry_flag)
     //       $model->picarr=serialize($picarr);


      //  $model->keywords=$request->keywords;
      //  $model->description=$request->description;
        $model->content=stripslashes($request->content);
     //   $model->hit=$request->click_volume;
        $model->order=1;

        $posttime=date('Y-m-d H:i:s ');

        $model->posttime=$posttime;
        $model->save();

        \Session::flash('success_message', trans('admin.success_add'));
        return redirect('/panel/admin/content/article_list');
    }

    public function updatearticle(Request $request){
        $rules = array(
            'category'        => 'required',
            'article_title'        => 'required',
            'content'        => 'required',
        );
        $this->validate($request, $rules);

        $nowtime = date('Y_m_d');
        $temp="public/eshop/upload/temp/";
        $path="public/eshop/upload/content_img/".$nowtime."/";

        if (!file_exists($path)) {
            mkdir($path, 0777);

        }

        $picarry_flag=0;
        $picarr=array();
        if($request->hasFile('imglists')){
            $image_list=$request->file('imglists');

            foreach($image_list as $img){
                $extension              = $img->getClientOriginalExtension();
                $type_mime_shot   = $img->getMimeType();
                $sizeFile                 = $img->getSize();
                $thumbnail              = $nowtime.'-'.str_random(32).'.'.$extension;

                if( $img->move($temp, $thumbnail) ) {

                    $image = Image::make($temp.$thumbnail);

                    if(   $image->width() <200  && $image->height() < 200 ) {

                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);

                    } else {
                        $image->fit(300, 300)->save($temp.$thumbnail);

                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);
                    }

                }// End File

                $picarr[]=$path.$thumbnail;

            }
            $picarry_flag=1;

        }


        $thumb_flag=0;
        if( $request->hasFile('thumbnail') )	{

            $extension              = $request->file('thumbnail')->getClientOriginalExtension();
            $type_mime_shot   = $request->file('thumbnail')->getMimeType();
            $sizeFile                 = $request->file('thumbnail')->getSize();
            $thumbnail              = $nowtime.'-'.str_random(32).'.'.$extension;

            if( $request->file('thumbnail')->move($temp, $thumbnail) ) {

                $image = Image::make($temp.$thumbnail);

                if(  $image->width() > 1200 && $image->height() > 1000 ) {

                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);

                } else {
                    $image->fit(1200, 1200)->save($temp.$thumbnail);

                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);
                }

            }// End File
            $thumb_flag=1;
        } // HasFile


        $model=new Article();
        $model->cateid=$request->category;
        $model->author=$request->author;
        $model->title=$request->article_title;
        if($thumb_flag)
            $model->thumb=$path.$thumbnail;

        if($picarry_flag)
            $model->picarr=serialize($picarr);


        //$model->keywords=$request->keywords;
        $model->description=$request->description;
        $model->content=stripslashes($request->content);
       // $model->hit=$request->click_volume;
        $model->order=1;

        $posttime=date('Y-m-d H:i:s ');

        Article::where("id",'=', $request->key_id)
            ->update( array( 'cateid'=>$request->category,'title'=>$request->article_title,
                'content'=>stripslashes($request->content),
                'posttime'=>$posttime));

        if($thumb_flag){
            Article::where("id",'=', $request->key_id)
                ->update( array( 'thumb'=>$path.$thumbnail));
        }


        \Session::flash('success_message', trans('admin.success_update'));
        return redirect('/panel/admin/content/article_list');

    }

    /**
     */
    public function contentAddnews()
    {
      //  $data = Article::all();
        return view('admin.add_news');

    }
    public function contentEditnews()
    {
      //  $data = Article::all();
       // var_dump('dsfdsf');exit;
        //return view('admin.edit_news');

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id) {

        $data = Article::findOrFail($id);

        $categorys=Category::select('*')->where('model','!=','1')->where('parentid','!=','0')->orderByRaw('order_cat ASC')->get();

        $option_list="";
        foreach($categorys as $item){
            // $item->order_cat;
            $order_group=explode(".",$item->order_cat);
            $sel_str="";

            if($data->cateid==$item->cateid)
                $sel_str="selected";
            if(count($order_group)==1){
                $option_list.="<option value=".$item->cateid." $sel_str >".$item->name."</option>";
            }
            else if(count($order_group)==2){
                $option_list.="<option value=".$item->cateid." $sel_str >"."   ├─ ".$item->name."</option>";
            }
            else if(count($order_group)==3){
                $option_list.="<option value=".$item->cateid." $sel_str>"."   │    ├─".$item->name."</option>";
            }
        }

        return view('admin.editarticle',compact('option_list','data'));

    }//<--- End Method


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id){

        $lang = Article::findOrFail($id);

        $lang->delete();

        return redirect('panel/admin/content/article_list');

    }//<--- End Method




}
