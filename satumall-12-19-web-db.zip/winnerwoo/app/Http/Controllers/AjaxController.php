<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Brand;
use App\Models\Items;
use App\Models\Items2;


class AjaxController extends Controller
{


    public function index(){

        return view('admin.product_list');
    }




    /**
     * @param int id
     * @return response
     */
    public function getbrandlist(Request $request){

        $brandlist =Brand::where("cateid",'=',$request->id)->orderBy('order','DESC')->get();
        $op_str="";
        foreach($brandlist as $list){
            $op_str.="<option value=".$list->id.">".$list->name."</option>";
        }

        return $op_str;

    }

    public  function getupperlevel(Request $request){

        $category_list=Category::where("model","=",$request->id)->orderBy('order_cat','ASC')->get(); // all category list

        $model_option="";

        $id=$request->id;

        $count=0;
        $option_array=array();
        $option_list='<option value>New category</option>';
        foreach($category_list as $item){
            // $item->order_cat;
            $order_group=explode(".",$item->order_cat);
            $sel_str="";
            if($id==$item->cateid)
                $sel_str="selected";
            if(count($order_group)==1){
                $option_list.="<option value=".$item->cateid." $sel_str >".$item->name."</option>";
            }
            else if(count($order_group)==2){
                $option_list.="<option value=".$item->cateid." $sel_str >"."   ├─ ".$item->name."</option>";
            }
            else if(count($order_group)==3){
                //  $option_list.="<option value=".$item->cateid." $sel_str>"."     │    ├─".$item->name."</option>";
            }
        }

        return $option_list;

    }
    /**
     * sesssion register action
     * add cart from good_list.blade
     */
    public function addcartinlist(Request $request){

        // $request->session()->flush();
        $product_id=$request->product_id;
        $product_data=Items::select('*')->where('id','=',$product_id)->whereRaw('q_user is  null')->first();

         if(!is_object($product_data)){
             $this->deleteitemcart($request);
             return response()->json(['success'=>'failed','msg'=>'Product was already revealed.']);
         }

       $price=$product_data->money;
       $product_name=$product_data->title;
       $amount=1;
       $product_thumb=$product_data->thumb;

        $p_list=array("product_id"=>$product_id,"product_name"=>$product_name,"price"=>$price,"amount"=>$amount,"product_thumb"=>$product_thumb,"key_id"=>"cloud");

        //$request->session()->forget('p_list');
        $new_list=array();
        $temp=array();
        if($request->session()->has('p_list')){

            $old_list=   $request->session()->get('p_list');
            //$index=0;
            //foreach($old_list as $list){

            $exit_flag=1;
            for($index=0;$index<sizeof($old_list);$index++){
                if($old_list[$index]['product_id']==$product_id){
                    $old_list[$index]['amount']=$amount;
                    $exit_flag=0;
                }
                //$index++;
            }
            // $new_list=array_push($old_list,$p_list);
            if($exit_flag==1)
                $old_list[]=$p_list;

            $new_list=$old_list;

            $request->session()->put("p_list",$new_list);

        }

        else{

            $temp[]=$p_list;
            $request->session()->put("p_list",$temp);
            $new_list=$request->session()->get('p_list');
        }

        return response()->json(['success'=>'success','list'=>$new_list]);


    }

    /**
     * sesssion register action
     * add cart from internation.blade
     */
    public function addcartbyinternation(Request $request){

        // $request->session()->flush();
        $product_id=$request->product_id;
        $product_data=Items2::select('*')->where('id','=',$product_id)->first();


       $price=$product_data->money;
       $product_name=$product_data->title;
       $amount=$request->amount;
       $product_thumb=$product_data->thumb;

        $p_list=array("product_id"=>$product_id,"product_name"=>$product_name,"price"=>$price,"amount"=>$amount,"product_thumb"=>$product_thumb,"key_id"=>"internation");

        //$request->session()->forget('p_list');
        $new_list=array();
        $temp=array();
        if($request->session()->has('p_list')){

            $old_list=   $request->session()->get('p_list');
            //$index=0;
            //foreach($old_list as $list){

            $exit_flag=1;
            for($index=0;$index<sizeof($old_list);$index++){
                if($old_list[$index]['product_id']==$product_id){
                    $old_list[$index]['amount']=$amount;
                    $exit_flag=0;
                }
                //$index++;
            }
            // $new_list=array_push($old_list,$p_list);
            if($exit_flag==1)
                $old_list[]=$p_list;

            $new_list=$old_list;

            $request->session()->put("p_list",$new_list);

        }

        else{

            $temp[]=$p_list;
            $request->session()->put("p_list",$temp);
            $new_list=$request->session()->get('p_list');
        }


        return response()->json($new_list);


    }
    /**
     * sesssion register action
     * add cart
     */
    public function addcartsession(Request $request){

       // $request->session()->flush();
        $product_id=$request->product_id;
        $price=$request->price;
        $product_name=$request->product_name;
        $amount=$request->amount;
        $product_thumb=$request->product_thumb;
        $p_list=array("product_id"=>$product_id,"product_name"=>$product_name,"price"=>$price,"amount"=>$amount,"product_thumb"=>$product_thumb,"key_id"=>"cloud");

        $product_data=Items::select('*')->where('id','=',$product_id)->whereRaw('q_user is  null')->first();

        if(!is_object($product_data)){

            $this->deleteitemcart($request);

            return response()->json(['success'=>'failed','msg'=>'Product was already revealed.']);
        }

       //$request->session()->forget('p_list');
        $new_list=array();
        $temp=array();
        if($request->session()->has('p_list')){

            $old_list=   $request->session()->get('p_list');
            //$index=0;
            //foreach($old_list as $list){

            $exit_flag=1;
            for($index=0;$index<sizeof($old_list);$index++){
                if($old_list[$index]['product_id']==$product_id){
                    $old_list[$index]['amount']=$amount;
                    $exit_flag=0;
                }
                //$index++;
            }
           // $new_list=array_push($old_list,$p_list);
            if($exit_flag==1)
             $old_list[]=$p_list;

            $new_list=$old_list;

            $request->session()->put("p_list",$new_list);

        }

        else{

            $temp[]=$p_list;
            $request->session()->put("p_list",$temp);
            $new_list=$request->session()->get('p_list');
        }


        return response()->json(['success'=>'success','list'=>$new_list]);
    }

    public function deletecart(Request $request){
        $product_id=$request->product_id;

        $new_list=array();
        if($request->session()->has('p_list')){
            $old_list=   $request->session()->get('p_list');
            for($index=0;$index<sizeof($old_list);$index++){
                if($old_list[$index]['product_id']==$product_id){
                    array_splice( $old_list, $index,1 );
                }

            }
            $request->session()->put("p_list",$old_list);
            $new_list=$old_list;
        }
        return response()->json($new_list);
        //return $product_id;

    }

    /**
     * delete product item, if it was revealed .
     */
    public function deleteitemcart($request){
        $product_id=$request->product_id;

        $new_list=array();
        if($request->session()->has('p_list')){
            $old_list=   $request->session()->get('p_list');
            for($index=0;$index<sizeof($old_list);$index++){
                if($old_list[$index]['product_id']==$product_id){
                    array_splice( $old_list, $index,1 );
                }

            }
            $request->session()->put("p_list",$old_list);
            $new_list=$old_list;
        }

        //return $product_id;

    }

    public function savepaycartlist(Request $request){
       $request->session()->forget('cloud_paycarts');
        $cloud_str=$request->cloud_str; // cloud products pay list

        if($cloud_str!=""){
            $temp_arr=explode("ed",$cloud_str);
            $pay_list=array();
            for($i=0;$i<sizeof($temp_arr)-1;$i++){
                $pro_amount=explode("jk",$temp_arr[$i]);
                $pay_list[]=array("product_id"=>$pro_amount[0],"amount"=>$pro_amount[1]);

            }
            $request->session()->put("cloud_paycarts",$pay_list);
        }



        $request->session()->forget('inter_paycarts');
        $inter_str=$request->inter_str; // internation products pay list

        if($inter_str!=''){
            $temp_arr=explode("ld",$inter_str);
            $pay_list=array();
            for($i=0;$i<sizeof($temp_arr)-1;$i++){
                $pro_amount=explode("io",$temp_arr[$i]);
                $pay_list[]=array("product_id"=>$pro_amount[0],"amount"=>$pro_amount[1]);

            }
            $request->session()->put("inter_paycarts",$pay_list);
        }

        return "success";

    }

}
