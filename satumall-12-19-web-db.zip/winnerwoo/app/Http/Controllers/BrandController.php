<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Items;
use App\Models\Brand;


//use Illuminate\Support\Facades\Validator;
//use Auth, URL, DB, Validator, Session;

class BrandController extends Controller
{



    public function index(){
       //$data = Brand::all();
        $items_model = new Brand();
        $data=$items_model->getBrandlist();
        return view('admin.brand_list')->withData($data);
    }

    public function Addbrand()
    {
        $items_model = new Items();
        $categorys=$items_model->getCategory();
        $count=0;
        $option_array=array();
        foreach($categorys as $item){
           // $item->order_cat;
            $order_group=explode(".",$item->order_cat);

            if(count($order_group)==1){
                $option= array( "id" => $item->cateid, "value" => $item->name);
               array_push($option_array,$option);
            }
            else if(count($order_group)==2){
                $option= array( "id" => $item->cateid, "value" => "├─ ".$item->name);
                array_push($option_array,$option);
            }
            else if(count($order_group)==3){
                $option= array( "id" => $item->cateid, "value" => "│  ├─".$item->name);
                array_push($option_array,$option);
            }
        }
        return view('admin.add_brands', compact('option_array'));

        //return view('welcome');
    }



    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id) {

        $data = Brand::findOrFail($id);

        $items_model = new Items();

        $categorys=$items_model->getCategory();
        $count=0;
        $option_array=array();

        foreach($categorys as $item){
            // $item->order_cat;
            $order_group=explode(".",$item->order_cat);

            if(count($order_group)==1){
                $option= array( "id" => $item->cateid, "value" => $item->name);
                array_push($option_array,$option);
            }
            else if(count($order_group)==2){
                $option= array( "id" => $item->cateid, "value" => "├─ ".$item->name);
                array_push($option_array,$option);
            }
            else if(count($order_group)==3){
                $option= array( "id" => $item->cateid, "value" => "│  ├─".$item->name);
                array_push($option_array,$option);
            }
        }

        return view('admin.edit_brands', compact('option_array','data'));
       // return view('admin.editarticle')->withData($data);

    }
    /**
     * @param int id
     * @return response
     */
    public function getbrands(Request $request){
        $data = $request->all();
        return "fdgfd";
    }
    //<--- End Method
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id){


        $flag=Items::where('brandid',$id)->get();
        if($flag->count()>0){
            \Session::flash('token_mismatch', "Because this category was being used in other record, can't delete it.");
            return redirect('panel/admin/cloud/brand_manage');
        }


        $lang = Brand::findOrFail($id);
        $lang->delete();
        \Session::flash('success_message', trans('admin.success_delete'));
        return redirect('panel/admin/cloud/brand_manage');

    }//<--- End Method

    public function savebrand(Request $request){
        $rules = array(
            'category_id'        => 'required',
            'brand_name'        => 'required',

        );
        $this->validate($request, $rules);

        $items_model = new Brand();
        $items_model->cateid=$request->category_id;
        $items_model->name=$request->brand_name;
        $items_model->order= ($request->order!='')?$request->order:1;
        $items_model->save();
        \Session::flash('success_message', trans('admin.success_add'));
        return redirect('panel/admin/cloud/brand_manage');
    }
    public function update(Request $request){
        $rules = array(
            'category_id'        => 'required',
            'brand_name'        => 'required',

        );
        $this->validate($request, $rules);

        $items_model = new Brand();
        Brand::where("id",'=',$request->brand_id)
        ->update( array( 'cateid' => $request->category_id,"name"=>$request->brand_name,"order"=>($request->sort!='')?$request->sort:1));
        \Session::flash('success_message', trans('admin.success_update'));
        return redirect('panel/admin/cloud/brand_manage');
    }

}
