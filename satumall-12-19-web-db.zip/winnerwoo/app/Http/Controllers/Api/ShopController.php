<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Items;
use App\Models\frontend\goreview;
use App\Models\Slide;
use App\Models\membergorecord;
use App\User;
use Illuminate\Support\Facades\DB;
use Image;
class ShopController extends Controller
{


    public function index(){

        $upcoming=Items::select('id','sid','title','money','yunjiage','zongrenshu','canyurenshu','shenyurenshu','thumb','picarr','qishu')
        ->where("shenyurenshu","!=",'0')
            ->whereRaw("q_uid is null")->orderBy("shenyurenshu","ASC")->paginate(10);

        foreach($upcoming as $row){

            $row->picarr=unserialize($row->picarr);
            $record=membergorecord::select('gonumber','uphoto')->where('shopid',$row->id)->get();
            $row->record=$record;
        }

        $newlist =Items::select('id','sid','title','money','yunjiage','zongrenshu','canyurenshu','shenyurenshu','thumb','picarr','qishu')->where("scene","!=","1")->whereRaw("q_end_time is null")->where("q_showtime","=","N")

            ->where("shenyurenshu","!=","0")->orderBy("created_at","DESC")->paginate(70);

        foreach($newlist as $row){
            $row->picarr=unserialize($row->picarr);
            $record=membergorecord::select('gonumber','uphoto')->where('shopid',$row->id)->get();
            $row->record=$record;
        }

        $pricelistbydesc=Items::select('id','sid','title','money','yunjiage','zongrenshu','canyurenshu','shenyurenshu','thumb','picarr','qishu')->whereRaw("q_end_time is null")
            ->where("shenyurenshu","!=","0")->orderBy("money","DESC")->paginate(70);
        foreach($pricelistbydesc as $row){
            $row->picarr=unserialize($row->picarr);
            $record=membergorecord::select('gonumber','uphoto')->where('shopid',$row->id)->get();
            $row->record=$record;
        }

        $pricelistbyasc=Items::select('id','sid','title','money','yunjiage','zongrenshu','canyurenshu','shenyurenshu','thumb','qishu','picarr')->whereRaw("q_end_time is null")
            ->where("shenyurenshu","!=","0")->orderBy("money","ASC")->paginate(70);
        foreach($pricelistbyasc as $row){
            $row->picarr=unserialize($row->picarr);
            $record=membergorecord::select('gonumber','uphoto')->where('shopid',$row->id)->get();
            $row->record=$record;
        }

       /**
        $announcement=Items::select("*")->whereRaw("q_end_time is not null")
            ->where("q_showtime","=","N")
            ->orderBy("q_end_time","DESC")
            ->paginate(8);
        * **/

        $reivews=goreview::select('*')->where('agree','!=','0')->where('image_number','!=','0')->orderBy('updated_at','DESC')->paginate(10);
        foreach($reivews as $row){
            $row->pic_arr=unserialize($row->pic_arr);

            $product=Items::select('title','money','thumb','qishu','q_end_time','q_user_code','q_user')->where("id",$row->product_id)->first();
            if(is_object($product))
                $product->time=microt($product->q_end_time);

            $product->q_user=unserialize($product->q_user);

            $row->pinf=$product;
            $gonumber=membergorecord::where('shopid',$row->product_id)->where('uid',$row->user_id)->sum('gonumber');
            $row->spent=$gonumber;

        }

        $record=membergorecord::select('gonumber','huode','shopname','username')->orderBy('updated_at','DESC')->paginate(30);

        $slides=Slide::where('visible','1')->orderBy('order','ASC')->get();

        return response()->json(['upcoming'=>$upcoming,'newlist'=>$newlist,'itembypricedesc'=>$pricelistbydesc,'itembypriceasc'=>$pricelistbyasc,'reviews'=>$reivews,'record'=>$record,'slide'=>$slides]);
    }

    public  function userdata(Request $request){
        $mobile_number=$request->phone;


        User::where('mobile_number',$mobile_number)->update(array('status'=>'active'));
        $is_user=User::where('mobile_number',$mobile_number)->first();
        if(!is_object($is_user)){
            return response()->json([
                'success' => 'failed','msg' => "Phone number not exists.",
            ]);
        }

        return response()->json([
            'success' => 'success','user' => $is_user->toArray()
        ]);
    }

    public  function upcoming(Request $request){
        $upcoming=Items::select('id','sid','title','money','yunjiage','zongrenshu','canyurenshu','shenyurenshu','thumb','qishu','picarr')
            ->where("shenyurenshu","!=","0")
            ->whereRaw("q_uid is null")->orderBy("shenyurenshu","ASC")->get();
        foreach($upcoming as $row){
            $row->picarr=unserialize($row->picarr);
            $record=membergorecord::select('gonumber','uphoto')->where('shopid',$row->id)->get();
            $row->record=$record;
        }
        return response()->json(['upcoming'=>$upcoming,'success'=>'success']);

    }
    public function detaildata(Request $request){
        $item_id=$request->product_id;
        $qishu=$request->qishu;

        $product=Items::select('id','sid','title','money','yunjiage','zongrenshu','canyurenshu','shenyurenshu','thumb','qishu')->where("id",$item_id)->first();
        $record=membergorecord::select('*')->where('shopid',$item_id)->where('shopqishu',$qishu)->orderBy('id','DESC')->get();

        foreach($record as $row){
            $row->time=microt($row->time);
        }
        return response()->json(['success'=>'success',"record"=>$record,"product"=>$product]);

    }
    public function getreviewlistbyproduct($sid){

        $reivews=goreview::select('*')->where('agree','!=','0')->where('image_number','!=','0')->where('sid',$sid)->orderBy('updated_at','DESC')->get();
        foreach($reivews as $row){
            $row->pic_arr=unserialize($row->pic_arr);

            $product=Items::select('title','money','thumb','qishu','q_end_time','q_user_code')->where("id",$row->product_id)->first();
            if(is_object($product))
                $product->time=microt($product->q_end_time);

            $row->pinf=$product;
            $gonumber=membergorecord::where('shopid',$row->product_id)->where('uid',$row->user_id)->sum('gonumber');
            $row->spent=$gonumber;

        }

        return response()->json(['success'=>'success',"reviews"=>$reivews]);


    }

    public  function allreviews(){
        $reivews=goreview::select('*')->where('agree','!=','0')->orderBy('updated_at','DESC')->get();
        foreach($reivews as $row){
            $row->pic_arr=unserialize($row->pic_arr);

            $product=Items::select('title','money','thumb','qishu','q_end_time','q_user_code')->where("id",$row->product_id)->first();
            if(is_object($product))
                $product->time=microt($product->q_end_time);

            $row->pinf=$product;
            $gonumber=membergorecord::where('shopid',$row->product_id)->where('uid',$row->user_id)->sum('gonumber');
            $row->spent=$gonumber;

        }

        return response()->json(['success'=>'success',"reviews"=>$reivews]);

    }

    public function getrecentwinners(){
        $wonlist=Items::select('id','sid','title','money','yunjiage','q_user_code','thumb','qishu','picarr','q_user','q_end_time')->whereRaw( "q_uid is not null and q_showtime='N'")->orderBy('q_end_time','DESC')->get();

        foreach($wonlist as $row){
            $row->q_user=unserialize($row->q_user);
            $row->q_end_time=microt($row->q_end_time);
            $row->picarr=unserialize($row->picarr);
            $record=membergorecord::select('gonumber','uphoto','uid')->where('shopid',$row->id)->get();
            $row->record=$record;

        }
        return response()->json(['success'=>'success',"wonlist"=>$wonlist]);
    }

    public function getnewperiod($sid){
        if($sid==''){
            return response()->json(['success'=>'failed']);
        }

        $nextperiod=Items::select('id','sid','title','money','yunjiage','zongrenshu','canyurenshu','shenyurenshu','thumb','picarr','qishu')->whereRaw("q_end_time is null")->where('sid',$sid)->orderBy('id','DESC')->first();

        if(!is_object($nextperiod)){
            return response()->json(['success'=>'failed']);
        }

        $nextperiod->picarr=unserialize($nextperiod->picarr);
        $record=membergorecord::select('gonumber','uphoto')->where('shopid',$nextperiod->id)->get();
        $nextperiod->record=$record;
        return response()->json(['success'=>'success',"nextperiod"=>$nextperiod]);
    }

    public function getpreviouswinner($sid){

        if($sid==''){
            return response()->json(['success'=>'failed']);
        }

        $winnerlist=Items::select('id','sid','title','money','yunjiage','q_user_code','thumb','qishu','picarr','q_user','q_end_time')->where("sid",$sid)->whereRaw("q_end_time is not null")->orderBy('qishu','DESC')->get();
        foreach($winnerlist as $row){
            $row->q_user=unserialize($row->q_user);
            $row->q_end_time=microt($row->q_end_time);
            $row->picarr=unserialize($row->picarr);
            $record=membergorecord::select('gonumber','uphoto','uid')->where('shopid',$row->id)->get();
            $row->record=$record;

        }
        return response()->json(['success'=>'success',"winnerlist"=>$winnerlist]);

    }

    public  function getmyparticipation($uid){
        //if($request->uid=''){
       //     return response()->json(['success'=>'failed']);
       // }
        $uid=($uid=='')?0:$uid;
        $recordlist=membergorecord::selectRaw('shopid')->where('uid',$uid)->groupBy('shopid','shopqishu')->orderBy('time','DESC')->get();

        foreach($recordlist as $record){
                $row=Items::select('id','sid','title','money','yunjiage','zongrenshu','canyurenshu','shenyurenshu','q_uid','q_user_code','thumb','qishu','picarr','q_user','q_end_time')
                ->where("id",$record->shopid)->first();


                $row->q_user=is_null($row->q_user)?$row->q_user:unserialize($row->q_user);
                $row->q_end_time=is_null($row->q_end_time)?$row->q_end_time:microt($row->q_end_time);
                $row->picarr=unserialize($row->picarr);

                $record_2=membergorecord::select('gonumber','uphoto','uid')->where('shopid',$row->id)->get();
                $row->record=$record_2;
                $record->id=$record->shopid;
                $record->pitem=$row;
        }

        $reivews=goreview::select('*')->where('agree','!=','0')->where('user_id',$uid)->orderBy('updated_at','DESC')->get();
        foreach($reivews as $row){
            $row->pic_arr=unserialize($row->pic_arr);

            $product=Items::select('title','money','thumb','qishu','q_end_time','q_user_code')->where("id",$row->product_id)->first();
            if(is_object($product))
                $product->time=microt($product->q_end_time);

            $row->pinf=$product;
            $gonumber=membergorecord::where('shopid',$row->product_id)->where('uid',$row->user_id)->sum('gonumber');
            $row->spent=$gonumber;

        }

        return response()->json(['success'=>'success',"recordlist"=>$recordlist,"reviewlist"=>$reivews]);

    }

    public  function getmywinningrecord($uid){
        $uid=($uid=='')?0:$uid;

        $wonlist=Items::select('id','sid','title','money','yunjiage','zongrenshu','canyurenshu','shenyurenshu','q_user_code','thumb','qishu','picarr','q_user','q_uid','q_end_time')
            ->where("q_uid",$uid)->get();

        foreach($wonlist as $row){
            $row->q_user=unserialize($row->q_user);
            $row->q_end_time=microt($row->q_end_time);
            $row->picarr=unserialize($row->picarr);
            $record=membergorecord::select('gonumber','uphoto','uid')->where('shopid',$row->id)->where('uid',$uid)->get();
            $row->record=$record;

        }


        return response()->json(['success'=>'success',"winningrecord"=>$wonlist]);

    }

   public function getmyreview($uid){
       $uid=($uid=='')?0:$uid;
       $reivews=goreview::select('*')->where('agree','!=','0')->where('user_id',$uid)->orderBy('updated_at','DESC')->get();
       foreach($reivews as $row){
           $row->pic_arr=unserialize($row->pic_arr);

           $product=Items::select('title','money','thumb','qishu','q_end_time','q_user_code')->where("id",$row->product_id)->first();
           if(is_object($product))
               $product->time=microt($product->q_end_time);

           $row->pinf=$product;
           $gonumber=membergorecord::where('shopid',$row->product_id)->where('uid',$row->user_id)->sum('gonumber');
           $row->spent=$gonumber;

       }


       $unshare=DB::table('go_shoplist')
           ->selectRaw("go_shoplist.id,go_shoplist.sid,go_shoplist.title,go_shoplist.money,go_shoplist.q_user_code,
           go_shoplist.thumb,go_shoplist.qishu,go_shoplist.q_user,go_shoplist.q_uid,go_shoplist.q_end_time,go_shoplist.picarr")
           ->leftJoin('go_review', 'go_shoplist.id', '=', 'go_review.product_id')
          ->whereRaw("go_shoplist.q_end_time IS NOT NULL AND go_shoplist.q_uid=".$uid." AND go_review.created_at IS  null")
           ->get();


       foreach($unshare as $row){
           $row->q_user=unserialize($row->q_user);
           $row->q_end_time=microt($row->q_end_time);
           $row->picarr=unserialize($row->picarr);
           $gonumber=membergorecord::where('shopid',$row->id)->where('uid',$uid)->sum('gonumber');
           $record=membergorecord::select('gonumber','uphoto','uid')->where('shopid',$row->id)->get();
           $row->record=$record;
       }

       return response()->json(['success'=>'success',"reviewlist"=>$reivews,"unshare"=>$unshare]);

   }
    /**
     * api for review
     */
    public  function givereview(Request $request){
        $picarr=array();
        $pic_num=0;


        if($request->hasFile('photo')){
            $image_list=$request->file('photo');
            $nowtime = date('Y_m_d');
            $temp="public/eshop/upload/temp/";
            $path="public/eshop/upload/shaidan/".$nowtime."/";
            if (!file_exists($path)) {
                mkdir($path, 0777);

            }

            foreach($image_list as $img){
                $pic_num++;
                //$extension              = $img->getClientOriginalExtension();
                //$type_mime_shot   = $img->getMimeType();
               // $sizeFile                 = $img->getSize();
                //$thumbnail              = str_random(13).'.'.$extension;
                $thumbnail              = str_random(13).'.'."jpg";

                if( $img->move($temp, $thumbnail) ) {

                    $image = Image::make($temp.$thumbnail);


                    if(   $image->width() <640  && $image->height() <640 ) {

                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);

                    } else {
                        $image->fit(640, 640)->save($temp.$thumbnail);

                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);
                    }

                    $picarr[]=$path.$thumbnail;

                }// End File

                //$piclist=serialize($picarr);
            }
        }

        $review_model=new goreview();
        $review_model->user_id=$request->userid;
        $review_model->product_id=$request->product_id;
        $review_model->user_email=$request->user_email;
        $review_model->mobile_number=get_user_name($request->mobile_number,'mobile');
        $review_model->user_photo=$request->user_photo;
        $review_model->score=$request->score;
        $review_model->feedback=$request->feedback;
        $review_model->time= sprintf("%.3f",microtime(true));
        $review_model->pic_arr=serialize($picarr);
        $review_model->image_number=$pic_num;
        $review_model->sid=$request->sid;
        $review_model->save();

        return response()->json(['success'=>"success"]);


    }
     public function saveprofile(Request $request){

         $nowtime = date('Y_m_d');
         $temp="public/eshop/upload/temp/";
         $path="public/avatar/";
         $file_flag=0;
         if( $request->hasFile('photo') )	{

            // $extension              = $request->file('thumbnail')->getClientOriginalExtension();
             $thumbnail              = $nowtime.'-'.str_random(18).'.'."jpg";

             if( $request->file('photo')->move($temp, $thumbnail) ) {

                 $image = Image::make($temp.$thumbnail);

                 $image->fit(180, 180)->save($temp.$thumbnail);
                 \File::copy($temp.$thumbnail, $path.$thumbnail);
                 \File::delete($temp.$thumbnail);

                 $user_photo=$path.$thumbnail;
                 $file_flag=1;
             }// End File
         } // HasFile


         $user_db=User::where('id',$request->user_id)->update(array('name'=>$request->first_name,'last_name'=>$request->last_name,
             "address"=>$request->shipping_address,"city"=>$request->city,"zip_code"=>$request->postal_code,"email"=>$request->email));

         if($file_flag){
             $user_db=User::where('id',$request->user_id)->update(array("avatar"=>$user_photo));
         }


         return response()->json(['success'=>"success"]);
     }

    public function expenserecord(Request $request){
        $uid=$request->uid;
        $expenselist = DB::table('go_member_go_record')
            ->select('*')
            ->where('uid',$uid)
             ->orderBy('time','DESC')
            ->get();
        foreach($expenselist as $row){
            $row->time=microt($row->time);
        }
        return response()->json(['success'=>'success',"expenselist"=>$expenselist]);
    }
    public function rechargerecord(Request $request){
        $uid=$request->uid;
        $rechargelist = DB::table('go_member_account')
            ->select('time','money')
            ->whereRaw("go_member_account.content='Card charge'  AND go_member_account.type='1'")
             ->where("uid",$uid)
            ->orderBy('time','DESC')
            ->get();
        foreach($rechargelist as $row){
            $row->time= date("Y-m-d H:i:s",$row->time);
            $row->moneycount=$row->money;
        }
        return response()->json(['success'=>'success',"rechargelist"=>$rechargelist]);
    }

    public  function search($str){


        $result=Items::select('id','sid','title','money','yunjiage','zongrenshu','canyurenshu','shenyurenshu','thumb','picarr','qishu')
            ->whereRaw("q_uid is null")->whereRaw("title like '%".$str."%' ")->orderBy("title","ASC")->get();

        foreach($result as $row){

            $row->picarr=unserialize($row->picarr);
            $record=membergorecord::select('gonumber','uphoto')->where('shopid',$row->id)->get();
            $row->record=$record;
        }

        return response()->json(['success'=>'success',"searchresult"=>$result]);

    }

    public function notificationrecord(Request $request){
        $uid=$request->uid;
        $wonlist=Items::select('id','sid','title','money','yunjiage','q_user_code','thumb','qishu','picarr','q_user','q_end_time','feedback')
            ->where( "q_uid",$uid)->orderBy('q_end_time','DESC')->get();

        foreach($wonlist as $row){
            $row->q_user=unserialize($row->q_user);
            $row->q_end_time=microt($row->q_end_time);
            $row->picarr=unserialize($row->picarr);
            $record=membergorecord::select('gonumber','uphoto','uid')->where('shopid',$row->id)->get();
            $row->record=$record;

        }
        return response()->json(['success'=>'success',"notificationlist"=>$wonlist]);
    }

     public function readmessage(Request $request){
         $pid=$request->pid==''?0:$request->pid;
         Items::where('id',$pid)->update(array("feedback"=>0));
         $wonlist=Items::select('id','sid','title','money','yunjiage','q_user_code','thumb','qishu','picarr','q_user','q_end_time','feedback')
             ->where( "q_uid",$request->uid)->orderBy('q_end_time','DESC')->get();

         foreach($wonlist as $row){
             $row->q_user=unserialize($row->q_user);
             $row->q_end_time=microt($row->q_end_time);
             $row->picarr=unserialize($row->picarr);
             $record=membergorecord::select('gonumber','uphoto','uid')->where('shopid',$row->id)->get();
             $row->record=$record;

         }
         return response()->json(['success'=>'success',"notificationlist"=>$wonlist]);
     }

    public function getlatestrecord(Request $request){
        $uid=$request->uid;
        $pid=$request->pid;
        $record =membergorecord::where('uid',$uid)->where('shopid',$pid)->orderBy('id','DESC')->skip(0)->take(1)->first();
        if(!is_object($record)){
            return response()->json(['success'=>'faild',"msg"=>"there is nothing a record!"]);
        }
        $record->time=microt($record->time);
        return response()->json(['success'=>'success',"latestrecord"=>$record]);




    }
}
