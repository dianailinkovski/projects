<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\User;
use Illuminate\Support\Facades\Hash;
class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;


    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }


    public function login(Request $request){

        if(\Auth::attempt(['mobile_number' => $request->email ,'password' =>$request->password])){
            $user = $this->guard()->user();
            $user->generateToken();
            return response()->json([
                'success'=>'success','user' => $user->toArray(),$user->successStatus
            ]);

        }else{
            return response()->json(['error'=>'Unauthorised'], 200);
        }


    }

    public function  signup(Request $request){
        $token = str_random(75);
        $regIpAddress = $_SERVER['REMOTE_ADDR'];
        $verify_code=generateRandomString(3)."-".generateRandomString(3);
        $time=time();
        $mobile_number=$request->phone;
        $password=$request->password;

        $is_user=User::where('mobile_number',$mobile_number)->first();
        if(is_object($is_user)){
            return response()->json([
                'success' => 'failed','msg' => "Phone number already exists.",
            ]);
        }

        $api_token=md5(uniqid(''));
        User::create([

            'mobile_number' => $mobile_number,
            'password' => Hash::make($password),
            'token' => $token,
            'remember_token' => $token,
            'user_ip' => $regIpAddress,
            'sign_in_time' => $time,
            'login_time' =>$time,
            'time' => $time,
            'api_token' =>$api_token,
        ]);



        $return=gw_send_sms(getenv('apiusername'), getenv('apipassword'), getenv('senderid'), "6".$mobile_number, $verify_code);


        if($return=='success'){
            return response()->json([
                'success' => 'success','verify_code' => $verify_code,'token'=>$api_token
            ]);
        }
        else{
            return response()->json([
                'success' => 'failed','msg' => "Wrong phone number.",
            ]);
        }
    }
    public function resend(Request $request){
        $verify_code=generateRandomString(3)."-".generateRandomString(3);
        $mobile_number=$request->phone;
        $is_user=User::where('mobile_number',$mobile_number)->first();
        if(!is_object($is_user)){
            return response()->json([
                'success' => 'failed','msg' => "Phone number does not exists.",
            ]);
        }

        $return=gw_send_sms(getenv('apiusername'), getenv('apipassword'), getenv('senderid'), "6".$mobile_number, $verify_code);

        if($return=='success'){
            return response()->json([
                'success' => 'success','verify_code' => $verify_code,
            ]);
        }
        else{
            return response()->json([
                'success' => 'failed','msg' => "Wrong phone number.",
            ]);
        }

    }
    public function resetpassword(Request $request){
        $mobile_number=$request->phone;
        $password=$request->password;

        $is_user=User::where('mobile_number',$mobile_number)->first();
        if(!is_object($is_user)){
            return response()->json([
                'success' => 'failed','msg' => "Phone number not exists.",
            ]);
        }

        User::where('mobile_number',$mobile_number)->update(array('password'=>  Hash::make($password)));

        return response()->json([
            'success' => 'success'
        ]);

    }
    public function test(){
        return response()->json([
            'user' => 'test result',
        ]);
    }

}
