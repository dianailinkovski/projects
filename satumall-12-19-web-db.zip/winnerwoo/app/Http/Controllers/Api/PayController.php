<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Items;
use App\Models\frontend\goreview;
use App\Models\membergorecord;
use App\Models\frontend\goodlist;
use App\User;
use App\Models\memberaccount;
use Illuminate\Support\Facades\DB;
use Image;
use App\Models\shopcodes;
use IPay88;
use Twilio\Rest\Client;
class PayController extends Controller
{

    protected $_merchantCode;
    protected $_merchantKey;

    public $fufen ;
    public $fufen_to_money = 0;
    public $dingdancode='';//ooo
    private $goods_count_num=0;//ooo

    private $Moneycount=0;
    private $cloud_productlist;
    private $generaldingdancode;

    private $product_id=0;
    private $amount=1; // total quantity
    private $user_id=0;
    private $p_type="";
    private $shop=array();
    private $user_inf=array();
    public function __construct()
    {
        //parent::__construct();
        $this->_merchantCode = 'M17669'; //MerchantCode confidential
        $this->_merchantKey = 'SYT3n1nSjc'; //MerchantKey confidential
    }
    public function index(){

        return response()->json(['upcoming'=>$upcoming,'newlist'=>$newlist,'itembypricedesc'=>$pricelistbydesc,'itembypriceasc'=>$pricelistbyasc,'reviews'=>$reivews,'record'=>$record]);
    }

    public function pay(Request $request){

        $this->product_id=$request->pid;
        $this->amount=$request->amount?$request->amount:1;
        $this->user_id=$request->uid;
        $this->p_type=$request->type;


        $fufen=0;
        $this->fufen=$fufen;

        /** pay record function */
        $Moenycount = 0;
        if($this->p_type=='cloud'){
            $yunlist=Items::select('*')->where('id','=',$this->product_id)->whereRaw('q_end_time is  null')->first();
            if(!is_object($yunlist)){
                return response()->json(['success'=>"failed","msg"=>"Product was already revealed for Winner","result"=>"no_product"]);
            }
            if($this->amount>$yunlist->shenyurenshu){
                $this->amount=$yunlist->shenyurenshu;
            }
            $cart_gorenci = $this->amount ? $this->amount : 1;

            if($cart_gorenci >= $yunlist->shenyurenshu){
                $cart_gorenci = $yunlist->shenyurenshu;
            }
            $cart_xiaoji = substr(sprintf("%.3f",$yunlist->yunjiage*$cart_gorenci),0,-1);
            $Moenycount += $cart_xiaoji;
        }
        $this->Moneycount=substr(sprintf("%.3f",$Moenycount),0,-1);

        /** pay function go_pay*/

        $user_inf=User::select('*')->where('id','=',$this->user_id)->first();
        $this->user_inf=$user_inf;
        if($user_inf->money>=$this->Moneycount){

            $pay_1 =  $this->pay_bag();

            if($pay_1){

                // dd('success ful account payment');

                return response()->json(['success'=>"success","result"=>"account_pay_success","msg"=>"account_pay_success"]);
                // return redirect('ipaypayment/paysuccess');
            }
            else{
                return response()->json(['success'=>"faild","result"=>"somethig errors","msg"=>"somethig errors"]);
            }
        }
        else{
            //$this->addmoney_record($this->Moneycount);
            return response()->json(['success'=>"faild","msg"=>"not enough the money, please charge.","result"=>"no_money"]);
        }


    }

    private function pay_bag(){
        $time=time();
        $uid=$this->user_id;
        $fufen=env('fufen_yuan');
        $user_inf=User::select('*')->where('id',$uid)->first();
        $query_1=$this->set_dingdan('account','A');// Order number

        $Money=$user_inf->money-$this->Moneycount+$this->fufen_to_money; // I think fufen_to_money is score to convert to money

        $query_fufen=true;
        $pay_zhifu_name="account";

        if($this->fufen_to_money){
            $myfufen = $user_inf->score - $this->fufen;
            $query_fufen = User::where('id',$uid)->update(array( 'score'=>$myfufen));
            $pay_zhifu_name = 'Integral';//积分
            $this->Moneycount = $this->fufen;
        }

        //add user experience  +existing money
        $jingyan = $this->user_inf->jingyan + env('z_shoppay');
        $query_jingyan = User::where('id',$uid)->update(array( 'jingyan'=>$jingyan));

        $query_2=User::where('id',$uid)->update(array( 'money'=>$Money));
        $query_3=$info=User::select('*')->where('id','=',$uid)->first();
        $model=new memberaccount();
        $model->uid=$uid;
        $model->type=-1;
        $model->pay=$pay_zhifu_name;
        $model->content="Purchased Goods";
        $model->money=$this->Moneycount;
        $model->time=$time;
        $query_4=$model->save();
        $query_5=true;
        $query_insert=true;

        //$cloud_productlist=get_paycartlist_cloud(); //cloud products
       // $cloud_productlist=$this->cloud_productlist; //cloud products
       // $inter_paycarts=get_paycartlist_internate(); //popular products

        if($this->p_type=='cloud'){
            $goods_count_num = 0;
            //foreach($cloud_productlist as $shop){
                $pro_shop=Items::select('*')->where('id','=',$this->product_id)->first();
                if($this->amount >= $pro_shop->zongrenshu && $pro_shop->maxqishu >= $pro_shop->qishu){ // when max and equal
                    Items::where('id',$this->product_id)->update(array( 'canyurenshu'=>$pro_shop->zongrenshu,'shenyurenshu'=>0));
                }
                else{
                    $sellnum=membergorecord::select(DB::raw('SUM(gonumber) as sellnum'))->where('shopid','=',$this->product_id)->first();

                    $sellnum = $sellnum->sellnum;
                    $shenyurenshu = $pro_shop->zongrenshu - $sellnum;
                    $query=Items::where('id',$this->product_id)->update(array( 'canyurenshu'=>$sellnum,'shenyurenshu'=>$shenyurenshu));
                    if(!$query)$query_5=false;
                }
                $goods_count_num += $this->shop['goods_count_num'];
            //}
            // Add integral
            if(!$this->fufen_to_money){
                $mygoscore = env('f_shoppay')*$goods_count_num;
                $mygoscore_text =  "Purchased ".$goods_count_num."times Products";//购买了{$goods_count_num}人次商品
                $myscore = $query_3->score + $mygoscore;
                //  $myscore = Auth::user()->score + $mygoscore-$this->fufen; //ooo
                $query_add_fufen_1=User::where('id',$uid)->update(array( 'score'=>$myscore));
                $model=new memberaccount();
                $model->uid=$uid;
                $model->type=1;
                $model->pay='Integral';//积分
                $model->content=$mygoscore_text;
                $model->money=$mygoscore;
                $model->time=$time;
                $query_add_fufen_2= $model->save();
                $query_fufen = ($query_add_fufen_1 && $query_add_fufen_2);
            }

            $dingdancode=$this->dingdancode;//已付款,未发货,未完成 Paid undelivered not completed
            $query_6 =membergorecord::where('code','=',$dingdancode)->where('uid','=',$this->user_id)->update(array('status'=>'已付款,未发货,未完成'));
            //$query_7 = $this->dingdan_query;
            $this->goods_count_num = $goods_count_num;

            if($info->money == $Money){

                    $pro_shop=Items::select('*')->where('id','=',$this->product_id)->first();
                    if($pro_shop->canyurenshu >= $pro_shop->zongrenshu && $pro_shop->maxqishu >= $pro_shop->qishu){
                        $query_insert=$this->pay_insert_shop($pro_shop,'add');
                    }

            }


        }


        return true;

    }

    //Generate order code
    /**
     * @param string $pay_type
     * @param string $dingdanzhui
     * @return bool
     */
    private function set_dingdan($pay_type='',$dingdanzhui=''){

        //pay_get_dingdan_code('a')

        $uid=$this->user_id;
        $username=goodlist::get_user_name($uid);
        $user_inf=User::select('*')->where('id',$uid)->first();
        $uphoto=$user_inf->avatar;
        $this->Moneycount=0;

        $this->dingdancode = $dingdancode=$dingdanzhui.time().substr(microtime(),2,6).rand(0,9); //product order number

        $inter_query=false;
        $cloud_query=false;
        // $ip=get_ip();  // goes to the helper.php

        // Todof
        //$cloud_productlist=get_paycartlist_cloud(); //cloud products
       // $inter_paycarts=get_paycartlist_internate(); //popular products

        if($this->p_type=="cloud"){


                $dingdancode_temp=0; //separate order

                // order time
                $time=sprintf("%.3f",microtime(true));
                //foreach($cloud_productlist as $key=>$shop){
                $pro_shop=Items::select('*')->where('id','=',$this->product_id)->first();
                $ret_data=$this->pay_get_shop_codes($this->amount,$pro_shop);

                $this->dingdan_query=$ret_data['query'];
                if(!$ret_data['query'])$this->dingdan_query = false;
                $codes = $ret_data['user_code'];									//Purchase ocde obtained
                $codes_len= intval($ret_data['user_code_len']);						//Get the number of codes
                $money=$codes_len * $pro_shop->yunjiage;                         //The total price of a single commodity

                $this->Moneycount+=$money; //Total Cost

                $status='未付款,未发货,未完成'; //unpaid, not shipped ,not completed
                $this->shop['canyurenshu'] = intval($pro_shop->canyurenshu) + $codes_len;
                $this->shop['goods_count_num'] = $codes_len;



                if($codes_len){
                    $model=new membergorecord();
                    $model->code=$dingdancode;
                    $model->code_tmp=$dingdancode_temp;
                    $model->uid=$uid;
                    $model->username=$username;
                    $model->uphoto=$uphoto;
                    $model->shopid=$pro_shop->id;
                    $model->shopname=$pro_shop->title;
                    $model->shopqishu=$pro_shop->qishu; //Number of Periods
                    $model->gonumber=$codes_len;
                    $model->moneycount=$money;
                    $model->goucode=$codes;
                    $model->pay_type=$pay_type;
                    $model->ip=$_SERVER['REMOTE_ADDR'];
                    $model->status=$status;
                    $model->time=$time;
                    $cloud_query=$model->save();
                    //$insert_html.="('$dingdancode','$dingdancode_tmp','$uid','$username','$uphoto','$shop[id]','$shop[title]','$shop[qishu]','$codes_len','$money','$codes','$pay_type','$ip','$status','$time'),";
                }


        } //end cloud product



        if($inter_query || $cloud_query )
            return true;
        else
            return false;
    }
    /*
*   *user_num 		@Generate number
*	shopinfo		@poroduct information
*	ret_data		@return data
*/
    private function pay_get_shop_codes($user_num=1,$shopinfo=null){
        $ret_data['query'] = true;
        $table = 'go_shopcodes_1';
        //$codes_one=shopcodes::select('*')->where('s_id','=',$shopinfo->id)->orderBy('s_cid','DESC')->first();
        $codes_arr = array();
        $codes_one=DB::select(DB::raw("select * from go_shopcodes_1 where s_id=".$shopinfo->id."  order by s_cid DESC for update"));

        $codes_arr[($codes_one[0]->s_cid)]=$codes_one[0];
        $codes_count_len = $codes_arr[$codes_one[0]->s_cid]->s_len;

        if($codes_count_len < $user_num && $codes_one[0]->s_cid > 1){  //no testing
            for($i=$codes_one[0]->s_cid-1;$i>=1;$i--):
                $codes_arr[$i] = DB::select(DB::raw("select * from go_shopcodes_1 where s_id=".$shopinfo->id." and s_cid = ".$i." order by s_cid DESC for update"));
                //$codes_arr[$i] = $db->GetOne("select id,s_id,s_cid,s_len,s_codes from `$table` where `s_id` = '$shopinfo[id]' and `s_cid` = '$i'  LIMIT 1 for update");
                $codes_count_len += $codes_arr[$i]->s_len;
                if($codes_count_len > $user_num)  break;
            endfor;
        }

        if($codes_count_len < $user_num) $user_num = $codes_count_len;
        $ret_data['user_code'] = '';
        $ret_data['user_code_len'] = 0;


        foreach($codes_arr as $icodes){
            $u_num = $user_num;
            $icodes->s_codes= unserialize($icodes->s_codes);
            $code_tmp_arr = array_slice($icodes->s_codes,0,$u_num);
            $ret_data['user_code'] .= implode(',',$code_tmp_arr);
            $code_tmp_arr_len = count($code_tmp_arr);

            if($code_tmp_arr_len < $u_num){
                $ret_data['user_code'] .= ',';
            }

            $icodes->s_codes= array_slice($icodes->s_codes,$u_num,count($icodes->s_codes));
            $icode_sub = count($icodes->s_codes);
            $icodes->s_codes = serialize($icodes->s_codes);

            if(!$icode_sub){
                $query= shopcodes::where("id",'=', $icodes->id)
                    ->update(array( 's_cid'=>0,'s_codes'=>$icodes->s_codes,'s_len'=>$icode_sub));

                if(!$query)$ret_data['query'] = false;
            }else{
                $query= shopcodes::where("id",'=', $icodes->id)
                    ->update(array( 's_codes'=>$icodes->s_codes,'s_len'=>$icode_sub));
                if(!$query)$ret_data['query'] = false;
            }
            $ret_data['user_code_len'] += $code_tmp_arr_len;
            $user_num  = $user_num - $code_tmp_arr_len;
        }

        return $ret_data;
    }
    /**
     * Reveal and insert goods.
     * @param string $shop
     * @param string $type
     */
    public function pay_insert_shop($shop='',$type=''){
        $time=sprintf("%.3f",microtime(true)+(int)env('goods_end_time'));
        $pro_shop=Items::select('*')->where('id','=',$this->product_id)->first();

        $url='http://f.apiplus.cn/cqssc.json';

        $handler=curl_init($url);
        curl_setopt($handler,   CURLOPT_RETURNTRANSFER,   1);
        $out   =   curl_exec($handler);
        $cq=json_decode($out,true);
        $cqssc=(array_pop($cq['data']));


        $data['cqssctime']=$cqssc['opentime'];
        $data['cqsscsign']=$cqssc['expect'];
        $data['cqssc']=str_replace(',','',$cqssc['opencode']);
        //$this->cqssc=$data;
        $cyrs = $pro_shop->canyurenshu;
        //$cyrs =567;
        $h=abs(date("H",$time));
        $i=date("i",$time);
        $s=date("s",$time);
        $w=substr($time,11,3);
        $num= $h.$i.$s.$w;
        if(!$cyrs)$cyrs=1;
        $go_code = 10000001+fmod($num*100+$data['cqssc'],$cyrs);
        $code=intval($go_code);

        /*** ****/

        if($pro_shop->zhiding){
            /**
            $ex_info=membergorecord::select('*')->where('shopid',$pro_shop->id)->where('shopqishu',$pro_shop->qishu)->where('uid',$pro_shop->zhiding)->first();
            if(is_object($ex_info)){
            $ex_code=explode(",",$ex_info->goucode);
            $ex_count=count($ex_code);
            $ex_rand=rand(0,$ex_count-1);
            if($ex_code[$ex_rand]){
            $code=$ex_code[$ex_rand];
            }
            }
             * */
            $ex_info=membergorecord::select('*')->where('shopid',$pro_shop->id)->where('shopqishu',$pro_shop->qishu)->get();

            foreach($ex_info as $rec_row){
                $ex_code=explode(",",$rec_row->goucode);
                if(in_array($pro_shop->zhiding, $ex_code)){
                    $code=$pro_shop->zhiding;
                    break;
                }

            }

        }
        /**  ***/

        $u_go_info=membergorecord::select('*')->where('shopid','=',$pro_shop['id'])->where('shopqishu','=',$pro_shop->qishu)->whereRaw("goucode LIKE '%".$code."%'")->first();
        //$u_go_info = $db->GetOne("select * from `@#_member_go_record` where `shopid` = '$shop[id]' and `shopqishu` = '$shop[qishu]' and `goucode` LIKE  '%$code%'");
        $query = true;
        if(is_object($u_go_info)){
            $u_info = User::select('id','avatar','name','email','mobile_number','address','zip_code','city')->where('id','=',$u_go_info->uid)->first();
        }
        else{
            $query = false;
        }

        if(is_object($u_info)){
            $u_info->name = _htmtocode($u_info->name);
            $u_temp['id']=$u_info->id;
            $u_temp['avatar']=$u_info->avatar;
            $u_temp['name']=$u_info->name;
            $u_temp['email']=$u_info->email;
            $u_temp['mobile_number']=get_user_name($u_info->mobile_number,'mobile');
            $u_temp['address']=$u_info->address;
            $q_user = serialize($u_temp);
            // $gtimes = (int)env('goods_end_time');
            $gtimes = 0;
            if($gtimes == 0 || $gtimes == 1){
                $q_showtime = 'N';
            }else{
                $q_showtime = 'Y';
            }
            $query= Items::where("id",'=', $pro_shop->id)
                ->update(array( 'canyurenshu'=>$pro_shop->zongrenshu,'shenyurenshu'=>0,
                    'q_uid'=>$u_info->id,'q_user'=>$q_user,'q_user_code'=>$code,
                    'q_end_time'=>$time,'q_showtime'=>$q_showtime));

            $query=membergorecord::where('id','=',$u_go_info->id)->update(array('huode'=>$code,'cqssc'=>$data['cqssc'],'cqssctime'=>$data['cqssctime'],'cqsscsign'=>$data['cqsscsign']));


            /**  notify to the winner**/
            $sid=getenv('TWILIO_ACCOUNT_SID');
            $token=getenv('TWILIO_AUTH_TOKEN');
            //$twilio = new Client($sid, $token);

            if($u_info->mobile_number=="8613478147560" || $u_info->mobile_number=="8613478147561"|| $u_info->mobile_number=="0123456789"){
                $mobile_number="8613478147560";
            }
            else{
                $mobile_number="6".$u_info->mobile_number;
            }

            $msg= "You are winner in SatuMall Product: ".$pro_shop->title." Revealed Date: ".microt($time)." Winner code: ".$code." Shipping Address: ".$u_info->address.", ".$u_info->zip_code.", ".$u_info->city;
            //$return=gw_send_sms(getenv('apiusername'), getenv('apipassword'), getenv('senderid'), $mobile_number, $msg);

            /**
            $message = $twilio->messages
            ->create("whatsapp:+".$mobile_number,
            array(
            "body" =>  "You are winner in SatuMall \nProduct: ".$pro_shop->title." \nRevealed Date:\n ".microt($time)." \nWinner code: ".$code." \nShipping Address: ".$u_info->address.", ".$u_info->zip_code.", ".$u_info->city,
            "from" => "whatsapp:".getenv('TWILIO_WHATSAPP_NUMBER'),
            "mediaUrl"=>"http://haipsy3.selfip.com/satumall/".$pro_shop->thumb
            )
            );

             **/
            /** **/

        }
        else{
            $query=false;
        }
        // sending new product again.
        if($query){
            $maxinfo = Items::select('*')->where('id','=',$pro_shop->id)->first();
            if($pro_shop->qishu < $pro_shop->maxqishu){
                //$maxinfo = $db->GetOne("select * from `@#_shoplist` where `sid` = '$shop[sid]' order by `qishu` DESC LIMIT 1");


                $new_model=new Items();
                $new_model->xsjx_time=0;
                $new_model->time=time();
                $new_model->qishu=intval($maxinfo->qishu)+1;
                $new_model->canyurenshu=0;
                $new_model->shenyurenshu=$maxinfo->zongrenshu;
                $new_model->title=$maxinfo->title;
                $new_model->title2=$maxinfo->title2;
                $new_model->q_showtime='N';
                $new_model->sid=$maxinfo->sid;
                $new_model->cateid=$maxinfo->cateid;
                $new_model->brandid=$maxinfo->brandid;
                $new_model->description=$maxinfo->description;
                $new_model->content=$maxinfo->content;
                $new_model->money=$maxinfo->money;
                $new_model->yunjiage=$maxinfo->yunjiage;
                $new_model->zongrenshu=$maxinfo->zongrenshu;
                $new_model->zongrenshu=$maxinfo->zongrenshu;
                $new_model->maxqishu=$maxinfo->maxqishu;
                $new_model->thumb=$maxinfo->thumb;
                $new_model->picarr=$maxinfo->picarr;
                $new_model->codes_table=$maxinfo->codes_table;
                $new_model->pos=$maxinfo->pos;
                $new_model->renqi=$maxinfo->renqi;
                $new_model->order=$maxinfo->order;
                $new_model->keywords=$maxinfo->keywords;
                $new_model->save();
                $lastid= $new_model->id;
                $this->content_get_go_codes($maxinfo->zongrenshu,3000,$lastid);

            }


        }
        else{
            return false;
        }
        return true;
    }
    /** generate product order codes */
    function content_get_go_codes($CountNum=null,$len=null,$sid=null){


        $num = ceil($CountNum/$len);
        $code_i = $CountNum;
        if($num == 1){
            $codes=array();
            for($i=1;$i<=$CountNum;$i++){
                $codes[$i]=10000000+$i;
            }shuffle($codes);$codes=serialize($codes);
            $model=new shopcodes();
            $model->s_id=$sid;
            $model->s_cid=1;
            $model->s_len=$CountNum;
            $model->s_codes=$codes;
            $model->s_codes_tmp=$codes;
            $model->save();
            unset($codes);
            return "success";
        }
        $query_1 = true;

        for($k=1;$k<$num;$k++){
            $codes=array();
            for($i=1;$i<=$len;$i++){
                $codes[$i]=10000000+$code_i;
                $code_i--;
            }shuffle($codes);$codes=serialize($codes);

            $model=new shopcodes();
            $model->s_id=$sid;
            $model->s_cid=$k;
            $model->s_len=$len;
            $model->s_codes=$codes;
            $model->s_codes_tmp=$codes;
            $model->save();
            unset($codes);
        }

        $CountNum = $CountNum - (($num-1)*$len);
        $codes=array();
        for($i=1;$i<=$CountNum;$i++){
            $codes[$i]=10000000+$code_i;
            $code_i--;
        }shuffle($codes);$codes=serialize($codes);

        $model=new shopcodes();
        $model->s_id=$sid;
        $model->s_cid=$num;
        $model->s_len=$CountNum;
        $model->s_codes=$codes;
        $model->s_codes_tmp=$codes;
        $model->save();

        unset($codes);
        return "success";
    }
}
