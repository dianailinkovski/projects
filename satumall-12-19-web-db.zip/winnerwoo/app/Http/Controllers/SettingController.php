<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use App\Models\Items;
use App\Models\Ordercloud;
//use Illuminate\Support\Facades\Validator;


class SettingController extends Controller
{
    public function __construct(){

    }



}
