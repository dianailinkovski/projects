<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use App\Models\Items;
use App\Models\Members;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Image;
//use Illuminate\Support\Facades\Validator;


class MemberController extends Controller
{

    private  $current_model;
    public function __construct(){
        $this->current_model=new Members();
    }
    /**
     *  get member lists
     *
     * @return Response
     */
    public function memberlist(){ //  get memberlist
        $data= User::select('*')->get();
        return view('admin.member_list')->withData($data);

    }
    /**
     *  get  added member in today
     *
     * @return Response
     */
    public function addedtoday(){
        $data= $this->current_model->getTodaymemeber();
        return view('admin.member_list')->withData($data);

    }
    /**
     *  get  note certied member in today
     *
     * @return Response
     */
    public function notcertified(){
        $data= $this->current_model->getNotcertified();
        return view('admin.member_list')->withData($data);

    }
    /**
     *  get  note certied member in today
     *
     * @return Response
     */
    public function deletedmember(){
        $data= $this->current_model->getDeletedmember();
        return view('admin.member_list')->withData($data);

    }
    /**
     *  get  note certied member in today
     *
     * @return Response
     */
    public function addmemeber(){
        // $data= $this->current_model->getDeletedmember();
        return view('admin.add_member');

    }
    /**
     *  get  note certied member in today
     *
     * @return Response
     */
    public function savemember(Request $request){

        $rules = array(
            'first_name'        => 'required|string|max:100',
            'last_name'        => 'required|string|max:100',
            'mobile_number' =>'required|phone|size:10|unique:users',
           // 'address'        => 'required',
            //'zip_code'        => 'required',
            'account_balance'        => 'required|numeric',
            'jingyan'        => 'required|numeric',
            'score'        => 'required|numeric',
            //'city'        => 'required|string|max:200',
            'password' => 'required|string|min:6',
        );
        $this->validate($request, $rules);


        $nowtime = date('Y_m_d');
        $temp="public/eshop/upload/temp/";
        $path="public/avatar/";

        $avarta_flag=0;
        if( $request->hasFile('thumbnail') )	{

            $extension              = $request->file('thumbnail')->getClientOriginalExtension();
            $type_mime_shot   = $request->file('thumbnail')->getMimeType();
            $sizeFile                 = $request->file('thumbnail')->getSize();
            $thumbnail              = $nowtime.'-'.str_random(32).'.'.$extension;

            if( $request->file('thumbnail')->move($temp, $thumbnail) ) {

                $image = Image::make($temp.$thumbnail);


                $image->fit(180, 180)->save($temp.$thumbnail);

                \File::copy($temp.$thumbnail, $path.$thumbnail);
                \File::delete($temp.$thumbnail);


            }// End File
            $avarta_flag=1;
        } // HasFile

        $model= new User();
        $model->name=$request->first_name;
        $model->last_name=$request->last_name;
        $model->email=$request->email;
        $model->mobile_number=$request->mobile_number;
        $model->password= Hash::make($request->password);
        $model->money=$request->account_balance;
        $model->jingyan=$request->jingyan;
        $model->score=$request->score;
        $model->emailcode=$request->email_status;
        $model->mobilecode=$request->phone_status;
        $model->qianming=$request->description;
        $model->groupid=$request->group;
        $model->address=$request->address;
        $model->zip_code=$request->zip_code;
        $model->time=time();
        $model->city=$request->city;
        $model->sign_in_time=time();
        $model->status=$request->status;
        $model->role=$request->role;
        $model->save();

        $lastid=$model->id;
        if($avarta_flag)
            User::where("id",'=', $lastid)
                ->update( array( 'avatar'=>$path.$thumbnail));

        \Session::flash('success_message', trans('admin.success_add'));
        return redirect('panel/admin/members/member_list');

    }

    public function editmemeber($id){
        $data=User::select('*')->where('id','=',$id)->first();

        return view('admin.edit_member',compact('data'));
    }
    public function deletemember($id){
        $lang = User::findOrFail($id);

        $lang->delete();
        \Session::flash('success_message', trans('admin.success_delete'));
        return redirect('panel/admin/members/member_list');

    }
    public function updatemember(Request $request){
        $rules = array(
            'first_name'        => 'required|string|max:100',
            'last_name'        => 'required|string|max:100',
            // 'email' => 'required|string|email|max:255|unique:users',
            //'mobile_number' =>'required|phone|size:10|unique:users',
            //'address'        => 'required',
           // 'zip_code'        => 'required',
            'account_balance'        => 'required|numeric',
            'jingyan'        => 'required|numeric',
            'score'        => 'required|numeric',
           // 'city'        => 'required|string|max:200',
        );
        $this->validate($request, $rules);


        $nowtime = date('Y_m_d');
        $temp="public/eshop/upload/temp/";
        $path="public/avatar/";

        $avarta_flag=0;
        if( $request->hasFile('thumbnail') )	{

            $extension              = $request->file('thumbnail')->getClientOriginalExtension();
            $type_mime_shot   = $request->file('thumbnail')->getMimeType();
            $sizeFile                 = $request->file('thumbnail')->getSize();
            $thumbnail              = $nowtime.'-'.str_random(32).'.'.$extension;

            if( $request->file('thumbnail')->move($temp, $thumbnail) ) {

                $image = Image::make($temp.$thumbnail);


                $image->fit(180, 180)->save($temp.$thumbnail);

                \File::copy($temp.$thumbnail, $path.$thumbnail);
                \File::delete($temp.$thumbnail);


            }// End File
            $avarta_flag=1;
        } // HasFile

        User::where("id",'=', $request->key_id)
            ->update( array( 'name'=>$request->first_name,'status'=>$request->status,'role'=>$request->role,'last_name'=>$request->last_name,'address'=>$request->address,'zip_code'=>$request->zip_code,
                'money'=>$request->account_balance,'jingyan'=>$request->jingyan,'score'=>$request->score,'emailcode'=>$request->email_status,'mobilecode'=>$request->phone_status,
                'qianming'=>$request->description,'emailcode'=>$request->email_status,'mobilecode'=>$request->phone_status,'city'=>$request->city));
        if($avarta_flag)
            User::where("id",'=', $request->key_id)
                ->update( array( 'avatar'=>$path.$thumbnail));

        \Session::flash('success_message', trans('admin.success_update'));
        return redirect('panel/admin/members/member_list');

    }
    /**
     *  get  expense record
     *
     * @return Response
     */
    public function expenserecord(){
        $data= $this->current_model->getExpenserecord();
        return view('admin.member_expense_record')->withData($data);

    }

    /**
     *  get  expense record
     *
     * @return Response by search date
     */
    public function expenserecordbypost(Request $request){
        $date_temp=$request->reservationtime;

        if($date_temp!=""){
            $date=explode("-",$date_temp);
            //$first_dt=date('Y-m-d H:i:s',strtotime($date[0]));

            $first_dt=strtotime($date[0]);
            $second_dt=strtotime($date[1]);

            $data= $this->current_model->getExpenserecordbetweendate($first_dt,$second_dt);
        }
        else
            $data= $this->current_model->getExpenserecord();


        return view('admin.member_expense_record',compact('data','date_temp'));

    }
    /**
     *  get  recharge record list
     *
     * @return Response
     */
    public function rechargerecord(){
        $data= $this->current_model->getRechargerecord();
        return view('admin.member_recharge_record')->withData($data);

    }





    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id) {

        $data = Article::findOrFail($id);

        return view('admin.editarticle')->withData($data);

    }//<--- End Method






}
