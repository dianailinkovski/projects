<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Items;
use Illuminate\Support\Facades\DB;
use App\Models\Slide;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        /**
         * latest  ANNOUNCEMENT for mobile responsive
         */
        $announcement=Items::select("*")->whereRaw("q_end_time is not null")
            ->where("q_showtime","=","N")
            ->orderBy("q_end_time","DESC")
            ->paginate(8);
        /**
         * latest announcement for web 1
         */

        $announcement_1=DB::select(DB::raw("select * from go_shoplist where q_end_time is not null and q_showtime='N' order by q_end_time DESC limit 0,4"));

        $announcement_2=DB::select(DB::raw("select * from go_shoplist where q_end_time is not null and q_showtime='N' order by q_end_time DESC limit 4,4"));


        /**  **/

        $shoplist =Items::select("*")->where("scene","!=","1")->whereRaw("q_end_time is null")->where("q_showtime","=","N")
            ->where("shenyurenshu","!=","0")->orderBy("created_at","DESC")->paginate(8);

        /*
         * comming soon
        */
        $comming_soon=Items::select("*")->whereRaw("q_uid is null")
           ->orderBy("shenyurenshu","ASC")->paginate(6);

        /**
         * latest participation
         */
        $latest_participate=DB::select(DB::raw("SELECT users.id,users.email, users.mobile_number, users.avatar,go_member_go_record.username, go_member_go_record.shopname,go_member_go_record.shopid FROM go_member_go_record, users WHERE go_member_go_record.uid=users.id AND go_member_go_record.status LIKE '%已付款%' ORDER BY go_member_go_record.time DESC LIMIT 0,8"));

        $slides=Slide::where('visible','1')->orderBy('order','ASC')->get();

        return view('index.home', compact('shoplist','comming_soon','announcement','announcement_1','announcement_2','latest_participate','slides'));
    }

    public  function language_change($id){
        if($id!="en" && $id!="cn"){

            return redirect()->back();
        }

        \Session::put('language', $id);//when buy the product.
        \Session::save();
        return redirect()->back();
    }
}
