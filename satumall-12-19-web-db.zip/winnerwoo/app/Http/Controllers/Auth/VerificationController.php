<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Twilio\Rest\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class VerificationController extends Controller
{


    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('authenticate');
    }

    public function verify(){

        $user = Auth::user();
        if($user->status=='active'){
            return redirect('/home');
        }
        return view('auth.verify');
    }
    public function confirm(Request $request){
        $user = Auth::user();

        $rules = array(
            'verify_code'        => 'required'

        );
        $this->validate($request, $rules);

        $sys_verify_code=\Session::get('verify_code');
        $user_verify_code=$request->verify_code;
        if($sys_verify_code==$user_verify_code){
            User::where('id',$user->id)->update(array('status'=>'active','mobilecode'=>1));
            \Session::forget('verify_code');
            \Session::flash('info',"Verify Successed!");
            return redirect('/home');
        }
        else{
            \Session::flash('token_mismatch',"Invalid Verify Code.");
            return redirect()->back();
        }
        dd(\Session::get('verify_code'),$request->verify_code);

    }
    public function resend(){

        $verify_code=generateRandomString(3)."-".generateRandomString(3);
        $sid=getenv('TWILIO_ACCOUNT_SID');
        $token=getenv('TWILIO_AUTH_TOKEN');
        $twilio = new Client($sid, $token);

        if(Auth::user()->mobile_number=='0123456789'){
            $mobile_number="8613478147560";
        }
        else{
            $mobile_number="6".Auth::user()->mobile_number;
        }


        $return=gw_send_sms(getenv('apiusername'), getenv('apipassword'), getenv('senderid'), $mobile_number, $verify_code);

        /**
        $message = $twilio->messages
        ->create("whatsapp:+".$mobile_number,
            array(
             "body" =>  "Your SatuMallApp verify code:".$verify_code,
            "from" => "whatsapp:".getenv('TWILIO_WHATSAPP_NUMBER')
            )
        );
         * **/
        \Session::put('verify_code', $verify_code);//when buy the product.
        \Session::save();
        if($return=='success'){
            \Session::flash('info',"Resent a Verify Code.");
        }
        else{
            \Session::flash('token_mismatch',"Failed, Wrong phone number.");
        }

        return redirect()->back();



    }

}
