<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\User;
use Illuminate\Support\Facades\Auth;
class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;


    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function loginaction(){
        return view('auth.login');
    }

    public function login_up(Request $request){
        $rules = array(
            'email'        => 'required',
            'password'        => 'required',
        );
        $this->validate($request, $rules);


        if(\Auth::attempt(['mobile_number' => $request->email ,'password' =>$request->password])){

            $new_sessid   = \Session::getId(); //get new session_id after user sign in
            $last_session = \Session::getHandler()->read(\Auth::user()->session_id); // retrive last session

            if ($last_session) {

                \Session::flash('token_mismatch',"Multi user not be allowed to login with a same account in same time");
                \Auth::logout();
                return redirect('/home');
            }

            \Auth::user()->session_id = $new_sessid;
            \Auth::user()->save();

            $regIpAddress = $_SERVER['REMOTE_ADDR'];
           User::where("mobile_number",'=', $request->email)
           ->update( array( 'login_time'=>time(),'user_ip'=>$regIpAddress));
           //  ->update( array( 'login_time'=>Carbon::now()->timestamp));

           \Session::flash('info',"Login Successed!");
           return redirect('/home');
       }

       else{
           \Session::flash('token_mismatch',"These credentials do not match our records.");
            return \Redirect::back();
       }

    }

}
