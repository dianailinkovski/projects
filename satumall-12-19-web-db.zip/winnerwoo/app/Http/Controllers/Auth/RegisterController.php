<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Twilio\Rest\Client;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/verification';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            //'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
            'address' => 'required|string',
            'city'=>'required|string|max:200',
            'mobile_number' =>'required|phone|size:10|unique:users',
            //'mobile_number' =>'required|regex:/(01)[0-9]{10}/|unique:users',
            'postal' => 'required|string|max:200',

        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {

        $verify_code=generateRandomString(3)."-".generateRandomString(3);
        //$sid    = "AC961a4e84ad6c9b5d1f45103c50a4c1a1"; //my osip.yandex
        //$token  = "8aa622647e3d94a128dd83b9bb320d7b";
        /**
        $message =$twilio->messages->create(
        // the number you'd like to send the message to
            '+8613478147560',
            array(
                // A Twilio phone number you purchased at twilio.com/console
                'from' => '+16822435421',
                // the body of the text message you'd like to send
                'body' => 'Hey Jenny! Good luck on the bar exam!'
            )
        );
        **/
        $sid=getenv('TWILIO_ACCOUNT_SID');
        $token=getenv('TWILIO_AUTH_TOKEN');
        $twilio = new Client($sid, $token);
        $token = str_random(75);
        $regIpAddress = $_SERVER['REMOTE_ADDR'];
        $time=time();
       // \Session::flash('token_mismatch',"Check email  ".$data['email']);




        /**
           User::create([
            'name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'email' => $data['email'],
            'address' => $data['address'],
            'mobile_number' => $data['mobile_number'],
            'zip_code' => $data['postal'],
            'password' => Hash::make($data['password']),
            'token' => $data['_token'],
            'remember_token' => $data['_token'],
            'user_ip' => $regIpAddress,
            'sign_in_time' => $time,
            'city' => $data['city'],
            'login_time' =>$time,
            'time' => $time,
        ]);
         * **/

        \Session::put('verify_code', $verify_code);//when buy the product.
        \Session::save();


           // return $user;

        if($data['mobile_number']=='0123456789'){
            $mobile_number="8613478147560";
        }
        else{
            $mobile_number="6".$data['mobile_number'];
        }





         /**
            $message = $twilio->messages
                ->create("whatsapp:+".$mobile_number,
                    array(
                        "body" => "Your SatuMallApp verify code:".$verify_code,
                        "from" => "whatsapp:".getenv('TWILIO_WHATSAPP_NUMBER')
                    )
            );
        **/
        $return=gw_send_sms(getenv('apiusername'), getenv('apipassword'), getenv('senderid'), $mobile_number, $verify_code);


        $user = (new User)->forceFill([
            'name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'email' => $data['email'],
            'address' => $data['address'],
            'mobile_number' => $data['mobile_number'],
            'zip_code' => $data['postal'],
            'password' => Hash::make($data['password']),
            'token' => $data['_token'],
            'remember_token' => $data['_token'],
            'user_ip' => $regIpAddress,
            'sign_in_time' => $time,
            'city' => $data['city'],
            'login_time' =>$time,
            'time' => $time,
        ]);

        $user->save();
        return $user;

    }

}
