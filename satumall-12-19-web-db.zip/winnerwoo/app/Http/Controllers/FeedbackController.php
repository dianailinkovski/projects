<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Items;
use App\Models\Category;
use App\Models\shopcodes;
use App\Models\frontend\goreview;



class FeedbackController extends Controller
{

    public function list(){
        $reivew=goreview::select('*')->get();
        return view('admin.feedback_list',compact('reivew'));
    }
    public function update($id){

    $review=goreview::select('*')->where('id',$id)->first();
    if(!is_object($review))
        return redirect()->back();

    $val=($review->agree)?0:1;
    goreview::where('id',$id)->update(array('agree'=>$val));
    \Session::flash('success_message', trans('admin.success_add'));
    return redirect()->back();

    }

    public function delete($id){

    $lang = goreview::findOrFail($id);
    $lang->delete();
    \Session::flash('success_message', trans('admin.success_delete'));
    return redirect()->back();

    }


}
