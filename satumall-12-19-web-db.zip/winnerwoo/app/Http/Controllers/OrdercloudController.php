<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use App\Models\Items;
use App\Models\Ordercloud;
use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Validator;


class OrdercloudController extends Controller
{

    private  $current_model;
    public function __construct(){
        $this->current_model=new Ordercloud();
    }
    public function index(){
        return view('admin.articlelist');
    }
    public function orderlist()
    {
        $data=$this->current_model->getOrderlist();

        return view('admin.cloud_orderlist')->withData($data);

    }
    public function ziporderlist(){
        $data= $this->current_model->getZipOrderlist();
        return view('admin.cloud_orderlist')->withData($data);
    }
    public function shippedlist(){
        $data= $this->current_model->getShippedlist();
        return view('admin.cloud_orderlist')->withData($data);
    }
    public function notshippedlist(){
        $data= $this->current_model->getNotShippedlist();
        return view('admin.cloud_orderlist')->withData($data);
    }
    public function completedlist(){
        $data= $this->current_model->getComplitedlist();
        return view('admin.cloud_orderlist')->withData($data);
    }
    public function discontinuedlist(){
        $data= $this->current_model->getDiscontinuedlist();
        return view('admin.cloud_orderlist')->withData($data);
    }
    public function pendinglist(){
        $data= $this->current_model->getPendinglist();
        return view('admin.cloud_orderlist')->withData($data);
    }
    public function order_tracking(){ // get order tracking
        $data= $this->current_model->getOrderlist();
        return view('admin.cloud_ordertrack')->withData($data);
    }
    public function order_tracking_post(Request $request){
         $date_temp=$request->reservationtime;

        if($date_temp!=""){
            $date=explode("-",$date_temp);
            //$first_dt=date('Y-m-d H:i:s',strtotime($date[0]));

            $first_dt=strtotime($date[0]);
            $second_dt=strtotime($date[1]);

            $data= $this->current_model->getOrderlistbybetween($first_dt,$second_dt);
        }
        else
            $data= $this->current_model->getOrderlist();
       // var_dump(strtotime($date[0]),$second_dt);exit;
        return view('admin.cloud_ordertrack',compact('data','date_temp'));

    }
     public function winningorder(){ // winning order
            $data= $this->current_model->getWinningorder();
            return view('admin.cloud_orderlist')->withData($data);
    }
    public function undeliveredorder(){ // get order tracking
            $data= $this->current_model->getUndeliveredorder();
            return view('admin.cloud_orderlist')->withData($data);
    }

    public function limitedorder(){ //  get limitted time disclosure
            $data= $this->current_model->getLimitteddisclousre();
            return view('admin.cloud_limittedorder')->withData($data);
    }



    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id) {

        $data = Article::findOrFail($id);

        return view('admin.editarticle')->withData($data);

    }//<--- End Method

/***
 *  order detail action
 */
    public  function order_detail($id){

        $record=Ordercloud::select('*')->where('id',$id)->first();
        $shop=Items::select('*')->where('id',$record->shopid)->first();
        if(!is_object($record)){
            return redirect()->back();
        }

        $shop=Items::select('*')->where('id',$record->shopid)->first();
        if(!is_object($shop)){
            return redirect()->back();
        }
        $user=User::select('*')->where('id',$record->uid)->first();

         return view('admin.cloud_orderdetail',compact('record','shop','user'));

    }

    public function update_order(Request $request){
        $rules = array(
            'company_code'        => 'string|max:20',
            'company'        => 'string|max:20',
        );
        $this->validate($request, $rules);

        $record=Ordercloud::select('*')->where('id',$request->record_id)->first();
         $recode_code=explode(',',$record->status);

         if(!$request->company_money){
             $company_money='0.01';
         }
        else{
            $company_money=sprintf("0.2f",$request->company_money);
        }

        $status=$record->status;
       // dd($request->order_status);
        if($request->order_status=='未完成'){
            $status=$recode_code[0].",".$recode_code[1].","."未完成";
        }
        if($request->order_status=='已发货'){
            $status="已付款,已发货,待收货";//pending receipt
        }
        if($request->order_status=='未发货'){
            $status="已付款,未发货,未完成";
        }
        if($request->order_status=='已完成'){
            $status="已付款,已发货,已完成";
        }
        if($request->order_status=='已作废'){
            $status=$recode_code[0].",".$recode_code[1].","."已作废";
        }

        Ordercloud::where('id',$request->record_id)->update(array("status"=>$status,"company_code"=>$request->company_code,"company_money"=>$request->company_money,"company"=>$request->company_name));
        //\Session::flash('success_message', trans('admin.success_add'));
        return redirect()->back();
    }



}
