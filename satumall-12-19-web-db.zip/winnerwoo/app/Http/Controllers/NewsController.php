<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use App\Models\News;
//use Illuminate\Support\Facades\Validator;


class NewsController  extends Controller
{



    public function index(){
        $data = News::all();
        return view('admin.news_list')->withData($data);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id) {

        $data = News::findOrFail($id);

        return view('admin.edit_news')->withData($data);

    }//<--- End Method
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id){

        $lang = News::findOrFail($id);

        $lang->delete();

        return redirect('panel/admin/content/news_list');

    }//<--- End Method
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function contentAddnews(){


        return view('admin.add_news');

    }//<--- End Method




}
