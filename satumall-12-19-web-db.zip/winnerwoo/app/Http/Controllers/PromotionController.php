<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use App\Models\Items;
use App\Models\Ordercloud;
use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Validator;


class PromotionController extends Controller
{

    private  $current_model;
    public function __construct(){
        $this->current_model=new Ordercloud();
    }
    public function index(){
        return view('admin.articlelist');
    }
    public function limitedorder(){ //  get limitted time disclosure
            $data= $this->current_model->getLimitteddisclousre();
            return view('admin.cloud_limittedorder')->withData($data);
    }

    public function limitedorderpost(Request $request){ //  get limitted time disclosure by search
        $date_temp=$request->reservationtime;

        if($date_temp!=""){
            $date=explode("-",$date_temp);
            $first_dt=strtotime($date[0]);
            $second_dt=strtotime($date[1]);
            $data= $this->current_model->getLimitteddisclousrebetween($first_dt,$second_dt);
        }
        else
            $data= $this->current_model->getLimitteddisclousre();
            return view('admin.cloud_limittedorder',compact('data','date_temp'));
    }

    public function productmanagement(){ //  get limitted time disclosure
            $data= $this->current_model->getProductmanagement();
            return view('admin.cloud_product_manage')->withData($data);
    }

    public function productmanagementbypost(Request $request){
        $date_temp=$request->reservationtime;
        if($date_temp!=""){
            $date=explode("-",$date_temp);
            $first_dt=strtotime($date[0]);
            $second_dt=strtotime($date[1]);
            $data= $this->current_model->getProductmanagementbypost($first_dt,$second_dt);
        }
        else
            $data= $this->current_model->getProductmanagement();
        return view('admin.cloud_product_manage',compact('data','date_temp'));

    }
     /**
     *  get popular products
     *
     * @return Response
     */
    public function popularproducts(){
            $data= $this->current_model->getPopularproducts();
            return view('admin.cloud_popular_products')->withData($data);
    }
    /**
     *  get popular products
     *
     * @return Response
     */
    public function popularproductsbypost(Request $request){

        $date_temp=$request->reservationtime;
        if($date_temp!=""){
            $date=explode("-",$date_temp);
            $first_dt=strtotime($date[0]);
            $second_dt=strtotime($date[1]);
            $data= $this->current_model->getPopularproductsbypost($first_dt,$second_dt);
        }
        else
            $data= $this->current_model->getPopularproducts();
            return view('admin.cloud_popular_products',compact('data','date_temp'));
    }
    /**
     *  get popular products
     *
     * @return Response
     */
    public function timereversed(){
            $data= $this->current_model->getReversedlist();
            $menu_title=trans('admin.period_positive_order');
            $link_url="panel/admin/cloud_promotion/period_order";
            $sub_title="Period reversed";
        return view('admin.cloud_reversed_period',compact('data','menu_title','link_url','sub_title'));
    }
    /**
     *  get popular products
     *
     * @return Response
     */
    public function periodorder(){
         $data= $this->current_model->cloud_positive_list();
        //return view('main.employee.update', compact('employee', 'permission_list', 'permissions'));
        $menu_title=trans('admin.times_reserved');
        $link_url="panel/admin/cloud_promotion/time_reversed";
        $sub_title="Period postive order";
        return view('admin.cloud_reversed_period',compact('data','menu_title','link_url','sub_title'));
    }
    /**
     *  get popular products
     *
     * @return Response
     */
    public function pricereversed(){
        $data= $this->current_model->getReversedprice();
        $menu_title=trans('admin.price_positive_order');
        $link_url="panel/admin/cloud_promotion/price_order";
        $sub_title=trans('admin.unit_price_reversed');
        return view('admin.cloud_reversed_price',compact('data','menu_title','link_url','sub_title'));
    }
    /**
     *  get popular products
     *
     * @return Response
     */
    public function priceorder(){
        $data= $this->current_model->getOrderprice();
        $menu_title=trans('admin.unit_price_reversed');
        $link_url="panel/admin/cloud_promotion/price_reversed";
        $sub_title=trans('admin.price_positive_order');
        return view('admin.cloud_reversed_price',compact('data','menu_title','link_url','sub_title'));
    }

    /**
     *  get popular products
     *
     * @return Response
     */
    public function productreserved(){
        $data= $this->current_model->getReservedproduct();
        $menu_title=trans('admin.product_positive_order');
        $link_url="panel/admin/cloud_promotion/product_order";
        $sub_title=trans('admin.product_price_reversed');
        return view('admin.cloud_reversed_product',compact('data','menu_title','link_url','sub_title'));
    }
 public function productorder(){
        $data= $this->current_model->getOrderproduct();
        $menu_title=trans('admin.product_price_reversed');
        $link_url="panel/admin/cloud_promotion/product_reserved";
        $sub_title=trans('admin.product_positive_order');
        return view('admin.cloud_reversed_product',compact('data','menu_title','link_url','sub_title'));
    }
    /**
     *  get popular products
     *
     * @return Response
     */
    public function disclosed(){
        $data= $this->current_model->getDisclosed();
        return view('admin.cloud_product_manage')->withData($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id) {

        $data = Article::findOrFail($id);

        return view('admin.editarticle')->withData($data);

    }//<--- End Method






}
