<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use App\Models\Items;
use App\Models\Items2;
use App\Models\Category;
use Illuminate\Http\Request;
use Image;
//use Illuminate\Support\Facades\Validator;
//use Auth, URL, DB, Validator, Session;

class InternationController extends Controller
{



    public function index(){
       // $data = Items::all();
        $items_model = new Items2();
        $data=$items_model->getShoplist();
        return view('admin.product_list_international')->withData($data);
    }

    public function Additem()
    {
        $items_model = new Items();
        $categorys=$items_model->getCategory();
        $count=0;
        $option_array=array();
        foreach($categorys as $item){
           // $item->order_cat;
            $order_group=explode(".",$item->order_cat);

            if(count($order_group)==1){
                $option= array( "id" => $item->cateid, "value" => $item->name);
               array_push($option_array,$option);
            }
            else if(count($order_group)==2){
                $option= array( "id" => $item->cateid, "value" => "├─ ".$item->name);
                array_push($option_array,$option);
            }
            else if(count($order_group)==3){
                $option= array( "id" => $item->cateid, "value" => "│  ├─".$item->name);
                array_push($option_array,$option);
            }
        }
        return view('admin.add_item_international', compact('option_array'));

        //return view('welcome');
    }

  public function saveitem(Request $request){
    $rules = array(
        'category'        => 'required',
        'brand'        => 'required',

        'product_title'        => 'required',
        'total_product_price'        => 'required|numeric',
        'stock'        => 'required|numeric',
        //'photo'           => 'mimes:jpg,gif,png,jpe,jpeg',

    );
    $this->validate($request, $rules);
    $nowtime = date('Y_m_d');
    $temp="public/eshop/upload/temp/";
    $path="public/eshop/upload/inter_shop_ge/".$nowtime."/";


    if (!file_exists($path)) {
        mkdir($path, 0777);

    }

    $picarr=array();
    if($request->hasFile('imglists')){
        $image_list=$request->file('imglists');

        foreach($image_list as $img){
            $extension              = $img->getClientOriginalExtension();
            $type_mime_shot   = $img->getMimeType();
            $sizeFile                 = $img->getSize();
            $thumbnail              = $nowtime.'-'.str_random(32).'.'.$extension;

            if( $img->move($temp, $thumbnail) ) {

                $image = Image::make($temp.$thumbnail);

                if(   $image->width() <200  && $image->height() < 200 ) {

                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);

                } else {
                    $image->fit(300, 300)->save($temp.$thumbnail);

                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);
                }

            }// End File

            $picarr[]=$path.$thumbnail;

        }

    }


    if( $request->hasFile('thumbnail') )	{

        $extension              = $request->file('thumbnail')->getClientOriginalExtension();
        $type_mime_shot   = $request->file('thumbnail')->getMimeType();
        $sizeFile                 = $request->file('thumbnail')->getSize();
        $thumbnail              = $nowtime.'-'.str_random(32).'.'.$extension;

        if( $request->file('thumbnail')->move($temp, $thumbnail) ) {

            $image = Image::make($temp.$thumbnail);

            if(  $image->width() > 1200 && $image->height() > 1000 ) {

                \File::copy($temp.$thumbnail, $path.$thumbnail);
                \File::delete($temp.$thumbnail);

            } else {
                $image->fit(1200, 1200)->save($temp.$thumbnail);

                \File::copy($temp.$thumbnail, $path.$thumbnail);
                \File::delete($temp.$thumbnail);
            }

        }// End File
    } // HasFile

    $goods_key_pos = isset($request->goods_key['recommend'])?1:0;
    $goods_key_renqi = isset($request->goods_key['popularity'])?1:0;
    $goods_key_bannershop =isset($request->goods_key['bannershop'])?1:0;

    $items_model = new Items2();

    $items_model->cateid=$request->category;
    $items_model->brandid=$request->brand;
    $items_model->title=$request->product_title;
    $items_model->title2=$request->product_sub_title;
    $items_model->keywords=$request->keywords;
    $items_model->description=$request->description;
    $items_model->money=$request->total_product_price;
    $items_model->inventory=$request->stock;

    $items_model->thumb=$path.$thumbnail;
    $items_model->picarr=serialize($picarr);

    $items_model->content=stripslashes($request->content);

    $items_model->pos=$goods_key_pos;
    $items_model->renqi=$goods_key_renqi;
    $items_model->bannershop=$goods_key_bannershop;

    $items_model->addtime=time();
    $items_model->edittime=time();
    $items_model->save();
  \Session::flash('success_message', trans('admin.success_add'));
  return redirect('panel/admin/international/product_list');


}

    /**
     * @param Request $request
     * updata function
     */

    public function updateitem(Request $request){
        $rules = array(
            'category'        => 'required',
            'brand'        => 'required',
            'product_title'        => 'required',
            'total_product_price'        => 'required|numeric',
            'stock'        => 'required|numeric',
            //'photo'           => 'mimes:jpg,gif,png,jpe,jpeg',

        );
        $this->validate($request, $rules);
        $nowtime = date('Y_m_d');
        $temp="public/eshop/upload/temp/";
        $path="public/eshop/upload/inter_shop_ge/".$nowtime."/";


        if (!file_exists($path)) {
            mkdir($path, 0777);

        }

        $picarr=array();
        $sub_falg=0;//default is empty subimage uploading.
        if($request->hasFile('imglists')){
            $image_list=$request->file('imglists');

            foreach($image_list as $img){
                $extension              = $img->getClientOriginalExtension();
                $type_mime_shot   = $img->getMimeType();
                $sizeFile                 = $img->getSize();
                $thumbnail              = $nowtime.'-'.str_random(32).'.'.$extension;

                if( $img->move($temp, $thumbnail) ) {

                    $image = Image::make($temp.$thumbnail);

                    if(   $image->width() <200  && $image->height() < 200 ) {

                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);

                    } else {
                        $image->fit(300, 300)->save($temp.$thumbnail);

                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);
                    }

                }// End File

                $picarr[]=$path.$thumbnail;
                $sub_falg=1;
            }

        }

        $main_flag=0; //default empty main image uploading.
        if( $request->hasFile('thumbnail') )	{

            $extension              = $request->file('thumbnail')->getClientOriginalExtension();
            $type_mime_shot   = $request->file('thumbnail')->getMimeType();
            $sizeFile                 = $request->file('thumbnail')->getSize();
            $thumbnail              = $nowtime.'-'.str_random(32).'.'.$extension;

            if( $request->file('thumbnail')->move($temp, $thumbnail) ) {

                $image = Image::make($temp.$thumbnail);

                if(  $image->width() > 1200 && $image->height() > 1000 ) {

                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);

                } else {
                    $image->fit(1200, 1200)->save($temp.$thumbnail);

                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);
                }

            }// End File
            $main_flag=1;
        } // HasFile

        $goods_key_pos = isset($request->goods_key['recommend'])?1:0;
        $goods_key_renqi = isset($request->goods_key['popularity'])?1:0;
        $goods_key_bannershop =isset($request->goods_key['bannershop'])?1:0;

        $product_id=$request->product_id;

        $time=time();
        Items2::where("id",'=', $product_id)
            ->update( array( 'cateid'=>$request->category,'brandid'=>$request->brand,
                'title'=>$request->product_title,'title2'=>$request->product_sub_title,'keywords'=>$request->keywords,
                'money'=>$request->total_product_price,'inventory'=>$request->stock,'description'=>$request->description,
                'content'=>stripslashes($request->content),
                 'pos'=>$goods_key_pos,'renqi'=>$goods_key_renqi,'bannershop'=>$goods_key_bannershop,"edittime"=>$time));
        if($main_flag){
            $image_temp=$path.$thumbnail;
            Items2::where("id",'=', $product_id)
                ->update(array( 'thumb'=>$image_temp));
        }
        if($sub_falg){
            $picarra_temp=serialize($picarr);
            Items2::where("id",'=', $product_id)
                ->update(array( 'picarr'=>$picarra_temp));
        }
        \Session::flash('success_message', trans('admin.success_update'));
        return redirect('panel/admin/international/product_list');

    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edititem($id) {

        $data = Items2::findOrFail($id);
        $items_model = new Items();
        $categorys=$items_model->getCategory();
        $brands=$items_model->getbrandbyid($data->cateid);
        $count=0;
        $option_array=array();
        $option_list="";
        foreach($categorys as $item){
            // $item->order_cat;
            $order_group=explode(".",$item->order_cat);
            $sel_str="";
            if($data->cateid==$item->cateid)
                $sel_str="selected";
            if(count($order_group)==1){
                $option_list.="<option value=".$item->cateid." $sel_str >".$item->name."</option>";
            }
            else if(count($order_group)==2){
                $option_list.="<option value=".$item->cateid." $sel_str >"."   ├─ ".$item->name."</option>";
            }
            else if(count($order_group)==3){
                $option_list.="<option value=".$item->cateid." $sel_str>"."   │    ├─".$item->name."</option>";
            }
        }

        $brand_list="";
        foreach($brands as $item){
            $sel_str="";
            if($data->brandid==$item->id)
                $sel_str="selected";
            $brand_list.="<option value=".$item->id." $sel_str >".$item->name."</option>";
        }

        return view('admin.edit_item_international', compact('option_list','data','brand_list'));
       // return view('admin.editarticle')->withData($data);

    }//<--- End Method
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function deleteitem($id){

        $lang = Items2::findOrFail($id);

        $lang->delete();
        \Session::flash('success_message', trans('admin.success_delete'));
        return redirect('panel/admin/international/product_list');


    }//<--- End Method




}
