<?php

namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;
use App\Models\frontend\Internation;
//use App\Models\Items2;
//use App\Models\Category;

//use Illuminate\Support\Facades\Validator;
//use Auth, URL, DB, Validator, Session;

class InternationshopController extends Controller
{


    private  $current_model;
    public function __construct(){
        $this->current_model=new Internation();
    }
    public function index($id){
       // $data = Items::all();
       // $items_model = new Items2();
       // $data=$items_model->getShoplist();

        $temp_id=(explode("_",$id));

        if($temp_id[0]!=0){

            $categories=$this->current_model->getChildcategory($temp_id[0],$temp_id[3]);
            $categories_flag=1;
            $brand_list=$this->current_model->getBrand($temp_id[0]);
            if($categories->count()==0 && $temp_id[3]){
                $categories=$this->current_model->getTwochild($temp_id[3]);
                $categories_flag=0;
            }
            $parentid=$temp_id[3];
            $cateid=$temp_id[0];
            $bid=$temp_id[1];

        }
        else{
            $categories=$this->current_model->getCategory();
            $cateid=$temp_id[0];
            $parentid=null;
            $brand_list=$this->current_model->getBrand($temp_id[0]);
            $bid=$temp_id[1];
            $categories_flag=1;
        }

         $orders=0;
         $order=$temp_id[2];



        if ($cateid && $bid){
            $sun_id_str="'".$cateid."'";
            if($categories_flag){
                foreach($categories as $list){
                    $cd=$list->cateid;
                    $sun_id_str .=",'".$cd ."'";
                }
            }

            $shoplist=$this->current_model->getShoplistbycatbrand($order,$sun_id_str,$bid);
        }
        else{
            if($bid){
                $shoplist=$this->current_model->getShoplistbybrand($order,$bid);
            }
            elseif($cateid){
                $sun_id_str="'".$cateid."'";

                if($categories_flag){
                    foreach($categories as $list){
                        $cd=$list->cateid;
                        $sun_id_str .=",'".$cd ."'";
                    }
                }

                $shoplist=$this->current_model->getShoplistbycategory($order,$sun_id_str);
            }
            else{
                $shoplist=$this->current_model->getShoplistbyblank($order);
            }
        }
       // var_dump( $this->current_model->getCategory());
       return view('user.internation', compact('categories','cateid','parentid','brand_list','bid','temp_id','shoplist'));

    }

    public function detail($id){

        $productinf=$this->current_model->getProductinf($id);
        if(!is_object($productinf)){
            return redirect()->back();
        }
        //$productinf = Internation::findOrFail($id);
        return view('user.detail',compact('productinf'));
    }







}
