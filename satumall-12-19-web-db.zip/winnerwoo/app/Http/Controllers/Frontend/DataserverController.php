<?php

namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;
use App\Models\frontend\goodlist;
use App\Models\Items;
use App\Models\frontend\goreview;
use App\Models\membergorecord;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Image;

class DataserverController extends Controller
{


    private  $current_model;
    public function __construct(){
        $this->current_model=new goodlist();
    }
    public function index($id){
        $itemid=$id;

        $p_inf=Items::select('*')->where('id','=',$id)->first();
        if(!is_object($p_inf))
            return redirect()->back();
         $itemlist=Items::select('*')->where('sid','=',$p_inf->sid)->orderBy('qishu','DESC')->get();

        $goodlist=new goodlist();
        $product_inf=$goodlist->getProductinf($itemid);
        $item=Items::select('*')->where('id','=',$id)->first();


        if(!is_object($item)){
            return redirect()->back();
        }
        $user_shop_arr=membergorecord::select('*')->where('uid',$item->q_uid)
            ->where('shopid',$item->id)->where('shopqishu',$item->qishu)->first();
        $user_codes_arr=membergorecord::select('*')->where('shopid',$item->id)->where('shopqishu',$item->qishu)->get();
        $codes_arr='';

            foreach($user_codes_arr as $v){
                $codes_arr.=$v->goucode.",";
            }

        $gonumber=membergorecord::where('shopid',$item->id)->where('shopqishu',$item->qishu)->sum('gonumber');
        $user_shod_codes=rtrim($codes_arr,",");
        $go_record_list=membergorecord::where('shopid',$id)->orderBy('time','DESC')->get();


        $reviews=goreview::select('*')->where('sid',$product_inf->sid)->where('agree','=','1')->orderBy('time','DESC')->paginate(5);

       return view('user.dataserver',compact('itemlist','itemid','product_inf','item','user_shop_arr','user_shod_codes','gonumber','go_record_list','reviews'));

    }

    /**
     * for to save the user's feedback
     */
    public  function savereview(Request $request){


        //dd(is_null($request->rating)?0:$request->rating);
        // $data=goreview::select('*')->where('user_id',Auth::user()->id)->where('product_id',$request->product_id)->first();
        // if(is_object($data)){
       //      return redirect()->back();
       //  }

        if(is_null(Auth::user())){
            return redirect()->guest('login')
                ->with(array('login_required' => trans('auth.login_required')));
        }

        $picarr=array();
        $pic_num=0;

        if($request->hasFile('imglists')){
            $image_list=$request->file('imglists');
            $nowtime = date('Y_m_d');
            $temp="public/eshop/upload/temp/";
            $path="public/eshop/upload/shaidan/".$nowtime."/";

			if (!file_exists($path)) {
                mkdir($path, 0777);

            }
            foreach($image_list as $img){
                $pic_num++;
                $extension              = $img->getClientOriginalExtension();
                $type_mime_shot   = $img->getMimeType();
                $sizeFile                 = $img->getSize();
                $thumbnail              = str_random(13).'.'.$extension;



                if( $img->move($temp, $thumbnail) ) {

                   $image = Image::make($temp.$thumbnail);


                    if(   $image->width() <640  && $image->height() <640 ) {

                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);

                    } else {
                        $image->fit(640, 640)->save($temp.$thumbnail);

                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);
                    }

                    $picarr[]=$path.$thumbnail;
                }// End File



            }
        }

        $review_model=new goreview();
        $review_model->user_id=Auth::user()->id;
        $review_model->product_id=$request->product_id;
        $review_model->user_email=Auth::user()->email;
        $review_model->mobile_number=get_user_name(Auth::user()->mobile_number,'mobile');
        $review_model->user_photo=Auth::user()->avatar;
        $review_model->score=is_null($request->rating)?0:$request->rating;
        $review_model->feedback=$request->comments;
        $review_model->time= sprintf("%.3f",microtime(true));
        $review_model->pic_arr=serialize($picarr);
        $review_model->image_number=$pic_num;
        $review_model->sid=$request->sid;
        $review_model->save();

        return redirect()->back();


    }

}
