<?php

namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;
use App\Models\frontend\userinf;
use App\Models\frontend\goreview;
use App\Models\User;
use App\Models\Items;
use App\Models\membergorecord;
use App\Models\memberaccount;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Image;
class UserinfController extends Controller
{


    private  $current_model;
    public function __construct(){
        $this->current_model=new userinf();
    }
    public function index(){

       //return view('user.internation', compact('categories','cateid','parentid','brand_list','bid','temp_id','shoplist'));
       return view('user.userinf');

    }
    public function getuserinf($id){
       $member=$this->current_model->getuserinf($id);

        if($member){
            $membergo=$this->current_model->getmemberrecord($id);
            $memberhuode=membergorecord::select('*')->where('uid',$id)->where('huode','>','10000000')->orderBy('id','DESC')->skip(0)
                ->take(10)
                ->get();
        }
        else{
            $membergo=null;
            return redirect()->back();
        }

       return view('user.userinf',compact('member','membergo','memberhuode'));

    }

    public  function recharge(){
        $user_inf=User::select('*')->where('id',Auth::user()->id)->first();
        return view('user.recharge',compact('user_inf'));
    }

    public function balance(){
        $user_inf=User::select('*')->where('id',Auth::user()->id)->first();
        $balance=User::select('*')->where('id',Auth::user()->id)->first();
        return view('user.balance',compact('balance','user_inf'));
    }

    public  function purchaserecord(){
        $user_inf=User::select('*')->where('id',Auth::user()->id)->first();
        $account=memberaccount::select('*')->where('uid',Auth::user()->id)->where('pay','account')->orderBy('time','DESC')->paginate(9);
        return view('user.purchase_rec',compact('account','user_inf'));

    }

    public  function profile(){
        $user_data=User::select('*')->where('id',Auth::user()->id)->first();
        return view('user.userprofile',compact('user_data'));
    }

    public  function profile_update(Request $request){
        $rules = array(
            'first_name'        => 'required|string|max:100',
            'last_name'        => 'required|string|max:100',
            'address'        => 'required',
            'city'        => 'required|string|max:200',
            'zip_code'        => 'required|string|max:200',
            

        );
        $this->validate($request, $rules);

        $nowtime = date('Y_m_d');
        $temp="public/eshop/upload/temp/";
        $path="public/avatar/";
        $file_flag=0;
        if( $request->hasFile('thumbnail') )	{

            $extension              = $request->file('thumbnail')->getClientOriginalExtension();
            $type_mime_shot   = $request->file('thumbnail')->getMimeType();
            $sizeFile                 = $request->file('thumbnail')->getSize();
            $thumbnail              = $nowtime.'-'.str_random(18).'.'.$extension;

            if( $request->file('thumbnail')->move($temp, $thumbnail) ) {

                $image = Image::make($temp.$thumbnail);

                $image->fit(180, 180)->save($temp.$thumbnail);
                \File::copy($temp.$thumbnail, $path.$thumbnail);
                \File::delete($temp.$thumbnail);

                $user_photo=$path.$thumbnail;
                $file_flag=1;
            }// End File
        } // HasFile

        $user_db=User::where('id',Auth::user()->id)->update(array('name'=>$request->first_name,'last_name'=>$request->last_name,
            "address"=>$request->address,"city"=>$request->city,"zip_code"=>$request->zip_code,"email"=>$request->email));

        if($file_flag){
            $user_db=User::where('id',Auth::user()->id)->update(array("avatar"=>$user_photo));
        }
        \Session::flash('info', trans('admin.success_add'));
        return redirect()->back();

    }
    public  function buylist(){
        $user_inf=User::select('*')->where('id',Auth::user()->id)->first();
        $record=membergorecord::select('*')->where('uid',Auth::user()->id)->orderBy('id','DESC')->paginate(8);
        return view('user.userbuylist',compact('record','user_inf'));
    }

    public function buydetail($id){
        $user_inf=User::select('*')->where('id',Auth::user()->id)->first();
        $record=membergorecord::select('*')->where('id',$id)->first();
        return view('user.userbuydetail',compact('user_inf','record'));
    }

    public function winning_record(){
        $user_inf=User::select('*')->where('id',Auth::user()->id)->first();
        //$record=membergorecord::select('*')->where('uid',Auth::user()->id)->where('huode','!=','0')->orderBy('id','DESC')->paginate(8);
        $record=Items::select('*')->where('q_uid',Auth::user()->id)->orderBy('q_end_time','DESC')->paginate(8);

        foreach($record as $row){

            $gonumber=membergorecord::where('shopid',$row->id)->where('uid',Auth::user()->id)->sum('gonumber');
            $review=goreview::where('product_id',$row->id)->where('user_id',Auth::user()->id)->get();
            $row->spent=$gonumber;
            $row->review=$review->count();
        }

        return view('user.winning_record',compact('record','user_inf'));
    }

}
