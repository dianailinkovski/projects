<?php

namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;
use App\Models\frontend\goodlist;
use Illuminate\Support\Facades\DB;
use App\Models\membergorecord;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class GoodlistController extends Controller
{


    private  $current_model;
    public function __construct(){
        $this->current_model=new goodlist();
    }
    public function index($id){


       // var_dump( $this->current_model->getCategory());
       return view('user.good_list');

    }

    public function fivegoodlist($id,$idd){


        $temp_id=(explode("_",$id));

        if($temp_id[0]!=0){

            $categories=$this->current_model->getChildcategory($temp_id[0],$temp_id[3]);
            $categories_flag=1;
            $brand_list=$this->current_model->getBrand($temp_id[0]);
            if($categories->count()==0 && $temp_id[3]){
                $categories=$this->current_model->getTwochild($temp_id[3]);
                $categories_flag=0;
            }
            $parentid=$temp_id[3];
            $cateid=$temp_id[0];
            $bid=$temp_id[1];

        }
        else{
            $categories=$this->current_model->getCategory();
            $cateid=$temp_id[0];
            $parentid=null;
            $brand_list=$this->current_model->getBrand($temp_id[0]);
            $bid=$temp_id[1];
            $categories_flag=1;
        }

        $orders=0;
        $order=$temp_id[2];

        $between=intval($idd);

        if ($cateid && $bid){
            $sun_id_str="'".$cateid."'";
            if($categories_flag){
                foreach($categories as $list){
                    $cd=$list->cateid;
                    $sun_id_str .=",'".$cd ."'";
                }
            }

            $shoplist=$this->current_model->getShoplistbycatbrand($order,$sun_id_str,$bid,$between); //o
        }
        else{
            if($bid){
                $shoplist=$this->current_model->getShoplistbybrand($order,$bid,$between);
            }
            elseif($cateid){
                $sun_id_str="'".$cateid."'";

                if($categories_flag){
                    foreach($categories as $list){
                        $cd=$list->cateid;
                        $sun_id_str .=",'".$cd ."'";
                    }
                }

                $shoplist=$this->current_model->getShoplistbycategory($order,$sun_id_str,$between); //0
            }
            else{
                $shoplist=$this->current_model->getShoplistbyblank($order,$between); //o
            }
        }
        // var_dump( $this->current_model->getCategory());

        return view('user.good_list',compact('categories','cateid','parentid','brand_list','bid','temp_id','shoplist','idd'));

    }



    public function gooddetail($id){
        $productinf=$this->current_model->getProductinf($id);

        if(!is_object($productinf))
            return redirect()->back();

        if($productinf->q_user_code!='' || $productinf->q_end_time!=''){  // if product was winner, swiching to  the data server.
            return redirect('home/dataserver/'.$productinf->id);
        }
        if(!empty($productinf))
            $sid_code=$this->current_model->getSideCode($productinf->sid);
         else{
             $productinf=(object)array();
             $productinf->id=0;
            // return view('errors.503');
             return redirect()->back();
         }


            $sid=isset($sid_code[0])?$sid_code[0]->id:0;
            $s_u_id=isset($sid_code[0])?$sid_code[0]->q_uid:0;
        if($productinf->id == $sid){
           // $sid_code=array();
            $sid_go_record=$this->current_model->getSideRecord(null,null);
            $sid_code=null;
        }
        else{
            $sid_go_record=$this->current_model->getSideRecord($sid,$s_u_id);
        }

        $us=membergorecord::select('*')->where('shopid',$id)->where('shopqishu',$productinf->qishu)->orderBy('id','DESC')->get();
        // my record history
        if(Auth::check()){
            $my_us=membergorecord::select('*')->where('shopid',$id)->where('uid',Auth::user()->id)->where('shopqishu',$productinf->qishu)->orderBy('id','DESC')->limit(4)->get();
        }

        return view('user.gooddetail',compact('productinf','sid_go_record', 'sid_code','us','my_us'));
    }


    public function stagecategory($id){

        if($id=='apple'){
            $shoplist=goodlist::select('*')->whereRaw("title like '%apple%' ")->paginate(6);
        }
        elseif($id=='iphone'){
            $shoplist=goodlist::select('*')->whereRaw("title like '%iphone%' ")->paginate(6);
        }
        elseif($id=='intelligent'){
            $shoplist=goodlist::select('*')->whereRaw("title like '%intelligent%'  or title like '%smart%'")->paginate(6);
        }
        elseif($id=='3Gmobile'){
            $shoplist=goodlist::select('*')->whereRaw("title like '%3G%'")->paginate(6);
        }
        else{
            $shoplist=(object)array();
        }
        /**
        $temp_id=(explode("_",$id));

        if($temp_id[0]!=0){

            $categories=$this->current_model->getChildcategory($temp_id[0],$temp_id[3]);
            $categories_flag=1;
            $brand_list=$this->current_model->getBrand($temp_id[0]);
            if($categories->count()==0 && $temp_id[3]){
                $categories=$this->current_model->getTwochild($temp_id[3]);
                $categories_flag=0;
            }
            $parentid=$temp_id[3];
            $cateid=$temp_id[0];
            $bid=$temp_id[1];

        }
        else{
            $categories=$this->current_model->getCategory();
            $cateid=$temp_id[0];
            $parentid=null;
            $brand_list=$this->current_model->getBrand($temp_id[0]);
            $bid=$temp_id[1];
            $categories_flag=1;
        }

        $orders=0;
        $order=$temp_id[2];

        $between=intval($idd);

        if ($cateid && $bid){
            $sun_id_str="'".$cateid."'";
            if($categories_flag){
                foreach($categories as $list){
                    $cd=$list->cateid;
                    $sun_id_str .=",'".$cd ."'";
                }
            }

            $shoplist=$this->current_model->getShoplistbycatbrand($order,$sun_id_str,$bid,$between); //o
        }
        else{
            if($bid){
                $shoplist=$this->current_model->getShoplistbybrand($order,$bid,$between);
            }
            elseif($cateid){
                $sun_id_str="'".$cateid."'";

                if($categories_flag){
                    foreach($categories as $list){
                        $cd=$list->cateid;
                        $sun_id_str .=",'".$cd ."'";
                    }
                }

                $shoplist=$this->current_model->getShoplistbycategory($order,$sun_id_str,$between); //0
            }
            else{
                $shoplist=$this->current_model->getShoplistbyblank($order,$between); //o
            }
        }
        // var_dump( $this->current_model->getCategory());
  **/

        return view('user.stagcategory',compact('shoplist'));
    }

    public function search_product(Request $request){
        $id=$request->q;

        $shoplist=goodlist::select('*')->whereRaw("title like '%".$id."%' ")->paginate(6);
        return view('user.stagcategory',compact('shoplist'));

    }

    public  function description($pid){

        $data=goodlist::where('id',$pid)->first();
        return view('user.descriptionmobile',compact('data'));
    }


}
