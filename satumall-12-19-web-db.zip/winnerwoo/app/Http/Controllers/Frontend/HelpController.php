<?php

namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Article;


class HelpController extends Controller
{

    public function __construct(){
    }
    public function index($id){

        $catlist=Category::select('*')->where('parentid','=','1')->get();
        if($id=='0')
             $content=Article::select('*')->whereRaw('1')->first();
        else
            $content=Article::select('*')->where('id','=',$id)->first();

        if(empty($content))
            return view('errors.404');

        return view('user.helpcenter',compact('catlist','content'));
    }

    public function mobile($id){
        $catlist=Category::select('*')->where('parentid','=','1')->get();
        if($id=='0')
            $content=Article::select('*')->whereRaw('1')->first();
        else
            $content=Article::select('*')->where('id','=',$id)->first();

        if(empty($content))
            return view('errors.404');

        return view('user.helpcentermobile',compact('catlist','content'));

    }
}
