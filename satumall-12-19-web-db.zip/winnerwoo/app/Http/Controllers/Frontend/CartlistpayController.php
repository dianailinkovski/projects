<?php

namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;



class CartlistpayController extends Controller
{


    private  $current_model;
    public function __construct(){
        $this->current_model=new latestpuclic();
    }
    public function index(){


       // $total=$this->current_model->getTotalcount();
       //return view('user.internation', compact('categories','cateid','parentid','brand_list','bid','temp_id','shoplist'));
       return view('user.cartlist');

    }

     public function cartlist(){
         return view('user.cartlist');
     }

    public function deletecartitem($id){

        $product_id=$id;

        $new_list=array();
        if(session()->has('p_list')){
            $old_list=   session()->get('p_list');
            for($index=0;$index<sizeof($old_list);$index++){
                if($old_list[$index]['product_id']==$product_id){
                    array_splice( $old_list, $index,1 );
                }

            }
           session()->put("p_list",$old_list);
            $new_list=$old_list;
        }

         return view('user.cartlist');
     }
}
