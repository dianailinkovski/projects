<?php

namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;
use App\Models\frontend\latestpuclic;
//use Illuminate\Foundation\Auth\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\User;

class CartlistController extends Controller
{


    private  $current_model;
    public function __construct(){

        $this->current_model=new latestpuclic();
    }
    public function index(){


       // $total=$this->current_model->getTotalcount();
       //return view('user.internation', compact('categories','cateid','parentid','brand_list','bid','temp_id','shoplist'));
       return view('user.cartlist');

    }

     public function cartlist(){
        // $user_data=User::select('*')->where('id',Auth::user()->id)->first();
         return view('user.cartlist');
     }

    public function deletecartitem($id){

        $product_id=$id;
      //  $user_data=User::select('*')->where('id',Auth::user()->id)->first();
        $new_list=array();
        if(session()->has('p_list')){
            $old_list=   session()->get('p_list');
            for($index=0;$index<sizeof($old_list);$index++){
                if($old_list[$index]['product_id']==$product_id){
                    array_splice( $old_list, $index,1 );
                }

            }
           session()->put("p_list",$old_list);
            $new_list=$old_list;
        }

         return view('user.cartlist',compact('user_data'));
     }

     public function cartlistpay(Request $request){

         $user_data=User::select('*')->where('id',Auth::user()->id)->first();

         $fufen_yuan=env('fufen_yuan');

         if($fufen_yuan){
             $fufen_dikou=intval(Auth::user()->score/$fufen_yuan);
         }
         else{
             $fufen_dikou=0;
         }

         return view('user.cartlistpay',compact('fufen_dikou','user_data'));

     }
}
