<?php

namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;
use App\Models\frontend\latestpuclic;


class InternationdiscoverController extends Controller
{


    private  $current_model;
    public function __construct(){
        $this->current_model=new latestpuclic();
    }
    public function index(){
      //  $total=$this->current_model->getTotalcount();
       //return view('user.internation', compact('categories','cateid','parentid','brand_list','bid','temp_id','shoplist'));
       return view('user.invitecloud');

    }
    public function invitefriend(){
        return view('user.invitecloud');
    }
    public function cloudpurchase(){
        return view('user.cloudpurchase');
    }

}
