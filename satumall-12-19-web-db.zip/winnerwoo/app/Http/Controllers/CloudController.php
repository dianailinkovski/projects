<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Items;
use App\Models\Category;
use App\Models\shopcodes;
use Image;
use Input;
//use Illuminate\Support\Facades\Validator;
//use Auth, URL, DB, Validator, Session;

class CloudController extends Controller
{


    public function __construct( Request $request) {
        $this->request = $request;
    }

    public function index(){
        // $data = Items::all();
        $items_model = new Items();
        $data=$items_model->getShoplist();
        return view('admin.product_list')->withData($data);
    }

    public function Additem()
    {
        $items_model = new Items();
        $categorys=$items_model->getCategory();
        $count=0;
        $option_array=array();
        foreach($categorys as $item){
            // $item->order_cat;
            $order_group=explode(".",$item->order_cat);

            if(count($order_group)==1){
                $option= array( "id" => $item->cateid, "value" => $item->name);
                array_push($option_array,$option);
            }
            else if(count($order_group)==2){
                $option= array( "id" => $item->cateid, "value" => "├─ ".$item->name);
                array_push($option_array,$option);
            }
            else if(count($order_group)==3){
                $option= array( "id" => $item->cateid, "value" => "│  ├─".$item->name);
                array_push($option_array,$option);
            }
        }
        return view('admin.add_item', compact('option_array'));

        //return view('welcome');
    }



    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id) {

        $data = Items::findOrFail($id);
        $items_model = new Items();
        $categorys=$items_model->getCategory();
        $brands=$items_model->getbrandbyid($data->cateid);
        $count=0;
        $option_array=array();
        $option_list="";
        foreach($categorys as $item){
            // $item->order_cat;
            $order_group=explode(".",$item->order_cat);
            $sel_str="";
            if($data->cateid==$item->cateid)
                $sel_str="selected";
            if(count($order_group)==1){
                $option_list.="<option value=".$item->cateid." $sel_str >".$item->name."</option>";
            }
            else if(count($order_group)==2){
                $option_list.="<option value=".$item->cateid." $sel_str >"."   ├─ ".$item->name."</option>";
            }
            else if(count($order_group)==3){
                $option_list.="<option value=".$item->cateid." $sel_str>"."   │    ├─".$item->name."</option>";
            }
        }

        $brand_list="";
        foreach($brands as $item){
            $sel_str="";
            if($data->brandid==$item->id)
                $sel_str="selected";
            $brand_list.="<option value=".$item->id." $sel_str >".$item->name."</option>";
        }
        return view('admin.edit_item', compact('option_list','data','brand_list'));
        // return view('admin.editarticle')->withData($data);

    }//<--- End Method
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id){

        $lang = Items::findOrFail($id);

        $lang->delete();
        \Session::flash('success_message', trans('admin.success_delete'));
        return redirect('panel/admin/cloud/product_list');

    }
    //<--- End Method

    public function saveitem(Request $request){

        $rules = array(
            'category'        => 'required',
            'brand'        => 'required',
            //'winning_member'        => 'required|numeric',
            'product_title'        => 'required',
            // 'product_sub_title'        => 'required',

            'total_product_price'        => 'required|numeric',
            'cloud_purchase_price'        => 'required|numeric',
            'maximum_number_period'        => 'required|numeric|max:65535',
            //'photo'           => 'mimes:jpg,gif,png,jpe,jpeg',

        );
        $this->validate($request, $rules);

        $canyurenshu=0;
        $money=intval($request->total_product_price);//total price
        $yunjiage=intval($request->cloud_purchase_price); //cloud single price
        if($money<$yunjiage){
            \Session::flash('token_mismatch',"Prices should not be less than the purchase price.");
            return \Redirect::back()->withInput();
        }

        $ratio_val=$request->total_product_price/$request->cloud_purchase_price;
        if(!is_integer($ratio_val)){
            \Session::flash('token_mismatch',"Please check total product price and cloud purchase single price.");
            return \Redirect::back()->withInput();

        }
        //$rules = array('cloud_purchase_price'=>'required|numeric|max:'.$money);
        // $this->validate($request, $rules);


        $zongrenshu=ceil($money/$yunjiage);
        $code_len=ceil($zongrenshu/3000);
        $shenyurenshu=$zongrenshu-$canyurenshu;

        if($zongrenshu==0 || $shenyurenshu==0){
            \Session::flash('token_mismatch',"Correct the Cloud Purchase price.");
            return \Redirect::back()->withInput();
        }
        $time=time();

        $max_qishu=$request->maximum_number_period;

        $xsjx_time_h=0;
        if($request->datepicker!=''){
            $xsjx_time=strtotime($request->datepicker)?strtotime($request->datepicker):time();
            $xsjx_time_h=intval($request->time_h)?$request->time_h:36000;
            $xsjx_time+=$xsjx_time_h;
        }else{
            $xsjx_time='0';
        }

        $goods_key_pos = isset($request->goods_key['recommend'])?1:0;
        $goods_key_renqi = isset($request->goods_key['popularity'])?1:0;
        $goods_key_bannershop =isset($request->goods_key['bannershop'])?1:0;

        $nowtime = date('Y_m_d');
        $temp="public/eshop/upload/temp/";
        $path="public/eshop/upload/inter_shop/".$nowtime."/";

        if (!file_exists($path)) {
            mkdir($path, 0777);

        }

        $picarr=array();
        if($request->hasFile('imglists')){
            $image_list=$request->file('imglists');

            foreach($image_list as $img){
                $extension              = $img->getClientOriginalExtension();
                $type_mime_shot   = $img->getMimeType();
                $sizeFile                 = $img->getSize();
                $thumbnail              = str_random(32).'.'.$extension;

                if( $img->move($temp, $thumbnail) ) {

                    $image = Image::make($temp.$thumbnail);

                    if(   $image->width() <640  && $image->height() <640 ) {
                        $image->fit(640, 640)->save($temp.$thumbnail);
                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);

                    } else {
                        $image->fit(640, 640)->save($temp.$thumbnail);

                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);
                    }

                }// End File

                $picarr[]=$path.$thumbnail;

            }
        }

        if( $request->hasFile('thumbnail') )	{

            $extension              = $request->file('thumbnail')->getClientOriginalExtension();
            $type_mime_shot   = $request->file('thumbnail')->getMimeType();
            $sizeFile                 = $request->file('thumbnail')->getSize();
            $thumbnail              = str_random(32).'.'.$extension;

            if( $request->file('thumbnail')->move($temp, $thumbnail) ) {

                $image = Image::make($temp.$thumbnail);

                if(  $image->width() < 640 && $image->height() < 640 ) {
                    $image->fit(640, 640)->save($temp.$thumbnail);
                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);

                } else {
                    $image->fit(640, 640)->save($temp.$thumbnail);

                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);
                }

            }// End File
        } // HasFile




        $winning_memeber=$request->winning_member;
        $items_model = new Items();
        $items_model->zhiding=$winning_memeber;// winning member
        $items_model->cateid=$request->category;
        $items_model->brandid=$request->brand;
        $items_model->title=$request->product_title;
        $items_model->title2=$request->product_sub_title;
        $items_model->keywords=$request->keywords;
        $items_model->description=$request->description;
        $items_model->money=$money;
        $items_model->yunjiage=$yunjiage;
        $items_model->zongrenshu=$zongrenshu;
        $items_model->canyurenshu=$canyurenshu;
        $items_model->shenyurenshu=$shenyurenshu;
        $items_model->qishu=1;
        $items_model->maxqishu=$max_qishu;
        $items_model->feedback=$request->feedback;

        $items_model->thumb=$path.$thumbnail;
        $items_model->picarr=serialize($picarr);


        $items_model->content=stripslashes($request->content);
        $items_model->xsjx_time=$xsjx_time;

        $items_model->pos=$goods_key_pos;
        $items_model->renqi=$goods_key_renqi;
        $items_model->bannershop=$goods_key_bannershop;

        $items_model->time=time();

        $items_model->scene=$request->scene==null?2:$request->scene;
        $items_model->save();

        $lastid=$items_model->id;


        Items::where("id",'=', $lastid)
            ->update( array( 'sid' => $lastid,'def_renshu'=>$canyurenshu));

        $query2=$this->content_get_go_codes($zongrenshu,3000,$lastid);

        \Session::flash('success_message', trans('admin.success_add'));
        return redirect('panel/admin/cloud/product_list');

    }
    public function updateitem(Request $request){

        $rules = array(
            'category'        => 'required',
            'brand'        => 'required',
            //'winning_member'        => 'required',
            'product_title'        => 'required|string|max:300',
            // 'product_sub_title'        => 'required|string|max:300',
            //'total_product_price'        => 'required|numeric',
            //'cloud_purchase_price'        => 'required|numeric',
            'maximum_number_period'        => 'required|numeric',
            //'photo'           => 'mimes:jpg,gif,png,jpe,jpeg',

        );
        $this->validate($request, $rules);

        $canyurenshu=0;

        //$money=intval($request->total_product_price);//total price
        //$yunjiage=intval($request->cloud_purchase_price); //cloud single price
        // $zongrenshu=ceil($money/$yunjiage);
        // $code_len=ceil($zongrenshu/3000);
        //  $shenyurenshu=$zongrenshu-$canyurenshu;

        $max_qishu=$request->maximum_number_period;

        $xsjx_time_h=0;
        if($request->datepicker!=''){
            $xsjx_time=strtotime($request->datepicker)?strtotime($request->datepicker):time();
            $xsjx_time_h=intval($request->time_h)?$request->time_h:36000;
            $xsjx_time+=$xsjx_time_h;
        }else{
            $xsjx_time='0';
        }

        $goods_key_pos = isset($request->goods_key['recommend'])?1:0;
        $goods_key_renqi = isset($request->goods_key['popularity'])?1:0;
        $goods_key_bannershop =isset($request->goods_key['bannershop'])?1:0;
        $nowtime = date('Y_m_d');

        $temp="public/eshop/upload/temp/";
        $path="public/eshop/upload/inter_shop/".$nowtime."/";

        if (!file_exists($path)) {
            mkdir($path, 0777);
        }
        $picarr=array();
        $sub_flag=0; //default empty main image uploading.
        if($request->hasFile('imglists')){
            $image_list=$request->file('imglists');

            foreach($image_list as $img){
                $extension              = $img->getClientOriginalExtension();
                $type_mime_shot   = $img->getMimeType();
                $sizeFile                 = $img->getSize();
                $thumbnail              = $nowtime.'-'.str_random(32).'.'.$extension;

                if( $img->move($temp, $thumbnail) ) {

                    $image = Image::make($temp.$thumbnail);

                    if(   $image->width() <640  && $image->height()< 640 ) {
                        $image->fit(640, 640)->save($temp.$thumbnail);
                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);

                    } else {
                        $image->fit(640, 640)->save($temp.$thumbnail);

                        \File::copy($temp.$thumbnail, $path.$thumbnail);
                        \File::delete($temp.$thumbnail);
                    }

                }// End File

                $picarr[]=$path.$thumbnail;

            }
            $sub_flag=1;
        }

        $main_flag=0;//default is empty subimage uploading.
        if( $request->hasFile('thumbnail') )	{

            $extension              = $request->file('thumbnail')->getClientOriginalExtension();
            $type_mime_shot   = $request->file('thumbnail')->getMimeType();
            $sizeFile                 = $request->file('thumbnail')->getSize();
            $thumbnail              = $nowtime.'-'.str_random(32).'.'.$extension;

            if( $request->file('thumbnail')->move($temp, $thumbnail) ) {

                $image = Image::make($temp.$thumbnail);

                if(  $image->width() < 640 && $image->height() < 640 ) {
                    $image->fit(640, 640)->save($temp.$thumbnail);
                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);

                } else {
                    $image->fit(640, 640)->save($temp.$thumbnail);

                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);
                }

            }// End File
            $main_flag=1;
        } // HasFile


        $winning_memeber=$request->winning_member;
        $items_model = new Items();


        $product_id=$request->product_id;
        Items::where("id",'=', $product_id)
            ->update( array( 'cateid'=>$request->category,'brandid'=>$request->brand,
                'title'=>$request->product_title,'title2'=>$request->product_sub_title,'keywords'=>$request->keywords,
                'description'=>$request->description,"zhiding"=>$winning_memeber,
                'maxqishu'=>$max_qishu,'content'=>stripslashes($request->content),'feedback'=>$request->feedback,
                'xsjx_time'=>$xsjx_time, 'pos'=>$goods_key_pos,'renqi'=>$goods_key_renqi,'bannershop'=>$goods_key_bannershop,"scene"=>$request->scene));
        if($main_flag){
            $image_temp=$path.$thumbnail;
            Items::where("id",'=', $product_id)
                ->update(array( 'thumb'=>$image_temp));
        }
        if($sub_flag){
            $picarra_temp=serialize($picarr);
            Items::where("id",'=', $product_id)
                ->update(array( 'picarr'=>$picarra_temp));
        }

        \Session::flash('success_message', trans('admin.success_update'));
        return redirect('panel/admin/cloud/product_list');

    }
    /** generate product order codes */
    function content_get_go_codes($CountNum=null,$len=null,$sid=null){


        $num = ceil($CountNum/$len);
        $code_i = $CountNum;
        if($num == 1){
            $codes=array();
            for($i=1;$i<=$CountNum;$i++){
                $codes[$i]=10000000+$i;
            }shuffle($codes);$codes=serialize($codes);
            $model=new shopcodes();
            $model->s_id=$sid;
            $model->s_cid=1;
            $model->s_len=$CountNum;
            $model->s_codes=$codes;
            $model->s_codes_tmp=$codes;
            $model->save();
            unset($codes);
            return "success";
        }
        $query_1 = true;

        for($k=1;$k<$num;$k++){
            $codes=array();
            for($i=1;$i<=$len;$i++){
                $codes[$i]=10000000+$code_i;
                $code_i--;
            }shuffle($codes);$codes=serialize($codes);

            $model=new shopcodes();
            $model->s_id=$sid;
            $model->s_cid=$k;
            $model->s_len=$len;
            $model->s_codes=$codes;
            $model->s_codes_tmp=$codes;
            $model->save();
            unset($codes);
        }

        $CountNum = $CountNum - (($num-1)*$len);
        $codes=array();
        for($i=1;$i<=$CountNum;$i++){
            $codes[$i]=10000000+$code_i;
            $code_i--;
        }shuffle($codes);$codes=serialize($codes);

        $model=new shopcodes();
        $model->s_id=$sid;
        $model->s_cid=$num;
        $model->s_len=$CountNum;
        $model->s_codes=$codes;
        $model->s_codes_tmp=$codes;
        $model->save();

        unset($codes);
        return "success";
    }
}
