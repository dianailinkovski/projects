<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\upload_setting;
use App\Models\config_setting;
use App\Models\membergorecord;
use Image;
use App\Models\Members;
use App\Models\Slide;
class AdminController extends Controller
{

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function admin()
    {
        $member_count=Members::select('*')->get()->count();
        $latest_members=Members::select('*')->orderBy('time','desc')->paginate(4);
        $latest_go=membergorecord::select('*')->where('huode','>','10000000')->orderBy('id','DESC')->paginate(4);
        // var_dump('sdfdsfdsf');exit;
        return view('admin.dashboard',compact('member_count','latest_members','latest_go'));
        //return view('welcome');
    }

    public function settingsUpload()
    {
        $data=upload_setting::select('*')->whereRaw("1")->first();

        return view('admin.uploads', compact('data'));

    }

    /**
     * @upload setting save
     */
    public function savesettingsupload(Request $request){
        $rules = array(
            'attached_size'        => 'required',
            'image_type'        => 'required',
            'file_type'        => 'required',
            'media_type'        => 'required',
        );

        $this->validate($request, $rules);

        /**
        $get_model = new upload_setting();
        $get_model->file_size=$request->attached_size;
        $get_model->image_type=$request->image_type;
        $get_model->file_types=$request->file_type;
        $get_model->media_type=$request->media_type;
        $get_model->save();
         **/
        upload_setting::where("id",'=', $request->key_id)
            ->update( array( 'file_size'=>$request->attached_size,'image_type'=>$request->image_type,
                'file_types'=>$request->file_type,'media_type'=>$request->media_type));

        \Session::flash('success_message', trans('admin.success_update'));
        return redirect('panel/admin/settings/upload_si');
    }

    public function settingsMailbox()
    {

        return view('admin.mailbox');
        //return view('welcome');
    }
    public function settingsSeo()
    {

        return view('admin.seo');
        //return view('welcome');
    }

    public function settingsPayment()
    {

        $model=new config_setting();
        $data=$model->paymentsetting();
        if(empty($data)){
            $data=(object)array();
            $data->id=0;
            $data->currency_code="";
            $data->merchant_code="";
            $data->payment_id="";
        }

        return view('admin.payment', compact('data'));
        //return view('welcome');
    }

    public function updatesettingsPayment(Request $request){

        $model=new config_setting();
        $model->updatepayemnt($request);
        $data=$model->paymentsetting();

        \Session::flash('success_message', trans('admin.success_update'));
        return view('admin.payment', compact('data'));
    }

    public function settingsWechat()
    {
        $data=config_setting::select('*')->whereRaw("1")->first();

        if(empty($data)){
            $data= (object)array();
            $data->id='';
            $data->username='';
            $data->user='';
            $data->avatar='';
            $data->nick='';
            $data->ghid='';
            $data->appid='';
            $data->appsecret='';
            // var_dump(empty($data));exit;
        }


        return view('admin.wechat',compact('data'));
        //return view('welcome');
    }
    public function savewechat(Request $request){


        $avar_flag=0;
        if( $request->hasFile('thumbnail') )	{

            $temp="public/eshop/upload/temp/";
            $path="public/eshop/img/";
            $nowtime = date('Y_m_d');
            if (!file_exists($path)) {
                mkdir($path, 0777);
            }

            $extension              = $request->file('thumbnail')->getClientOriginalExtension();
            $type_mime_shot   = $request->file('thumbnail')->getMimeType();
            $sizeFile                 = $request->file('thumbnail')->getSize();
            $thumbnail              = $nowtime.'-'.str_random(32).'.'.$extension;


            if( $request->file('thumbnail')->move($temp, $thumbnail) ) {

                $image = Image::make($temp.$thumbnail);

                if(  $image->width() > 1200 && $image->height() > 1000 ) {

                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);

                } else {
                    $image->fit(1200, 1200)->save($temp.$thumbnail);

                    \File::copy($temp.$thumbnail, $path.$thumbnail);
                    \File::delete($temp.$thumbnail);
                }

            }// End File
            $avar_flag=1;
        } // HasFile


        config_setting::where("id",'=', $request->key_id)
            ->update( array( 'user'=>$request->website_address,'username'=>$request->website_address,
                'nick'=>$request->nick,'ghid'=>$request->ghid,
                'appid'=>$request->appid,'appsecret'=>$request->appsecret));

        if($avar_flag){
            config_setting::where("id",'=', $request->key_id)
                ->update( array( 'avatar'=>$path.$thumbnail));
        }
        \Session::flash('success_message', trans('admin.success_update'));
        return redirect('panel/admin/settings/wechat');

    }

    public  function contentlist(){
        $data=Slide::select('*')->orderBy('order','ASC')->get();

        return view('admin.contentlist',compact('data'));
    }
    public  function slide_edit($id=0){
        $data=Slide::select('*')->where('id',$id)->first();
        if(!is_object($data)){
            return redirect()->back();
        }
        return view('admin.edit_slide',compact('data'));
    }
    public  function slide_update(Request $request){

        $s_id=$request->s_id;

        if( $request->hasFile('thumbnail') )	{

            $temp="public/eshop/upload/temp/";
            $path="public/eshop/img/";
            $nowtime = date('Y_m_d');
            if (!file_exists($path)) {
                mkdir($path, 0777);
            }

            $extension              = $request->file('thumbnail')->getClientOriginalExtension();

            $thumbnail              = $request->filename;


            if( $request->file('thumbnail')->move($temp, $thumbnail) ) {

                $image = Image::make($temp.$thumbnail);

                $image->fit(820, 385)->save($temp.$thumbnail);
                \File::copy($temp.$thumbnail, $path.$thumbnail);
                \File::delete($temp.$thumbnail);


            }// End File
            $avar_flag=1;
        } // HasFile

        Slide::where('id',$s_id)->update(array('order'=>$request->order,"title"=>$request->description,"visible"=>$request->status));
        \Session::flash('success_message', trans('admin.success_update'));
        return redirect('panel/admin/settings/contentlist');

    }
    public  function slide_add(){
        return view('admin.add_slide',compact('data'));
    }
    public  function slide_save(Request $request){


        $maxfile=Slide::latest()->value('id');
        $maxfile=$maxfile++;
        $path_url="public/eshop/img/bank_slide.png";
        if( $request->hasFile('thumbnail') )	{

            $temp="public/eshop/upload/temp/";
            $path="public/eshop/img/";
            $nowtime = date('Y_m_d');
            if (!file_exists($path)) {
                mkdir($path, 0777);
            }

            $extension              = $request->file('thumbnail')->getClientOriginalExtension();

            $thumbnail              = "banner0".$maxfile.".".$extension;


            if( $request->file('thumbnail')->move($temp, $thumbnail) ) {

                $image = Image::make($temp.$thumbnail);

                $image->fit(820, 385)->save($temp.$thumbnail);
                \File::copy($temp.$thumbnail, $path.$thumbnail);
                \File::delete($temp.$thumbnail);

                $path_url=$path.$thumbnail;
            }// End File
            $avar_flag=1;
        } // HasFile


        $items_model = new Slide();
        $items_model->img=$path_url;
        $items_model->title=$request->description;
        $items_model->visible=$request->status;
        $items_model->filename=$thumbnail;
        $items_model->order=$request->order;
        $items_model->save();

        \Session::flash('success_message', trans('admin.success_add'));
        return redirect('panel/admin/settings/contentlist');

    }

    public  function slide_delete($id){

        $data=Slide::where('id',$id)->first();
        if(!is_object($data)){
            return redirect()->back();
        }
        unlink($data->img);
        $item = Slide::findOrFail($id);

        $item->delete();
        \Session::flash('success_message', trans('admin.success_delete'));
        return redirect('panel/admin/settings/contentlist');

    }
}
