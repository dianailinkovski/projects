<?php namespace IPay88\Security\Exceptions;

class InvalidReferrerException extends \Exception 
{ 
	protected $message = 'Invalid referrer';
}