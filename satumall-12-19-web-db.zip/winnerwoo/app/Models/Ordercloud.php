<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ordercloud extends Model
{
    //
    protected $table = 'go_member_go_record';
    public function getOrderlist(){
        $return = DB::table('go_member_go_record')->select('*')->where('status','like','%已付款%')->orderByRaw('time DESC')->get();
        return $return;
    }
    public function getOrderlistbybetween($first_dt='',$second_dt=''){
        $return = DB::table('go_member_go_record')->select('*')
            ->whereRaw("time >=$first_dt and time<=$second_dt")
            ->where('status','like','%已付款%')->orderByRaw('time DESC')->get();
        return $return;
    }
    public function getZipOrderlist(){
        $return = DB::table('go_member_go_record')->select('*')->where('huode','!=','0')->orderByRaw('time DESC')->get();
        return $return;
    }
    public function getShippedlist(){
        $return = DB::table('go_member_go_record')->select('*')->where('status','like','%已发货%')->where('huode','!=','0')->orderByRaw('time DESC')->get();
        return $return;
    }
    public function getNotShippedlist(){
        $return = DB::table('go_member_go_record')->select('*')->where('status','like','%未发货%')->where('huode','!=','0')->orderByRaw('time DESC')->get();
        return $return;
    }
    public function getComplitedlist(){
        $return = DB::table('go_member_go_record')->select('*')->where('status','like','%已完成%')->where('huode','!=','0')->orderByRaw('time DESC')->get();
        return $return;
    }
    public function getDiscontinuedlist(){
        $return = DB::table('go_member_go_record')->select('*')->where('status','like','%已作废%')->orderByRaw('time DESC')->get();
        return $return;
    }
    public function getPendinglist(){
        $return = DB::table('go_member_go_record')->select('*')->where('status','like','%待收货%')->orderByRaw('time DESC')->get();
        return $return;
    }

    public function getWinningorder(){
        $return = DB::table('go_member_go_record')->select('*')->where('huode','!=','0')->orderByRaw('time DESC')->get();
        return $return;
    }
    public function getUndeliveredorder(){
        $return = DB::table('go_member_go_record')->select('*')->where('huode','!=','0')->where('status','like','%未发货%')->orderByRaw('time DESC')->get();
        return $return;
    }
    public function getLimitteddisclousre(){
        $return = DB::table('go_shoplist')->select('*')->where('xsjx_time','!=','0')->get();
        return $return;
    }

    public function getLimitteddisclousrebetween($first_dt,$second_dt){
        $return = DB::table('go_shoplist')->select('*')->whereRaw("time>=$first_dt and time <=$second_dt")->get();
        return $return;
    }

    public function getProductmanagement(){
        $return = DB::table('go_shoplist')
            ->join('go_category', 'go_shoplist.cateid', '=', 'go_category.cateid')
            ->select('go_shoplist.*', 'go_category.name')
            ->whereRaw("go_shoplist.q_uid is null")
            ->orderByRaw('go_shoplist.money DESC')->get();
       // $return = DB::table('go_shoplist')->select('*')->whereRaw("q_uid is null")->get();
        return $return;
    }
    public function getProductmanagementbypost($first_dt,$second_dt){
        $return = DB::table('go_shoplist')
            ->join('go_category', 'go_shoplist.cateid', '=', 'go_category.cateid')
            ->select('go_shoplist.*', 'go_category.name')
            ->whereRaw("go_shoplist.q_uid is null")
            ->whereRaw("time>=$first_dt and time <=$second_dt")
            ->orderByRaw('go_shoplist.money DESC')->get();
        // $return = DB::table('go_shoplist')->select('*')->whereRaw("q_uid is null")->get();
        return $return;
    }
    public function getPopularproducts(){
        $return = DB::table('go_shoplist')->select('*')->where('renqi','=','1')->get();

        return $return;
    }
    public function getPopularproductsbypost($first_dt,$second_dt){
        $return = DB::table('go_shoplist')->select('*')->where('renqi','=','1')->whereRaw("time>=$first_dt and time <=$second_dt")->get();

        return $return;
    }

    public function getReversedlist(){
        $return = DB::table('go_shoplist')->select('*')->orderByRaw('qishu DESC')->get();

        return $return;
    }
    public function cloud_positive_list(){
        $return = DB::table('go_shoplist')->select('*')->orderByRaw('qishu ASC')->get();

        return $return;
    }
    public function getReversedprice(){
        $return = DB::table('go_shoplist')->select('*')->orderByRaw('yunjiage DESC')->get();

        return $return;
    }
    public function getOrderprice(){
        $return = DB::table('go_shoplist')->select('*')->orderByRaw('yunjiage ASC')->get();

        return $return;
    }
    public function getReservedproduct(){
        $return = DB::table('go_shoplist')
            ->join('go_category', 'go_shoplist.cateid', '=', 'go_category.cateid')
            ->select('go_shoplist.*', 'go_category.name')
            ->orderByRaw('go_shoplist.money DESC')->get();

        return $return;
    }
    public function getOrderproduct(){
        $return = DB::table('go_shoplist')
            ->join('go_category', 'go_shoplist.cateid', '=', 'go_category.cateid')
            ->select('go_shoplist.*', 'go_category.name')
            ->orderByRaw('go_shoplist.money ASC')->get();

        return $return;
    }
 public function getDisclosed(){
     $return = DB::table('go_shoplist')
         ->join('go_category', 'go_shoplist.cateid', '=', 'go_category.cateid')
         ->select('go_shoplist.*', 'go_category.name')
         ->whereRaw("go_shoplist.q_uid is not null")
         ->orderByRaw('go_shoplist.money DESC')->get();

        return $return;
    }

    /**
    public function getShoplist(){

        $return = DB::table('go_shoplist')
            ->join('go_category', 'go_shoplist.cateid', '=', 'go_category.cateid')
            ->select('go_shoplist.*', 'go_category.name')
            ->get();
        return $return;
    }**/
}
