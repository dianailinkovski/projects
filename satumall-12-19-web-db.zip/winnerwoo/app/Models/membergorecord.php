<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class membergorecord extends Model
{
    //
    protected $table = 'go_member_go_record';


}
