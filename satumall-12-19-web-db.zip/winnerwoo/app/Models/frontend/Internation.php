<?php

namespace App\Models\frontend;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class internation extends Model
{
    //
    protected $table = 'go_shop_general';
    public function getCategory(){
        $return = DB::table('go_category')->select('*')->where( "model","=",'1')->where( "parentid","=",'0')->get();
        return $return;
    }
    public function getChildcategory($cateid=0,$level=0){
        $return = DB::table('go_category')->select('*')->where( "model","=",'1')->where( "parentid","=",$cateid)->orderBy('order','DESC')->get();
        return $return;
    }
    public function getTwochild($cateid=0,$level=0){
        $return = DB::table('go_category')->select('*')->where( "model","=",'1')->where( "parentid","=",$cateid)->orderBy('order','DESC')->get();
        return $return;
    }

    public function getBrand($cateid=0){
        if($cateid==0)
            $return = DB::table('go_brand')->select('*')->orderBy('order','DESC')->get();
        else
            $return = DB::table('go_brand')->select('*')->where( "cateid","=",$cateid)->orderBy('order','DESC')->get();
        return $return;
    }
    public function getShoplistbyblank($order='0'){

        switch($order){
            case '2':
                $return = DB::table('go_shop_general')->select('*')->where("renqi","=","1")->paginate(10);
                break;
            case '4':
                $orders = "addtime DESC";
                $return = DB::table('go_shop_general')->select('*')->orderByRaw($orders)->paginate(10);
                break;
            case '5':
                $orders = "money DESC";
                $return = DB::table('go_shop_general')->select('*')->orderByRaw($orders)->paginate(10);
                break;
            case '6':
                $orders = "money ASC";
                $return = DB::table('go_shop_general')->select('*')->orderByRaw($orders)->paginate(10);
                break;
            default:
                $orders = "addtime DESC";
                $return = DB::table('go_shop_general')->select('*')->orderByRaw($orders)->paginate(5);

        }

        return $return;
    }
    public function getShoplistbycategory($order=0,$sun_id_list=''){

        switch($order){
            case '2':
                $return = DB::table('go_shop_general')->select('*')->whereRaw("cateid in ($sun_id_list)")->where("renqi","=","1")->paginate(10);
                break;
            case '4':
                $orders = "addtime DESC";
                $return = DB::table('go_shop_general')->select('*')->whereRaw("cateid in ($sun_id_list)")->orderByRaw($orders)->paginate(10);
                break;
            case '5':
                $orders = "money DESC";
                $return = DB::table('go_shop_general')->select('*')->whereRaw("cateid in ($sun_id_list)")->orderByRaw($orders)->paginate(10);
                break;
            case '6':
                $orders = "money ASC";
                $return = DB::table('go_shop_general')->select('*')->whereRaw("cateid in ($sun_id_list)")->orderByRaw($orders)->paginate(10);
                break;
            default:
                $orders = "addtime DESC";
                $return = DB::table('go_shop_general')->select('*')->whereRaw("cateid in ($sun_id_list)")->orderByRaw($orders)->paginate(5);

        }

        return $return;
    }
    public function getShoplistbycatbrand($order=0,$sun_id_list='',$brandid='0'){

        switch($order){
            case '2':
                $return = DB::table('go_shop_general')->select('*')->where('brandid','=',$brandid)->wherewhereRaw("cateid in ($sun_id_list)")->where("renqi","=","1")->paginate(10);
                break;
            case '4':
                $orders = "addtime DESC";
                $return = DB::table('go_shop_general')->select('*')->where('brandid','=',$brandid)->whereRaw("cateid in ($sun_id_list)")->orderByRaw($orders)->paginate(10);
                break;
            case '5':
                $orders = "money DESC";
                $return = DB::table('go_shop_general')->select('*')->where('brandid','=',$brandid)->whereRaw("cateid in ($sun_id_list)")->orderByRaw($orders)->paginate(10);
                break;
            case '6':
                $orders = "money ASC";
                $return = DB::table('go_shop_general')->select('*')->where('brandid','=',$brandid)->whereRaw("cateid in ($sun_id_list)")->orderByRaw($orders)->paginate(10);
                break;
            default:
                $orders = "addtime DESC";
                $return = DB::table('go_shop_general')->select('*')->where('brandid','=',$brandid)->whereRaw("cateid in ($sun_id_list)")->orderByRaw($orders)->paginate(5);

        }

        return $return;
    }
    public function getShoplistbybrand($order=0,$brandid=0){

        switch($order){
            case '2':
                $return = DB::table('go_shop_general')->select('*')->where("brandid","=",$brandid)->where("renqi","=","1")->paginate(10);
                break;
            case '4':
                $orders = "addtime DESC";
                $return = DB::table('go_shop_general')->select('*')->where("brandid","=",$brandid)->orderByRaw($orders)->paginate(10);
                break;
            case '5':
                $orders = "money DESC";
                $return = DB::table('go_shop_general')->select('*')->where("brandid","=",$brandid)->orderByRaw($orders)->paginate(10);
                break;
            case '6':
                $orders = "money ASC";
                $return = DB::table('go_shop_general')->select('*')->where("brandid","=",$brandid)->orderByRaw($orders)->paginate(10);
                break;
            default:
                $orders = "addtime DESC";
                $return = DB::table('go_shop_general')->select('*')->where("brandid","=",$brandid)->orderByRaw($orders)->paginate(5);

        }

        return $return;
    }

    public function getProductinf($pid=0){
        $return = DB::table('go_shop_general')
            ->leftJoin('go_category', 'go_category.cateid', '=', 'go_shop_general.cateid')
            ->leftJoin ('go_brand','go_brand.id',"=", 'go_shop_general.brandid')
            ->select('go_shop_general.*','go_category.name','go_brand.name as bname')->where("go_shop_general.id","=",$pid)->first();
       return $return;
    }
}
