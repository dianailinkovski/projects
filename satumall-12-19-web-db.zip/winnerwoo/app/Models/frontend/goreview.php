<?php

namespace App\Models\frontend;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class goreview extends Model
{
    //
    protected $table = 'go_review';

}
