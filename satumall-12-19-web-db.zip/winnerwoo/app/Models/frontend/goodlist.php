<?php

namespace App\Models\frontend;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class goodlist extends Model
{
    //
    protected $table = 'go_shoplist';
    public function getCategory(){
        $return = DB::table('go_category')->select('*')->where( "model","=",'1')->where( "parentid","=",'0')->orderBy('order','DESC')->get();
        return $return;
    }
    public function getChildcategory($cateid=0,$level=0){
        $return = DB::table('go_category')->select('*')->where( "model","=",'1')->where( "parentid","=",$cateid)->orderBy('order','DESC')->get();
        return $return;
    }
    public function getTwochild($cateid=0,$level=0){
        $return = DB::table('go_category')->select('*')->where( "model","=",'1')->where( "parentid","=",$cateid)->orderBy('order','DESC')->get();
        return $return;
    }

    public function getBrand($cateid=0){
        if($cateid==0)
            $return = DB::table('go_brand')->select('*')->orderBy('order','DESC')->get();
        else
            $return = DB::table('go_brand')->select('*')->where( "cateid","=",$cateid)->orderBy('order','DESC')->get();
        return $return;
    }
    public function getShoplistbyblank($order='0',$beetween=1){

        switch($order){
            case '1':
                $orders = "shenyurenshu ASC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '2':
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->where("renqi","=","1")->paginate(9);
                break;
            case '3':
                $orders = "shenyurenshu ASC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '4':
                $orders = "time DESC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '5':
                $orders = "money DESC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '6':
                $orders = "money ASC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            default:
                $orders = "shenyurenshu ASC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
        }

        return $return;
    }
    public function getShoplistbycategory($order=0,$sun_id_list='',$beetween=1){

        switch($order){
            case '1':
                $orders = "shenyurenshu ASC";
                $return = DB::table('go_shoplist')->select('*')
                    ->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '2':
                $return = DB::table('go_shoplist')->select('*')
                    ->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->where("renqi","=","1")->paginate(9);
                break;
            case '3':
                $orders = "shenyurenshu ASC";
                $return = DB::table('go_shoplist')->select('*')
                    ->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '4':
                $orders = "time DESC";
                $return = DB::table('go_shoplist')->select('*')
                    ->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '5':
                $orders = "money DESC";
                $return = DB::table('go_shoplist')->select('*')
                    ->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '6':
                $orders = "money ASC";
                $return = DB::table('go_shoplist')->select('*')
                    ->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->orderByRaw($orders)->paginate(9);
                break;
            default:
                $orders = "shenyurenshu ASC";
                $return = DB::table('go_shoplist')->select('*')
                    ->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->whereRaw("q_uid is null")
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->orderByRaw($orders)->paginate(9);

        }

        return $return;
    }
    public function getShoplistbycatbrand($order=0,$sun_id_list='',$brandid='0',$beetween=1){

        switch($order){
            case '1':
                $orders = "shenyurenshu ASC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
               break;
            case '2':
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->whereRaw("q_uid is null")
                    ->where("renqi","=","1")->paginate(9);
                break;
            case '3':
                $orders = "shenyurenshu ASC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '4':
                $orders = "time DESC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '5':
                $orders = "money DESC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '6':
                $orders = "money ASC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            default:
                $orders = "shenyurenshu ASC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("cateid in ($sun_id_list)")
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);

        }

        return $return;
    }
    public function getShoplistbybrand($order=0,$brandid=0,$beetween=1){

        switch($order){
            case '1':
                $orders = "shenyurenshu ASC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '2':
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("q_uid is null")
                     ->where("renqi","=","1")->paginate(9);
                break;
            case '3':
                $orders = "shenyurenshu ASC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '4':
                $orders = "time DESC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '5':
                $orders = "money DESC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            case '6':
                $orders = "money ASC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);
                break;
            default:
                $orders = "shenyurenshu DESC";
                $return = DB::table('go_shoplist')->select('*')->where('yunjiage','=',$beetween)
                    ->where('scene','!=','1')
                    ->where('brandid','=',$brandid)
                    ->whereRaw("q_uid is null")
                    ->orderByRaw($orders)->paginate(9);

        }

        return $return;
    }

    public function getProductinf($pid=0){
        $return = DB::table('go_shoplist')
            ->join('go_category', 'go_category.cateid', '=', 'go_shoplist.cateid')
            ->join ('go_brand','go_brand.id',"=", 'go_shoplist.brandid')
            ->select('go_shoplist.*','go_category.name','go_brand.name as bname')
            ->where('go_shoplist.scene','!=','1')
            ->where("go_shoplist.id","=",$pid)->first();
       return $return;
    }
    public  function getSideCode($sid=0){


        $return=DB::select(DB::raw("select * from go_shoplist where scene !='1' and sid=$sid order by id desc limit 1,1"));
        //var_dump("select * from go_shoplist where scene !='1' and sid=$sid order by id desc limit 1,1");exit;
        return $return;
    }

    public  function getSideRecord($sid=0,$sid_uid=0){
        $return = DB::table('go_member_go_record')
            ->select('*')
            ->where('shopid','=',$sid)
            ->where("uid","=",$sid_uid)
            ->where("huode","!=",0)
            ->orderBy('id','DESC')
            ->first();
        return $return;
    }
    public static function getipaddress($id,$ipmac=null){

        $record = DB::table('go_member_go_record')
            ->where('id','=',$id)
            ->first();
		
        $ip=explode(',',$record->ip);
        if($ipmac=='ipmac'){
            return $ip[1];
        }elseif($ipmac=='ipcity'){
            return $ip[0];
        }
        return $ip[0].'IP:'.$ip[1];
    }
    public static function get_user_name($uid='',$type='username',$key='sub'){

        if(is_object($uid)){
            if(isset($uid->mobile_number) && !empty($uid->mobile_number)){
                if($key=='sub'){
                    return $uid_mobile = substr($uid->mobile_number,0,3).'***'.substr($uid->mobile_number,6,4);
                }else{
                    return $uid->mobile_number;
                }
            }

            if(isset($uid->username) && !empty($uid->username)){

                return $uid->username;
            }
            if(isset($uid->email) && !empty($uid->email)){
                if($key=='sub'){
                    $email = explode('@',$uid->email);
                    return $uid_email = substr($uid->email,0,2).'*'.$email[1];
                }else{
                    return $uid->email;
                }
            }


            return '';
        }else{

            $uid = intval($uid);
            $info = DB::table('users')  //go_member
                ->where('id','=',$uid)
                ->first();

            if(isset($info->mobile_number) && !empty($info->mobile_number)){
                if($key=='sub'){
                    return $info->mobile_number = substr($info->mobile_number,0,3).'***'.substr($info->mobile_number,6,4);
                }else{
                    return $info->mobile_number;
                }
            }
            if(isset($info->username) && !empty($info->username)){
                return $info->username;
            }

            if(isset($info->email) && !empty($info->email)){
                if($key=='sub'){
                    $email = explode('@',$info->email);
                    return $info->email = substr($info->email,0,2).'*'.$email[1];
                }else{
                    return $info->email;
                }
            }

            if(isset($info->type) && !empty($info->type)){
                return $info->type;
            }
            return '';
        }
    }
}
