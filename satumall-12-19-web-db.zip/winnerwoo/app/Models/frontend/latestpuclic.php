<?php

namespace App\Models\frontend;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class latestpuclic extends Model
{
    //
    protected $table = 'go_shoplist';
    public function getShoplist(){
        $return = DB::table('go_shoplist')->select('*')->whereRaw( "q_uid is not null and q_showtime='N'")->orderBy('q_end_time','DESC')->paginate(12);

        return $return;
    }
    public function getTotalcount(){
        $return = DB::table('go_shoplist')->select('*')->whereRaw( "q_uid is not null and q_showtime='N'")->get()->count();
        return $return;
    }

    public static function get_user_goods_num($uid=null,$sid=null){
        if(empty($uid) || empty($sid)){
            return "";
        }
        //$list = $db->GetList("select * from `@#_member_go_record` where `uid` = '$uid' and `shopid` = '$sid' and `status` LIKE '%已付款%'");
        $list = DB::table('go_member_go_record')->select('*')->where("uid","=" ,$uid)->where("shopid","=" ,$sid)
            ->where('status','like','%已付款%')->get();

        $num=0;
        foreach($list as $v){
            $num+=$v->gonumber;
        }
        return $num;
    }

}
