<?php

namespace App\Models\frontend;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class userinf extends Model
{
    //
    protected $table = 'go_member';
    public function getuserinf($uid=0){
        $return = DB::table('Users')->select('*')->where( "id","=",$uid)->first();
        return $return;
    }
    public function getmemberrecord($uid){
        $return=DB::select(DB::raw("select * from go_member_go_record where uid =$uid  order by id desc limit 0,10"));
        return $return;
    }

    public static function get_shop_if_jiexiao($shopid=0){
        $record = DB::table('go_shoplist')->select('*')->where( "id","=",$shopid)
            ->where( "q_showtime","=","N")->first();

        if(!$record) return null;
        if($record->q_user){
            $record->q_user = unserialize($record->q_user);
            return $record;
        }else{
            return $record;
        }
    }

}
