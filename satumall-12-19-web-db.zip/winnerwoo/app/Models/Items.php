<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class items extends Model
{
    //
    protected $table = 'go_shoplist';

    public function getCategory(){
        $return = DB::table('go_category')->select('*')->where('model',1)->orderByRaw('order_cat ASC')->get();
        return $return;
    }
    public function getShoplist(){
       // $return=DB::table('go_shoplist')
        $return = DB::table('go_shoplist')
            ->join('go_category', 'go_shoplist.cateid', '=', 'go_category.cateid')
            ->select('go_shoplist.*', 'go_category.name')
            ->get();
        return $return;
    }
    public function getbrandbyid($id){
        $return = DB::table('go_brand')->select('*')->where('cateid','=',$id)->orderByRaw("'order' DESC")->get();
        return $return;
    }

}
