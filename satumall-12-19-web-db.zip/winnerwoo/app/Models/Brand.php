<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class brand extends Model
{
    //
    protected $table = 'go_brand';
    public  function getBrandlist(){
        $return = DB::table('go_brand')
        ->join('go_category', 'go_brand.cateid', '=', 'go_category.cateid')
        ->select('go_brand.*', 'go_category.name as cate_name')
        ->orderByRaw('go_brand.order DESC')
        ->get();
        return $return;
    }

}
