<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class upload_setting extends Model
{
    //
    protected $table = 'go_upload_setting';

}
