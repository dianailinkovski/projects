<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class config_setting extends Model
{
    //
    protected $table = 'go_wechat';

    public function paymentsetting(){
        $return = DB::table('go_payment_conf')->select('*')
           ->whereRaw('1')
            ->first();
        return $return;
    }
    public function updatepayemnt($request){
        DB::table('go_payment_conf')->where("id",'=', $request->key_id)
            ->update( array( 'currency_code'=>$request->currency_code,'merchant_code'=>$request->merchant_code,
                'payment_id'=>$request->payment_id));
        return "";
    }

}
