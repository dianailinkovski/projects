<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class members extends Model
{
    //
    protected $table = 'Users';
    public function getMemberlist(){
        // $return = DB::table('go_member')->select('*')->whereRaw( "(emailcode='1' OR mobilecode='1') OR band IS NOT NULL" )->get();
        $return = DB::table('go_member')->select('*')->get();
        return $return;
    }

    public function getTodaymemeber(){
        $date_time=strtotime(date("Y-m-d"));
        $return = DB::table('Users')->select('*')->where('sign_in_time',">=",$date_time )->get();
        return $return;
    }
    public function getNotcertified(){
        $date_time=strtotime(date("Y-m-d"));
        $return = DB::table('Users')->select('*')->where('emailcode',"<>",'1' )->where('mobilecode',"<>",'1' )->get();

        return $return;
    }
    public function getDeletedmember(){
        $return = DB::table('Users')->select('*')->get();
        return $return;
    }
    public function getRechargerecord(){
        $return = DB::table('go_member_account')
            ->join('Users', 'Users.id', '=', 'go_member_account.uid')
            ->select('go_member_account.*', 'Users.name', 'Users.last_name')
            ->whereRaw("go_member_account.content='Card charge'  AND go_member_account.type='1'")
            ->get();
        return $return;//充值
    }
    public function getExpenserecord(){

        $return = DB::table('go_member_go_record')
            ->join('Users', 'Users.id', '=', 'go_member_go_record.uid')
            ->select('go_member_go_record.*', 'Users.name')
            ->get();
        return $return;
    }

    public function getExpenserecordbetweendate($fist_dt='',$second_dt=''){

        $return = DB::table('go_member_go_record')
            ->join('Users', 'Users.id', '=', 'go_member_go_record.uid')
            ->select('go_member_go_record.*', 'Users.name')
            ->whereRaw("go_member_go_record.time>=$fist_dt and go_member_go_record.time<=$second_dt")
            ->get();
        return $return;
    }

}
