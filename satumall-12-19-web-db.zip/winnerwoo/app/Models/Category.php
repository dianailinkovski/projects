<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class category extends Model
{
    //
    protected $table = 'go_category';
    public function getCategorylist(){

        $return = DB::table('go_category')
            ->join('go_model', 'go_category.model', '=', 'go_model.modelid')
            ->select('go_category.*', 'go_model.name as m_name')
            ->orderByRaw('go_category.order_cat ASC')->paginate(20);
        return $return;
    }
    public function getmodellist(){
        $return=DB::table('go_model')
          ->select('*')
          ->get();
        return $return;
    }

    /**
     * @return mixed
     * this is to get the all category list
     */
    public function getallcategorylist(){
        $return=DB::table('go_category')
            ->whereRaw('1')

            ->orderBy('order_cat', 'ASC')
            ->get();
        return $return;
    }
    public function getcalitem($id=0){
          $return=DB::table('go_category')
              ->where('cateid','=',$id)
              ->first();
        return $return;
    }
}
