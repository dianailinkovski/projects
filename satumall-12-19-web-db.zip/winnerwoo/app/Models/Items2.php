<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class items2 extends Model
{
    //
    protected $table = 'go_shop_general';
    public function getCategory(){
        $return = DB::table('go_category')->select('*')->where('model',1)->orderByRaw('order_cat ASC')->get();
        return $return;
    }
    public function getShoplist(){
       // $return=DB::table('go_shoplist')
        $return = DB::table('go_shop_general')
            ->join('go_category', 'go_shop_general.cateid', '=', 'go_category.cateid')
            ->select('go_shop_general.*', 'go_category.name')
            ->get();
        return $return;
    }

}
