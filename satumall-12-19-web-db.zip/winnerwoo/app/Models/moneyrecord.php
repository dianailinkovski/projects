<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class moneyrecord extends Model
{
    //
    protected $table = 'go_member_addmoney_record';

}
