<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class memberaccount extends Model
{
    //
    protected $table = 'go_member_account';


}
