<?php


function microt($time,$x=null){
    $len=strlen($time);
    if($len<13){
        $time=$time."0";
    }
    $list=explode(".",$time);
    if($x=="L"){
        return date("His",$list[0]).substr($list[1],0,3);
    }else if($x=="Y"){
        return date("Y-m-d",$list[0]);
    }else if($x=="H"){
        return date("H:i:s",$list[0]).".".substr($list[1],0,3);
    }else if($x=="r"){
        return date("Y-m-d  H:i",$list[0]);
    }else{
        return date("Y-m-d H:i:s",$list[0]).".".substr($list[1],0,3);
    }
}

function percent($p,$t){
    if($p<=0){return 0;}
    return sprintf('%.2f%%',$p/$t*100);
}


function editor_safe_replace($content){

    $tags = array(
        "'<iframe[^>]*?>.*?</iframe>'is",
        "'<frame[^>]*?>.*?</frame>'is",
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}

function get_user_name($uid=array(),$type='username',$key='sub'){

    if(is_array($uid)){

        if(isset($uid['mobile_number']) && !empty($uid['mobile_number'])){
            if($key=='sub'){
                return $uid_mobile = substr($uid['mobile_number'],0,3).'***'.substr($uid['mobile_number'],6,4);
            }else{
                return $uid['mobile_number'];
            }
        }

        if(isset($uid['username']) && !empty($uid['username'])){

            return $uid['username'];
        }
        if(isset($uid['email']) && !empty($uid['email'])){
            if($key=='sub'){
                $email = explode('@',$uid['email']);
                return $uid_email = substr($uid['email'],0,2).'*'.$email[1];
            }else{
                return $uid['email'];
            }
        }


        return '';
    }
    elseif($type=='mobile'){
        return $uid_mobile = substr($uid,0,3).'***'.substr($uid,6,4);
    }
    else
    return '';
}

/*
 * get added cart list
 */
function get_cartlist(){
    $value=session('p_list');
    return $value;
}
/**
 * after submit order, gettting the pay_cartlist for cloud
 */

function get_paycartlist_cloud(){

    $value=session('cloud_paycarts');
    return $value;
}
/**
 * after submit order, gettting the pay_cartlist for internation
 */
function get_paycartlist_internate(){

    $value=session('inter_paycarts');
    return $value;
}

function _get_ip(){
    if (isset($_SERVER['HTTP_CLIENT_IP']) && strcasecmp($_SERVER['HTTP_CLIENT_IP'], "unknown"))
    $ip = $_SERVER['HTTP_CLIENT_IP'];
    else if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && strcasecmp($_SERVER['HTTP_X_FORWARDED_FOR'], "unknown"))
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if (isset($_SERVER['REMOTE_ADDR']) && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
    $ip = $_SERVER['REMOTE_ADDR'];
    else if (isset($_SERVER['REMOTE_ADDR']) && isset($_SERVER['REMOTE_ADDR']) && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
    $ip = $_SERVER['REMOTE_ADDR'];
    else $ip = "";
    return ($ip);
}

 /* get the ip and address **/
function get_ip($ip=null){

    if($ip){
        $ipmac=$ip;
    }
    else{
        //$ipmac=_get_ip();
        $ipmac=$_SERVER['REMOTE_ADDR'];
        if(strpos($ipmac,"127.0.0.1")===true) return '';
    }
    $location=unserialize(file_get_contents('http://ip-api.com/php/'.$ipmac));
    if($location['status']=='success'){
        $ip= $ipmac.",".$location['regionName'].$location['city'];
    }
    else{
        $ip="";
    }
    //$location = file_get_contents('http://freegeoip.net/json/'."77.99.179.98");

    return $ip;
}

function _htmtocode($content) {
    $content = str_replace('%','%&lrm;',$content);
    $content = str_replace("<", "&lt;", $content);
    $content = str_replace(">", "&gt;", $content);
    $content = str_replace("\n", "<br/>", $content);
    $content = str_replace(" ", "&nbsp;", $content);
    $content = str_replace('"', "&quot;", $content);
    $content = str_replace("'", "&#039;", $content);
    $content = str_replace("$", "&#36;", $content);
    $content = str_replace('}','&rlm;}',$content);
    return $content;
}

function _put_time($time = 0,$test=''){
    if(empty($time)){return $test;}
    $time = substr($time,0,10);
    $ttime = time() - $time;
    if($ttime <= 0 || $ttime < 60){
        return 'a few seconds ago';
    }
    if($ttime > 60 && $ttime <120){
        return '1 minute ago';
    }

    $i = floor($ttime / 60);							//分
    $h = floor($ttime / 60 / 60);						//时
    $d = floor($ttime / 86400);							//天
    $m = floor($ttime / 2592000);						//月
    $y = floor($ttime / 60 / 60 / 24 / 365);			//年
    if($i < 30){
        return $i.'minutes ago';
    }
    if($i > 30 && $i < 60){
        return 'in an hour';
    }
    if($h>=1 && $h < 24){
        return $h.'hour ago';
    }
    if($d>=1 && $d < 30){
        return $d.'days ago';
    }
    if($m>=1 && $m < 12){
        return $m.'month ago';
    }
    if($y){
        return $y.'years ago';
    }
    return "";

}

 function generateRandomString($length = 10) {
    return substr(str_shuffle(str_repeat($x='0123456789467812356789345128833456', ceil($length/strlen($x)) )),1,$length);
}
 function gw_send_sms($user,$pass,$sms_from,$sms_to,$sms_msg)
{
    $query_string = "api.aspx?apiusername=".$user."&apipassword=".$pass;
    $query_string .= "&senderid=".rawurlencode($sms_from)."&mobileno=".rawurlencode($sms_to);
    $query_string .= "&message=".rawurlencode(stripslashes($sms_msg)) . "&languagetype=1";
    $url = "http://gateway.onewaysms.com.au:10001/".$query_string;
    $fd = @implode ('', file ($url));
    if ($fd)
    {
        if ($fd > 0) {
            $ok = "success";
        }
        else {
            $ok = "fail";
        }
    }
    else
    {

        $ok = "fail";
    }
    return $ok;
}