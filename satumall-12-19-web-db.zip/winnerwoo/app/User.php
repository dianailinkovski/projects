<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;
    public $successStatus = 200;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name','last_name', 'email', 'password','address','mobile_number','zip_code','token','user_ip','remember_token','emailcode','mobilecode','jingyan','money','score','qianming','avatar','time','city','sign_in_time','login_time','api_token'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
    public function generateToken() {
        $this->api_token = md5(uniqid(''));
        $this->save();
        return $this->api_token;
    }

}
