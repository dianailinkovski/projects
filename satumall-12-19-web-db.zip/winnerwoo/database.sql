/*
SQLyog Enterprise - MySQL GUI v8.12 
MySQL - 5.5.5-10.1.34-MariaDB : Database - winwoo
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`winwoo` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `winwoo`;

/*Table structure for table `go_article` */

DROP TABLE IF EXISTS `go_article`;

CREATE TABLE `go_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章id',
  `cateid` char(30) NOT NULL COMMENT '文章父ID',
  `author` char(20) DEFAULT NULL,
  `title` char(100) NOT NULL COMMENT '标题',
  `title_style` varchar(100) DEFAULT NULL,
  `thumb` varchar(300) DEFAULT NULL,
  `picarr` text,
  `keywords` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `content` mediumtext COMMENT '内容',
  `hit` int(10) unsigned DEFAULT '0',
  `order` tinyint(3) unsigned DEFAULT NULL,
  `posttime` datetime DEFAULT NULL COMMENT '添加时间',
  `url` varchar(255) DEFAULT NULL,
  `show_enable` enum('1','0') DEFAULT '0' COMMENT 'visilbe or desable',
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cateid` (`cateid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

/*Data for the table `go_article` */

insert  into `go_article`(`id`,`cateid`,`author`,`title`,`title_style`,`thumb`,`picarr`,`keywords`,`description`,`content`,`hit`,`order`,`posttime`,`url`,`show_enable`,`updated_at`,`created_at`) values (2,'2','plj','Common Problem','','public/eshop/upload/content_img/2018_11_19/2018_11_19-Zm0v63RfAqIbi7oCZNuk01KUj5oqmWlN.jpg','a:1:{i:0;s:90:\"public/eshop/upload/content_img/2018_11_19/2018_11_19-TuXkPu5p7S6rH4KHoiOfuU8yt3e8rbV2.jpg\";}',NULL,'11','<p><strong>1, How do I check whether the products I participated in have won a prize?</strong></p>\r\n\r\n<p>After the result of each product is announced, log on to the website, enter &quot;My User Center&quot; and inquire about the winning situation in &quot;My Winning Goods&quot;.</p>\r\n\r\n<p><strong>2, I got the goods. Do I still have to pay other expenses?</strong></p>\r\n\r\n<p>There is no need to pay any other cost.</p>\r\n\r\n<p><strong>3, What should I do after I get the product?</strong></p>\r\n\r\n<p>After you get the goods, you will receive the notice of letter, SMS and email. After that, you must correctly fill in the &quot;My User Center&quot; and authenticate the delivery address to improve or confirm your personal information. We will contact you by telephone within 3 working days after you get the goods.</p>\r\n\r\n<p><strong>4, Is the product genuine? How can it be guaranteed?</strong></p>\r\n\r\n<p>We promise that all the 100% genuine goods can enjoy the national joint insurance service provided by the manufacturers and the obligation to guarantee, exchange and return the goods (the national three-package policy).</p>\r\n\r\n<p><strong>5, How to share the sun?</strong></p>\r\n\r\n<p>After you receive the goods, log on to the website, go to &quot;My User Center&quot; and publish the information in the &quot;Solar List Sharing&quot; area. After the examination, you can also get 400-1500 points award. After you have successfully sunned the sheet, your sunshine sheet will appear in the &quot;sunshine sheet sharing&quot; area of the website, and share the joy with you.</p>\r\n\r\n<p><strong>6, Can I get the goods returned or returned?</strong></p>\r\n\r\n<p>Non quality problems, not within the scope of three packages, do not be returned.</p>\r\n\r\n<p><strong>7, Participate in 1 yuan cloud shopping need to pay attention to what?</strong></p>\r\n\r\n<p>Be sure to fill in the correct and valid contact number and receiving address so that you can get in touch with you in time when you win the lottery.</p>\r\n\r\n<p><strong>8, How to do online banking recharge without arriving in time?</strong></p>\r\n\r\n<p>There may be several reasons for the failure of online payment to arrive in time:</p>\r\n\r\n<p>Firstly, payment data is not transmitted to payment system in time because of network speed or payment interface.</p>\r\n\r\n<p>Second, the slow network speed, data transmission timeout, so that the bank can not successfully dock back-end payment information, resulting in successful bank transactions and payment back-end display failure;</p>\r\n\r\n<p>Third, on-line payment using some firewall software, sometimes blocked the bank interface pop-up window, which will cause the bank to be deducted fees, but not yet paid on our website. But you can rest assured that every day we will check the previous day&#39;s orders one by one according to the detailed list of accounts in the banking system. If there is a problem order, we will add it manually.</p>\r\n\r\n<p>Suggestion feedback</p>\r\n\r\n<p>If you have any questions or suggestions about our help center, please let us know.</p>',55,3,'2018-11-21 01:57:28',NULL,'0','2018-11-21 01:57:28',NULL),(4,'3','rvf','Security System','','','a:0:{}',NULL,'22','<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3>100% genuine guarantee</h3>\r\n\r\n<p>Cloud purchase international carefully selected quality service brand merchants to protect the whole product 100% brand authentic.</p>\r\n\r\n<h3>100% fairness and justice</h3>\r\n\r\n<p>The whole process is completely transparent, you can always view the number of participants in each commodity, the number of participants, the list of participants and winning information and other records.</p>\r\n\r\n<h3>Free Express</h3>\r\n\r\n<p>Cloud purchase international commitment to free all the courier. (except Hong Kong, Macao and Taiwan)</p>',100,0,'2018-08-31 00:00:00',NULL,'0','2018-08-31 16:26:57',NULL),(5,'3','nkor','Privacy','','','a:0:{}',NULL,'33','<p>11111</p>\r\n\r\n<p>Cloud Buy International strictly controls the supply channels, all goods are purchased directly from the official brand and brand dealers, and obtain the official brand network sales authorization, if you believe that the goods purchased by Cloud Buy is fake, and can provide the relevant national quality inspection agency certification documents, after confirmation, in return for the amount of goods at the same time It also provides false one compensation ten service guarantee. In order to protect your interests, the following are the items for cloud purchase:</p>\r\n\r\n<p>1. Cloud Purchase International guarantees that all commodities are genuine goods and shipped through regular channels. All commodities can enjoy the national joint guarantee service of manufacturers. According to the national three-package policy, it fulfills the obligations of warranty, replacement and return for the commodities sold.</p>\r\n\r\n<p>2. In the event of a functional failure specified in the National Three-Party Package, you may choose to exchange or repair the goods if the failure is confirmed by the manufacturer&#39;s designated or special after-sales service center. You can only enjoy free maintenance service during the warranty period if it exceeds 15 days. In order not to delay your use and shorten the maintenance time of the defective goods, we suggest that you contact the manufacturer&#39;s after-sales service center directly for processing. You can also directly in the warranty card to find the goods corresponding to the manufacturers throughout the country after-sales service center contact processing.</p>\r\n\r\n<p>3. Cloud Buy International sincerely reminds the vast number of lucky people when you receive the goods, please try to personally sign and collect and unpack the case for inspection, if there is any problem (damage in transit) do not sign! Negotiate with the courier, refuse to sign, return!</p>\r\n\r\n<p>4. If quality problems are found after receiving the goods, please do not deal with them privately and keep the original packing properly. Contact the international customer service staff of Cloud Buy as soon as possible. The problem will be solved by Cloud Buy International in 48 hours through consultation with the shipping mall. If there is any breakage or loss, we will not be able to return the goods for you.</p>\r\n\r\n<p>If there is any objection to the result of negotiation, please go to the local manufacturer&#39;s after-sales service center for testing and issue a formal test report (for some manufacturers&#39;after-sales service center can not provide the test report, need to provide maintenance inspection documents), if the test report is confirmed to be a quality problem, then the test will be carried out. The test report, the defective goods and the complete package accessories shall be returned to the consignor&#39;s Mall for transshipment, and the relevant fees incurred shall be borne by the responsible party of Yunnan Buy International.</p>\r\n\r\n<p>Cloud Buy International electronic products and accessories due to the production process or warehousing logistics reasons, there may be failure in the process of receiving or using the probability, Cloud Buy International can not guarantee that all the goods are faulty, but we guarantee that the goods sold are brand-new genuine goods, can provide formal after-sales protection. We guarantee the normal channel and quality of the goods. If you doubt the quality of the goods received, please provide a written appraisal issued by the manufacturer or the official, and we will deal with it in accordance with national laws. However, for any fraudulent act, cloud purchase international will retain the right to pursue legal liability according to law. The final interpretation right of the rules is owned by cloud purchase international.</p>',30,0,'2018-08-28 00:00:00',NULL,'0','2018-11-19 07:26:52',NULL),(6,'3','6yef','Risk Warning','','','a:0:{}',NULL,'44','<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>As a certified merchant of Ping An Bank, Internet Bank Online, Fast Money, UnionPay Online and Finance Payment Tong, Yun Buy International strictly follows the safety criteria of online shopping, and fully guarantees the safety of your online payment by means of high security payment methods such as Internet Bank Online, Fast Money, UnionPay Online and Finance Payment Tong.</p>',23,0,'2018-08-28 00:00:00',NULL,'0','2018-11-19 07:27:24',NULL),(16,'34','cde','Understand Us',NULL,NULL,'a:0:{}',NULL,'88','<p>We are a Winner Lucky Team.(Sorry this is on development.)</p>\r\n\r\n<p>We will go back soon.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Thank you.</p>',0,NULL,'2018-09-12 00:00:00',NULL,'0','2018-08-31 16:25:32',NULL),(13,'34','admin','Contact us','','','a:0:{}',NULL,'90','<p>&nbsp;</p>\r\n\r\n<p>Contact us</p>\r\n\r\n<p>Hotline:</p>\r\n\r\n<p>Mailbox:</p>\r\n\r\n<p>Address:</p>\r\n\r\n<p>Zip code:</p>\r\n\r\n<p>Business cooperation</p>\r\n\r\n<p>Cloud Buy International has a large domestic consumer groups and professional and efficient e-commerce platform, sincerely invite all brand suppliers to enter into business cooperation with us to create a better future of China&#39;s e-commerce.</p>\r\n\r\n<p>Market promotion</p>\r\n\r\n<p>With the development of Cloud Buy International and the development of markets all over the country, you are welcome to join hands with us to develop together. Hand in hand.</p>\r\n\r\n<p>Telephone:</p>\r\n\r\n<p>Mailbox:</p>\r\n\r\n<p>Media attention</p>\r\n\r\n<p>With the development of Cloud Buy International, all kinds of media are welcome to come to communicate and guide. At the same time, all kinds of contents are welcome to cooperate in planning and dissemination. Your attention and support, interviews and reports will become an indispensable part of the growth of Cloud Buy.</p>\r\n\r\n<p>Telephone:</p>\r\n\r\n<p>Mailbox:</p>\r\n\r\n<p>&nbsp;</p>',61,1,'2018-08-28 00:00:00',NULL,'0','2018-08-31 16:26:25',NULL),(20,'2','435','Feedback',NULL,'public/eshop/upload/content_img/2018_08_31/2018_08_31-oVuxflSZ627mCYwXHBbmHHzn1iqMUmyi.jpeg','a:1:{i:0;s:90:\"public/eshop/upload/content_img/2018_08_31/2018_08_31-aiAf61wean46hoy5A57Uo0HQKPwqjxDX.png\";}','333','444','<p>45555</p>',55,1,'2018-08-22 00:00:00',NULL,'0','2018-11-19 07:28:31','2018-08-31 03:15:14'),(22,'2',NULL,'Shopping Guide',NULL,NULL,'a:0:{}',NULL,'总结','<p>有中英文双语,自行选择语言</p>',55,1,'2018-11-15 00:00:00',NULL,'0','2018-11-19 07:29:14','2018-11-15 14:41:19'),(25,'2',NULL,'test',NULL,NULL,NULL,NULL,NULL,'<p>test</p>',0,1,'2018-11-21 03:04:28',NULL,'0','2018-11-21 03:04:28','2018-11-21 03:04:28');

/*Table structure for table `go_brand` */

DROP TABLE IF EXISTS `go_brand`;

CREATE TABLE `go_brand` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cateid` varchar(255) DEFAULT NULL COMMENT '所属栏目ID',
  `status` varchar(255) DEFAULT 'Y' COMMENT '显示隐藏',
  `name` varchar(255) DEFAULT NULL,
  `order` int(11) DEFAULT '1',
  `thumb` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `order` (`order`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='品牌表';

/*Data for the table `go_brand` */

insert  into `go_brand`(`id`,`cateid`,`status`,`name`,`order`,`thumb`,`url`,`created_at`,`updated_at`) values (10,'6','Y','苹果',1,NULL,NULL,NULL,NULL),(11,'6','Y','三星',1,NULL,NULL,NULL,NULL),(13,'12','Y','尼康',3,NULL,NULL,NULL,NULL),(14,'18','Y','苹果',10,NULL,NULL,NULL,'2018-11-01 02:42:50'),(15,'17','Y','华为',1,NULL,NULL,NULL,NULL),(16,'17','Y','vivo',10,NULL,NULL,NULL,NULL),(31,'43','Y','testBrand',1,NULL,NULL,'2018-11-19 01:37:50','2018-11-19 01:37:50'),(20,'13','Y','苹果',1,NULL,NULL,NULL,NULL),(21,'19','Y','苹果',1,NULL,NULL,NULL,NULL),(22,'22','Y','小米',1,NULL,NULL,NULL,NULL),(23,'21','Y','小米',1,NULL,NULL,NULL,NULL),(29,'14','Y','seiko',1,NULL,NULL,'2018-09-01 15:55:44','2018-09-01 15:55:44'),(32,'50','Y','Others',1,NULL,NULL,'2018-11-21 02:42:54','2018-11-21 02:42:54');

/*Table structure for table `go_category` */

DROP TABLE IF EXISTS `go_category`;

CREATE TABLE `go_category` (
  `cateid` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '栏目id',
  `parentid` smallint(6) NOT NULL COMMENT '父ID',
  `channel` tinyint(4) NOT NULL DEFAULT '0',
  `model` tinyint(1) NOT NULL COMMENT '栏目模型',
  `name` varchar(255) NOT NULL COMMENT '栏目名称',
  `catdir` char(20) NOT NULL COMMENT '英文名',
  `url` varchar(255) DEFAULT NULL,
  `info` text,
  `order` smallint(6) DEFAULT '1' COMMENT '排序',
  `cids` varchar(100) DEFAULT NULL,
  `html` tinyint(1) DEFAULT '0',
  `property` varchar(500) DEFAULT NULL COMMENT '分类属性',
  `level` int(5) DEFAULT NULL,
  `order_cat` varchar(500) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`cateid`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `order` (`order`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COMMENT='栏目表';

/*Data for the table `go_category` */

insert  into `go_category`(`cateid`,`parentid`,`channel`,`model`,`name`,`catdir`,`url`,`info`,`order`,`cids`,`html`,`property`,`level`,`order_cat`,`updated_at`,`created_at`) values (1,0,0,2,'Help','help','','a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";N;s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}',1,NULL,0,NULL,0,'001','2018-11-19 15:29:49',NULL),(2,1,0,2,'Beginner\'s guide','Beginner\'s guide','','a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";N;s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}',1,NULL,0,NULL,1,'001.002','2018-11-19 15:32:34',NULL),(3,1,0,2,'Customer Service','Service support','','a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";N;s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}',1,NULL,0,NULL,1,'001.003','2018-11-19 16:04:15',NULL),(4,1,0,2,'Product distribution','Product distribution','','a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";N;s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}',1,NULL,0,NULL,1,'001.004','2018-11-19 15:33:22',NULL),(5,0,0,1,'Mobile Phone','Mobile Phone','','a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";N;s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}',6,NULL,0,NULL,0,'005','2018-11-01 02:39:02',NULL),(34,1,0,2,'About us','about us','','a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";N;s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}',1,NULL,0,NULL,1,'001.034','2018-11-19 15:33:47',NULL),(17,5,0,1,'Huawei','Huawei','','a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";N;s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}',1,NULL,0,NULL,1,'005.017','2018-11-01 02:31:57',NULL),(18,5,0,1,'Apple','Apple','','a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";N;s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}',1,NULL,0,NULL,1,'005.018','2018-11-01 02:39:31',NULL),(48,0,0,1,'Home & Lifestyle','Toys','','a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";N;s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}',1,NULL,0,NULL,NULL,'048','2018-11-21 02:21:41','2018-11-21 02:18:05'),(42,5,0,1,'Toys','Toys','','a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";N;s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}',1,NULL,0,NULL,NULL,'005.035','2018-11-12 09:11:56','2018-11-12 09:11:23'),(43,42,0,1,'e toys','e toys','','a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";N;s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}',1,NULL,0,NULL,NULL,'005.035.043','2018-11-12 09:18:37','2018-11-12 09:18:37'),(50,48,0,1,'Decorations','Decorations','','a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";N;s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}',1,NULL,0,NULL,NULL,'048.049','2018-11-21 02:22:25','2018-11-21 02:22:25'),(51,0,0,1,'Test','Test','','a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";s:4:\"test\";s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}',1,NULL,0,NULL,NULL,'051','2018-11-23 09:11:46','2018-11-23 09:11:46');

/*Table structure for table `go_member_account` */

DROP TABLE IF EXISTS `go_member_account`;

CREATE TABLE `go_member_account` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(1) DEFAULT NULL COMMENT '充值1/消费-1',
  `pay` char(20) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL COMMENT '详情',
  `money` mediumint(8) NOT NULL DEFAULT '0' COMMENT '金额',
  `time` char(20) NOT NULL,
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=373 DEFAULT CHARSET=utf8 COMMENT='会员账户明细';

/*Data for the table `go_member_account` */

insert  into `go_member_account`(`uid`,`type`,`pay`,`content`,`money`,`time`,`id`,`created_at`,`updated_at`) values (21,-1,'account','Purchased Goods',1,'1541042268',315,'2018-11-01 03:17:49','2018-11-01 03:17:49'),(21,1,'Integral','Purchased1times Products',20,'1541042268',316,'2018-11-01 03:17:49','2018-11-01 03:17:49'),(39,-1,'account','Purchased Goods',1,'1541042932',317,'2018-11-01 03:28:52','2018-11-01 03:28:52'),(39,1,'Integral','Purchased1times Products',20,'1541042932',318,'2018-11-01 03:28:52','2018-11-01 03:28:52'),(39,-1,'account','Purchased Goods',1,'1541043027',319,'2018-11-01 03:30:27','2018-11-01 03:30:27'),(39,1,'Integral','Purchased1times Products',20,'1541043027',320,'2018-11-01 03:30:27','2018-11-01 03:30:27'),(21,-1,'account','Purchased Goods',3,'1541043209',321,'2018-11-01 03:33:29','2018-11-01 03:33:29'),(21,1,'Integral','Purchased3times Products',60,'1541043209',322,'2018-11-01 03:33:29','2018-11-01 03:33:29'),(40,-1,'account','Purchased Goods',2,'1541054555',323,'2018-11-01 06:42:35','2018-11-01 06:42:35'),(40,1,'Integral','Purchased2times Products',40,'1541054555',324,'2018-11-01 06:42:35','2018-11-01 06:42:35'),(40,-1,'account','Purchased Goods',1,'1541054813',325,'2018-11-01 06:46:53','2018-11-01 06:46:53'),(40,1,'Integral','Purchased1times Products',20,'1541054813',326,'2018-11-01 06:46:53','2018-11-01 06:46:53'),(40,-1,'account','Purchased Goods',3,'1541054880',327,'2018-11-01 06:48:00','2018-11-01 06:48:00'),(40,1,'Integral','Purchased3times Products',60,'1541054880',328,'2018-11-01 06:48:00','2018-11-01 06:48:00'),(40,-1,'account','Purchased Goods',1,'1541055354',329,'2018-11-01 06:55:54','2018-11-01 06:55:54'),(40,1,'Integral','Purchased1times Products',20,'1541055354',330,'2018-11-01 06:55:54','2018-11-01 06:55:54'),(21,-1,'account','Purchased Goods',1,'1541090275',331,'2018-11-01 16:37:55','2018-11-01 16:37:55'),(21,1,'Integral','Purchased1times Products',20,'1541090275',332,'2018-11-01 16:37:55','2018-11-01 16:37:55'),(40,-1,'account','Purchased Goods',3,'1541123884',333,'2018-11-02 01:58:04','2018-11-02 01:58:04'),(40,1,'Integral','Purchased3times Products',60,'1541123884',334,'2018-11-02 01:58:04','2018-11-02 01:58:04'),(46,-1,'account','Purchased Goods',1,'1541227364',335,'2018-11-03 06:42:44','2018-11-03 06:42:44'),(46,1,'Integral','Purchased1times Products',20,'1541227364',336,'2018-11-03 06:42:44','2018-11-03 06:42:44'),(44,-1,'account','Purchased Goods',1,'1541422423',337,'2018-11-05 12:53:44','2018-11-05 12:53:44'),(44,1,'Integral','Purchased1times Products',20,'1541422423',338,'2018-11-05 12:53:44','2018-11-05 12:53:44'),(46,-1,'account','Purchased Goods',2,'1541472583',339,'2018-11-06 02:49:43','2018-11-06 02:49:43'),(46,1,'Integral','Purchased2times Products',40,'1541472583',340,'2018-11-06 02:49:43','2018-11-06 02:49:43'),(46,-1,'account','Purchased Goods',1,'1541472810',341,'2018-11-06 02:53:30','2018-11-06 02:53:30'),(46,1,'Integral','Purchased1times Products',20,'1541472810',342,'2018-11-06 02:53:30','2018-11-06 02:53:30'),(46,-1,'account','Purchased Goods',2,'1541472853',343,'2018-11-06 02:54:13','2018-11-06 02:54:13'),(46,1,'Integral','Purchased2times Products',40,'1541472853',344,'2018-11-06 02:54:13','2018-11-06 02:54:13'),(46,-1,'account','Purchased Goods',1,'1541472880',345,'2018-11-06 02:54:40','2018-11-06 02:54:40'),(46,1,'Integral','Purchased1times Products',20,'1541472880',346,'2018-11-06 02:54:40','2018-11-06 02:54:40'),(44,-1,'account','Purchased Goods',1,'1542013324',347,'2018-11-12 09:02:05','2018-11-12 09:02:05'),(44,1,'Integral','Purchased1times Products',20,'1542013324',348,'2018-11-12 09:02:05','2018-11-12 09:02:05'),(21,-1,'account','Purchased Goods',1,'1542077223',349,'2018-11-13 02:47:03','2018-11-13 02:47:03'),(21,1,'Integral','Purchased1times Products',20,'1542077223',350,'2018-11-13 02:47:03','2018-11-13 02:47:03'),(45,-1,'account','Purchased Goods',4,'1542420038',351,'2018-11-17 02:00:38','2018-11-17 02:00:38'),(45,1,'Integral','Purchased4times Products',80,'1542420038',352,'2018-11-17 02:00:38','2018-11-17 02:00:38'),(44,-1,'account','Purchased Goods',1,'1542420285',353,'2018-11-17 02:04:45','2018-11-17 02:04:45'),(44,1,'Integral','Purchased1times Products',20,'1542420285',354,'2018-11-17 02:04:45','2018-11-17 02:04:45'),(21,-1,'account','Purchased Goods',1,'1542428392',355,'2018-11-17 04:19:52','2018-11-17 04:19:52'),(21,1,'Integral','Purchased1times Products',20,'1542428392',356,'2018-11-17 04:19:52','2018-11-17 04:19:52'),(39,-1,'account','Purchased Goods',1,'1542428783',357,'2018-11-17 04:26:23','2018-11-17 04:26:23'),(39,1,'Integral','Purchased1times Products',20,'1542428783',358,'2018-11-17 04:26:23','2018-11-17 04:26:23'),(39,-1,'account','Purchased Goods',2,'1542430266',359,'2018-11-17 04:51:06','2018-11-17 04:51:06'),(39,1,'Integral','Purchased2times Products',40,'1542430266',360,'2018-11-17 04:51:06','2018-11-17 04:51:06'),(49,-1,'account','Purchased Goods',1,'1542590822',361,'2018-11-19 01:27:02','2018-11-19 01:27:02'),(49,1,'Integral','Purchased1times Products',20,'1542590822',362,'2018-11-19 01:27:02','2018-11-19 01:27:02'),(21,-1,'account','Purchased Goods',1,'1542599605',363,'2018-11-19 03:53:25','2018-11-19 03:53:25'),(21,1,'Integral','Purchased1times Products',20,'1542599605',364,'2018-11-19 03:53:25','2018-11-19 03:53:25'),(49,-1,'account','Purchased Goods',1,'1542767866',365,'2018-11-21 02:37:46','2018-11-21 02:37:46'),(49,1,'Integral','Purchased1times Products',20,'1542767866',366,'2018-11-21 02:37:46','2018-11-21 02:37:46'),(49,-1,'account','Purchased Goods',100,'1542768602',367,'2018-11-21 02:50:02','2018-11-21 02:50:02'),(49,1,'Integral','Purchased 1 Popular Product',100,'1542768602',368,'2018-11-21 02:50:02','2018-11-21 02:50:02'),(21,-1,'account','Purchased Goods',1,'1543020780',369,'2018-11-24 00:53:00','2018-11-24 00:53:00'),(21,1,'Integral','Purchased1times Products',20,'1543020780',370,'2018-11-24 00:53:00','2018-11-24 00:53:00'),(21,-1,'account','Purchased Goods',2,'1543023896',371,'2018-11-24 01:44:56','2018-11-24 01:44:56'),(21,1,'Integral','Purchased2times Products',40,'1543023896',372,'2018-11-24 01:44:56','2018-11-24 01:44:56');

/*Table structure for table `go_member_addmoney_record` */

DROP TABLE IF EXISTS `go_member_addmoney_record`;

CREATE TABLE `go_member_addmoney_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `code` char(20) NOT NULL,
  `money` decimal(10,2) unsigned NOT NULL,
  `pay_type` char(10) NOT NULL,
  `status` char(20) NOT NULL,
  `time` int(10) NOT NULL,
  `score` int(10) unsigned DEFAULT NULL,
  `scookies` text COMMENT '购物车cookie',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=110 DEFAULT CHARSET=utf8;

/*Data for the table `go_member_addmoney_record` */

/*Table structure for table `go_member_del` */

DROP TABLE IF EXISTS `go_member_del`;

CREATE TABLE `go_member_del` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL COMMENT '用户名',
  `email` varchar(50) DEFAULT NULL COMMENT '用户邮箱',
  `mobile` char(11) DEFAULT NULL COMMENT '用户手机',
  `password` char(32) DEFAULT NULL COMMENT '密码',
  `user_ip` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL COMMENT '用户头像',
  `qianming` varchar(255) DEFAULT NULL COMMENT '用户签名',
  `groupid` tinyint(4) unsigned DEFAULT '0' COMMENT '用户权限组',
  `addgroup` varchar(255) DEFAULT NULL COMMENT '用户加入的圈子组1|2|3',
  `money` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '账户金额',
  `emailcode` char(21) DEFAULT '-1' COMMENT '邮箱认证码',
  `mobilecode` char(21) DEFAULT '-1' COMMENT '手机认证码',
  `passcode` char(21) DEFAULT '-1' COMMENT '找会密码认证码-1,1,码',
  `reg_key` varchar(100) DEFAULT NULL COMMENT '注册参数',
  `score` int(10) unsigned NOT NULL DEFAULT '0',
  `jingyan` int(10) unsigned DEFAULT '0',
  `yaoqing` int(10) unsigned DEFAULT NULL,
  `band` varchar(255) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `login_time` int(10) unsigned DEFAULT '0',
  `sign_in_time` mediumint(8) NOT NULL DEFAULT '0' COMMENT '连续签到天数',
  `sign_in_date` char(10) NOT NULL DEFAULT '' COMMENT '上次签到日期',
  `sign_in_time_all` mediumint(8) NOT NULL DEFAULT '0' COMMENT '总签到次数',
  PRIMARY KEY (`uid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=13565 DEFAULT CHARSET=utf8 COMMENT='会员表';

/*Data for the table `go_member_del` */

/*Table structure for table `go_member_go_order` */

DROP TABLE IF EXISTS `go_member_go_order`;

CREATE TABLE `go_member_go_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(20) DEFAULT NULL COMMENT '订单号',
  `code_tmp` tinyint(3) unsigned DEFAULT NULL COMMENT '相同订单',
  `username` varchar(30) NOT NULL,
  `uphoto` varchar(255) DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL COMMENT '会员id',
  `shopid` int(6) unsigned NOT NULL COMMENT '商品id',
  `shopname` varchar(255) NOT NULL COMMENT '商品名',
  `shopimg` varchar(255) DEFAULT NULL,
  `shopshuliang` smallint(6) NOT NULL DEFAULT '0' COMMENT '期数',
  `shopdanjia` float(11,2) unsigned DEFAULT NULL COMMENT '购买次数',
  `moneycount` decimal(10,2) NOT NULL,
  `pay_type` char(10) DEFAULT NULL COMMENT '付款方式',
  `ip` varchar(255) DEFAULT NULL,
  `status` char(30) DEFAULT NULL COMMENT '订单状态',
  `time` char(21) NOT NULL COMMENT '购买时间',
  `shouhuo_name` varchar(255) DEFAULT NULL,
  `shouhuo_address` varchar(255) DEFAULT NULL,
  `shouhuo_phone` varchar(255) DEFAULT NULL,
  `isfahuo` int(11) DEFAULT NULL,
  `fahuo_kuaidi` varchar(255) DEFAULT NULL,
  `fahuo_code` varchar(255) DEFAULT NULL,
  `property` text COMMENT '属性',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `shopid` (`shopid`) USING BTREE,
  KEY `time` (`time`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=131 DEFAULT CHARSET=utf8 COMMENT='云购记录表';

/*Data for the table `go_member_go_order` */

insert  into `go_member_go_order`(`id`,`code`,`code_tmp`,`username`,`uphoto`,`uid`,`shopid`,`shopname`,`shopimg`,`shopshuliang`,`shopdanjia`,`moneycount`,`pay_type`,`ip`,`status`,`time`,`shouhuo_name`,`shouhuo_address`,`shouhuo_phone`,`isfahuo`,`fahuo_kuaidi`,`fahuo_code`,`property`,`created_at`,`updated_at`) values (129,'G15407969038309179',0,'te*gmail.com','public/avatar/515254438192hrbkaixk4hofr3.jpg',21,10,'ew','public/eshop/upload/inter_shop_ge/2018_10_11/2018_10_11-FSKsMyHn1UnOreHFlPsIpl9DX5mRSq8Q.jpg',1,50.00,'50.00','account','ip','未付款,未发货,未完成','1540796903.831',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-10-29 07:08:23','2018-10-29 07:08:23'),(130,'G15427686022452985',0,'016***4195','public\\avatar\\default.jpg',49,11,'fada','public/eshop/upload/inter_shop_ge/2018_11_21/2018_11_21-g4lC7ok6a4kM7JxI12XjBWCVT52hy9FW.jpg',1,100.00,'100.00','account','ip','未付款,未发货,未完成','1542768602.245',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-11-21 02:50:02','2018-11-21 02:50:02');

/*Table structure for table `go_member_go_record` */

DROP TABLE IF EXISTS `go_member_go_record`;

CREATE TABLE `go_member_go_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(20) DEFAULT NULL COMMENT '订单号',
  `code_tmp` tinyint(3) unsigned DEFAULT NULL COMMENT '相同订单',
  `username` varchar(30) NOT NULL,
  `uphoto` varchar(255) DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL COMMENT '会员id',
  `shopid` int(6) unsigned NOT NULL COMMENT '商品id',
  `shopname` varchar(255) NOT NULL COMMENT '商品名',
  `shopqishu` smallint(6) NOT NULL DEFAULT '0' COMMENT '期数',
  `gonumber` smallint(5) unsigned DEFAULT NULL COMMENT '购买次数',
  `goucode` longtext NOT NULL COMMENT '云购码',
  `moneycount` decimal(10,2) NOT NULL,
  `huode` char(50) NOT NULL DEFAULT '0' COMMENT '中奖码',
  `pay_type` char(10) DEFAULT NULL COMMENT '付款方式',
  `ip` varchar(255) DEFAULT NULL,
  `status` char(30) DEFAULT NULL COMMENT '订单状态',
  `company_money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `company_code` char(20) DEFAULT NULL,
  `company` char(20) DEFAULT NULL,
  `time` char(21) NOT NULL COMMENT '购买时间',
  `cqssc` varchar(255) DEFAULT NULL,
  `cqssctime` varchar(255) DEFAULT NULL,
  `cqsscsign` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `shopid` (`shopid`) USING BTREE,
  KEY `time` (`time`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=249 DEFAULT CHARSET=utf8 COMMENT='云购记录表';

/*Data for the table `go_member_go_record` */

insert  into `go_member_go_record`(`id`,`code`,`code_tmp`,`username`,`uphoto`,`uid`,`shopid`,`shopname`,`shopqishu`,`gonumber`,`goucode`,`moneycount`,`huode`,`pay_type`,`ip`,`status`,`company_money`,`company_code`,`company`,`time`,`cqssc`,`cqssctime`,`cqsscsign`,`created_at`,`updated_at`) values (221,'A15410422689736811',0,'861***8147','public/avatar/515254438192hrbkaixk4hofr3.jpg',21,168,'Huawei Ascend Mate7 Moonlight Silver Mobile Unicom Dual 4G Mobile Phone Dual SIM Dual Standby',1,1,'10000001','1.00','10000001','account','ip','已付款,已发货,已完成','0.01','*666中单','das','1541042268.974','70084','2018-11-01 10:40:40','20181101028','2018-11-01 03:17:48','2018-11-21 08:12:41'),(222,'A15410429324376762',0,'012***6789','public\\avatar\\default.jpg',39,168,'Huawei Ascend Mate7 Moonlight Silver Mobile Unicom Dual 4G Mobile Phone Dual SIM Dual Standby',1,1,'10000002','1.00','0','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1541042932.438',NULL,NULL,NULL,'2018-11-01 03:28:52','2018-11-01 03:28:52'),(223,'A15410430277033466',0,'012***6789','public\\avatar\\default.jpg',39,169,'Apple iPhone 6 Plus (A1524) 16GB Gold Mobile',1,1,'10000001','1.00','10000001','account','ip','已付款,已发货,已完成','0.00','asd','ads','1541043027.703','70084','2018-11-01 10:40:40','20181101028','2018-11-01 03:30:27','2018-11-27 15:56:58'),(224,'A15410432091391378',0,'861***8147','public/avatar/515254438192hrbkaixk4hofr3.jpg',21,166,'Apple 1 (Apple) iPhone 6 (A1586) 16GB Gold Mobile',1,3,'10000003,10000004,10000002','3.00','0','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1541043209.139',NULL,NULL,NULL,'2018-11-01 03:33:29','2018-11-01 03:33:29'),(225,'A15410545556021834',0,'016***4195','public\\avatar\\default.jpg',40,170,'Huawei Ascend Mate7 Moonlight Silver Mobile Unicom Dual 4G Mobile Phone Dual SIM Dual Standby',2,2,'10000001,10000002','2.00','10000001','account','ip','已付款,已发货,已完成','0.00','huy672','pos laju','1541054555.602','44226','2018-11-01 13:50:40','20181101047','2018-11-01 06:42:35','2018-11-02 02:21:22'),(226,'A15410548137929016',0,'016***4195','public\\avatar\\default.jpg',40,172,'Huawei Ascend Mate7 Moonlight Silver Mobile Unicom Dual 4G Mobile Phone Dual SIM Dual Standby',3,1,'10000002','1.00','0','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1541054813.793',NULL,NULL,NULL,'2018-11-01 06:46:53','2018-11-01 06:46:53'),(227,'A15410548808247616',0,'016***4195','public\\avatar\\default.jpg',40,167,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',1,3,'10000003,10000001,10000002','3.00','10000002','account','ip','已付款,已发货,已完成','5.00','y67833','pos laju','1541054880.825','55370','2018-11-01 14:00:40','20181101048','2018-11-01 06:48:00','2018-11-12 10:14:56'),(228,'A15410553543803708',0,'016***4195','public\\avatar\\default.jpg',40,172,'Huawei Ascend Mate7 Moonlight Silver Mobile Unicom Dual 4G Mobile Phone Dual SIM Dual Standby',3,1,'10000001','1.00','10000001','account','ip','已付款,已发货,已完成','0.00','ad','da','1541055354.380','55370','2018-11-01 14:00:40','20181101048','2018-11-01 06:55:54','2018-11-21 02:56:07'),(229,'A15410902758215316',0,'012***6789','public/avatar/515254438192hrbkaixk4hofr3.jpg',21,171,'Apple iPhone 6 Plus (A1524) 16GB Gold Mobile',2,1,'10000001','1.00','10000001','account','ip','已付款,已发货,已完成','0.00','sad','ad','1541090275.822','33657','2018-11-02 00:10:40','20181102002','2018-11-01 16:37:55','2018-11-21 02:56:20'),(230,'A15411238846673977',0,'016***4195','public\\avatar\\default.jpg',40,173,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',2,3,'10000003,10000001,10000002','3.00','10000001','account','ip','已付款,已发货,已完成','0.00','ad','ad','1541123884.667','60654','2018-11-02 01:35:40','20181102019','2018-11-02 01:58:04','2018-11-21 02:56:40'),(231,'A15412273646025504',0,'012***7698','public\\avatar\\default.jpg',46,166,'Apple 1 (Apple) iPhone 6 (A1586) 16GB Gold Mobile',1,1,'10000001','1.00','0','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1541227364.603',NULL,NULL,NULL,'2018-11-03 06:42:44','2018-11-03 06:42:44'),(232,'A15414224239290487',0,'012***6167','public\\avatar\\default.jpg',44,176,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',3,1,'10000002','1.00','10000002','account','ip','已付款,已发货,已完成','0.00','asd','ad','1541422423.929','38190','2018-11-06 10:00:40','20181106024','2018-11-05 12:53:43','2018-11-21 02:56:50'),(233,'A15414725830920382',0,'012***7698','public\\avatar\\default.jpg',46,176,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',3,2,'10000003,10000001','2.00','0','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1541472583.092',NULL,NULL,NULL,'2018-11-06 02:49:43','2018-11-06 02:49:43'),(234,'A15414728101171796',0,'012***7698','public\\avatar\\default.jpg',46,177,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',4,1,'10000003','1.00','10000003','account','ip','已付款,已发货,已完成','0.00','asd','asd','1541472810.117','38190','2018-11-06 10:00:40','20181106024','2018-11-06 02:53:30','2018-11-21 02:57:02'),(235,'A15414728536267411',0,'012***7698','public\\avatar\\default.jpg',46,177,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',4,2,'10000001,10000002','2.00','10000002','account','ip','已付款,已发货,已完成','0.00','ads','da','1541472853.627','38190','2018-11-06 10:00:40','20181106024','2018-11-06 02:54:13','2018-11-21 02:57:09'),(236,'A15414728808868138',1,'012***7698','public\\avatar\\default.jpg',46,174,'Huawei Ascend Mate7 Moonlight Silver Mobile Unicom Dual 4G Mobile Phone Dual SIM Dual Standby',4,1,'10000002','1.00','0','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1541472880.887',NULL,NULL,NULL,'2018-11-06 02:54:40','2018-11-06 02:54:40'),(237,'A15420133249868591',0,'012***6167','public\\avatar\\default.jpg',44,166,'Apple 1 (Apple) iPhone 6 (A1586) 16GB Gold Mobile',1,1,'10000005','1.00','10000005','account','ip','已付款,已发货,已完成','8.00','112231','sf','1542013324.987','70264','2018-11-12 16:10:40','20181112061','2018-11-12 09:02:04','2018-11-21 02:57:19'),(238,'A15420772231605277',0,'012***6789','public/avatar/515254438192hrbkaixk4hofr3.jpg',21,180,'Apple 1 (Apple) iPhone 6 (A1586) 16GB Gold Mobile',2,1,'10000005','1.00','0','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1542077223.161',NULL,NULL,NULL,'2018-11-13 02:47:03','2018-11-13 02:47:03'),(239,'A15424200382676096',0,'012***1821','public/avatar/2018_11_02-p2IdjHEjSNUaekQKkDNzrd3NchWN5q7i.png',45,180,'Apple 1 (Apple) iPhone 6 (A1586) 16GB Gold Mobile',2,4,'10000004,10000003,10000001,10000002','4.00','10000004','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1542420038.268','20198','2018-11-17 01:35:40','20181117019','2018-11-17 02:00:38','2018-11-17 02:00:39'),(240,'A15424202858004698',0,'012***6167','public\\avatar\\default.jpg',44,181,'Apple 1 (Apple) iPhone 6 (A1586) 16GB Gold Mobile',3,1,'10000002','1.00','0','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1542420285.800',NULL,NULL,NULL,'2018-11-17 02:04:45','2018-11-17 02:04:45'),(241,'A15424283927628483',0,'012***6789','public/avatar/515254438192hrbkaixk4hofr3.jpg',21,178,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',5,1,'10000001','1.00','0','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1542428392.763',NULL,NULL,NULL,'2018-11-17 04:19:52','2018-11-17 04:19:52'),(242,'A15424287834197766',0,'012***6780','public/avatar/2018_11_17-Uq4VRW67FVZetPFV36.jpg',39,175,'Apple iPhone 6 Plus (A1524) 16GB Gold Mobile',3,1,'10000001','1.00','10000001','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1542428783.420','84125','2018-11-17 11:30:40','20181117033','2018-11-17 04:26:23','2018-11-17 04:26:24'),(243,'A15424302662587696',0,'012***6780','public/avatar/2018_11_17-Uq4VRW67FVZetPFV36.jpg',39,179,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',5,2,'10000003,10000001','2.00','0','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1542430266.259',NULL,NULL,NULL,'2018-11-17 04:51:06','2018-11-17 04:51:06'),(244,'A15425908221597666',0,'016***4195','public\\avatar\\default.jpg',49,182,'Apple iPhone 6 Plus (A1524) 16GB Gold Mobile',4,1,'10000001','1.00','10000001','account','ip','已付款,已发货,待收货','0.00','asd','asd','1542590822.160','42588','2018-11-19 01:35:40','20181119019','2018-11-19 01:27:02','2018-11-21 02:59:01'),(245,'A15425996057789124',0,'012***6789','public/avatar/515254438192hrbkaixk4hofr3.jpg',21,181,'Apple 1 (Apple) iPhone 6 (A1586) 16GB Gold Mobile',3,1,'10000004','1.00','0','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1542599605.779',NULL,NULL,NULL,'2018-11-19 03:53:25','2018-11-19 03:53:25'),(246,'A15427678662667579',0,'016***4195','public\\avatar\\default.jpg',49,183,'Apple iPhone 6 Plus (A1524) 16GB Gold Mobile',5,1,'10000001','1.00','10000001','account','ip','已付款,已发货,已完成','0.00','9822312','pos laju','1542767866.267','90853','2018-11-21 01:55:40','20181121023','2018-11-21 02:37:46','2018-11-21 02:54:52'),(247,'A15430207806372344',0,'012***6789','public/avatar/515254438192hrbkaixk4hofr3.jpg',21,181,'Apple 1 (Apple) iPhone 6 (A1586) 16GB Gold Mobile',3,1,'10000001','1.00','0','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1543020780.637',NULL,NULL,NULL,'2018-11-24 00:53:00','2018-11-24 00:53:00'),(248,'A15430238961198617',0,'012***6789','public/avatar/515254438192hrbkaixk4hofr3.jpg',21,181,'Apple 1 (Apple) iPhone 6 (A1586) 16GB Gold Mobile',3,2,'10000003,10000005','2.00','10000005','account','ip','已付款,未发货,未完成','0.00',NULL,NULL,'1543023896.120','88074','2018-11-24 01:35:40','20181124019','2018-11-24 01:44:56','2018-11-24 01:44:57');

/*Table structure for table `go_model` */

DROP TABLE IF EXISTS `go_model`;

CREATE TABLE `go_model` (
  `modelid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(50) NOT NULL,
  `table` char(50) NOT NULL,
  PRIMARY KEY (`modelid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='模型表';

/*Data for the table `go_model` */

insert  into `go_model`(`modelid`,`name`,`table`) values (1,'Cloud purchase model','shoplist'),(2,'Article model','article');

/*Table structure for table `go_news` */

DROP TABLE IF EXISTS `go_news`;

CREATE TABLE `go_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章id',
  `author` char(20) DEFAULT NULL,
  `title` char(100) NOT NULL COMMENT '标题',
  `title_style` varchar(100) DEFAULT NULL,
  `thumb` varchar(200) DEFAULT NULL,
  `picarr` text,
  `keywords` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `content` mediumtext COMMENT '内容',
  `hit` int(10) unsigned DEFAULT '0',
  `order` tinyint(3) unsigned DEFAULT NULL,
  `posttime` datetime DEFAULT NULL COMMENT '添加时间',
  `url` varchar(255) DEFAULT NULL,
  `show_enable` enum('1','0') DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

/*Data for the table `go_news` */

insert  into `go_news`(`id`,`author`,`title`,`title_style`,`thumb`,`picarr`,`keywords`,`description`,`content`,`hit`,`order`,`posttime`,`url`,`show_enable`) values (1,'','了解网站','','','a:2:{i:0;s:33:\"photo/20130902/41484375056924.jpg\";i:1;s:33:\"photo/20130902/26578125056924.jpg\";}','','','',1,1,'0000-00-00 00:00:00',NULL,'0'),(3,'','服务协议','','','a:0:{}','','','',0,0,'0000-00-00 00:00:00',NULL,'0'),(4,'','购保障体系','','','a:0:{}','','','',0,0,'0000-00-00 00:00:00',NULL,'0'),(8,'','配送费用','','','a:0:{}','','','',0,0,'0000-00-00 00:00:00',NULL,'0'),(9,'','商品验货与签收','','','a:0:{}','','','',0,0,'0000-00-00 00:00:00',NULL,'0'),(10,'','长时间未收到商品','','','a:0:{}','','','',0,0,'0000-00-00 00:00:00',NULL,'0'),(13,'','联系我们','','','a:0:{}','','','',61,1,'0000-00-00 00:00:00',NULL,'0');

/*Table structure for table `go_payment_conf` */

DROP TABLE IF EXISTS `go_payment_conf`;

CREATE TABLE `go_payment_conf` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `currency_code` varchar(30) NOT NULL,
  `merchant_code` varchar(100) NOT NULL,
  `payment_id` int(10) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `go_payment_conf` */

insert  into `go_payment_conf`(`id`,`currency_code`,`merchant_code`,`payment_id`,`created_at`,`updated_at`) values (1,'MYR','xd3dml50f0loi344j49fdfssdf',2,'0000-00-00 00:00:00',NULL);

/*Table structure for table `go_review` */

DROP TABLE IF EXISTS `go_review`;

CREATE TABLE `go_review` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(10) DEFAULT NULL,
  `product_id` int(10) DEFAULT NULL,
  `user_id` int(5) DEFAULT NULL,
  `mobile_number` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `user_photo` varchar(255) DEFAULT NULL,
  `score` int(2) DEFAULT NULL,
  `feedback` text,
  `pic_arr` text,
  `image_number` int(2) DEFAULT '0',
  `agree` int(1) DEFAULT '1',
  `time` char(30) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

/*Data for the table `go_review` */

insert  into `go_review`(`id`,`sid`,`product_id`,`user_id`,`mobile_number`,`user_email`,`user_photo`,`score`,`feedback`,`pic_arr`,`image_number`,`agree`,`time`,`created_at`,`updated_at`) values (39,166,166,45,'012***1821','frank@gmail.com','public/avatar/2018_11_02-p2IdjHEjSNUaekQKkDNzrd3NchWN5q7i.png',4,'good','a:1:{i:0;s:56:\"public/eshop/upload/shaidan/2018_11_17/EQaVVjXJb4CMS.png\";}',1,1,'1542419930.070','2018-11-17 01:58:50','2018-11-21 08:19:14'),(40,169,175,39,'012***6780','xiang@gmail.com','public/avatar/2018_11_17-Uq4VRW67FVZetPFV36.jpg',4,'this system is good for me. thanks for satumall.','a:2:{i:0;s:56:\"public/eshop/upload/shaidan/2018_11_17/l4C18eSv0yntC.jpg\";i:1;s:56:\"public/eshop/upload/shaidan/2018_11_17/QuPdGbBNPRjfR.jpg\";}',2,1,'1542428835.006','2018-11-17 04:27:15','2018-11-17 04:27:15'),(41,169,171,21,'012***6789','test@gmail.com','public/avatar/515254438192hrbkaixk4hofr3.jpg',4,'love it. very good','a:1:{i:0;s:56:\"public/eshop/upload/shaidan/2018_11_17/heVPmhqzf6ADa.jpg\";}',1,1,'1542428980.199','2018-11-17 04:29:40','2018-11-17 04:29:40'),(42,169,182,49,'016***4195',NULL,'public\\avatar\\default.jpg',2,'asdasd','a:1:{i:0;s:56:\"public/eshop/upload/shaidan/2018_11_21/JubyDbxcN5Bjp.jpg\";}',1,1,'1542767791.266','2018-11-21 02:36:31','2018-11-21 02:36:31'),(50,168,168,39,'012***6780','xiang@gmail.com','public/avatar/2018_11_17-Uq4VRW67FVZetPFV36.jpg',4,'Days','a:2:{i:0;s:56:\"public/eshop/upload/shaidan/2018_11_27/TPUB4gym7rv9u.jpg\";i:1;s:56:\"public/eshop/upload/shaidan/2018_11_27/nYgPMKHmpG4aC.jpg\";}',2,1,'1543293180.105','2018-11-27 04:33:00','2018-11-27 04:33:00');

/*Table structure for table `go_shop_general` */

DROP TABLE IF EXISTS `go_shop_general`;

CREATE TABLE `go_shop_general` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '普通商品id',
  `cateid` smallint(6) unsigned DEFAULT NULL COMMENT '所属栏目ID',
  `brandid` smallint(6) unsigned DEFAULT NULL COMMENT '所属品牌ID',
  `title` varchar(100) NOT NULL COMMENT '商品标题',
  `title_style` varchar(100) DEFAULT NULL,
  `title2` varchar(100) DEFAULT NULL COMMENT '副标题',
  `keywords` varchar(100) DEFAULT NULL COMMENT '关键字',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `money` decimal(10,2) DEFAULT '0.00' COMMENT '商品价格',
  `thumb` varchar(255) NOT NULL COMMENT '商品图片',
  `picarr` text NOT NULL COMMENT '商品图片',
  `content` text NOT NULL COMMENT '商品内容详情',
  `pos` tinyint(1) unsigned NOT NULL COMMENT '是否推荐：0否，1是',
  `renqi` tinyint(1) unsigned DEFAULT '0' COMMENT '是否人气商品：0否，1是',
  `addtime` int(10) unsigned NOT NULL COMMENT '添加时间',
  `edittime` int(10) unsigned NOT NULL COMMENT '编辑时间',
  `listorder` int(10) unsigned DEFAULT '1' COMMENT '排序',
  `renqipos` tinyint(1) unsigned DEFAULT '0' COMMENT '是否热门推荐广告：0否，1是',
  `newpos` tinyint(1) unsigned DEFAULT '0' COMMENT '是否新品上架广告：0否，1是',
  `bannershop` tinyint(1) unsigned DEFAULT '0' COMMENT '是否幻灯下推荐位商品：0否，1是',
  `posthumb` varchar(255) DEFAULT NULL COMMENT '广告图片',
  `property` varchar(500) DEFAULT NULL COMMENT '商品属性',
  `inventory` varchar(255) DEFAULT NULL,
  `sales` int(11) DEFAULT NULL,
  `ddddd` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='普通商品表';

/*Data for the table `go_shop_general` */

insert  into `go_shop_general`(`id`,`cateid`,`brandid`,`title`,`title_style`,`title2`,`keywords`,`description`,`money`,`thumb`,`picarr`,`content`,`pos`,`renqi`,`addtime`,`edittime`,`listorder`,`renqipos`,`newpos`,`bannershop`,`posthumb`,`property`,`inventory`,`sales`,`ddddd`,`created_at`,`updated_at`) values (10,6,10,'ew',NULL,'ew','ew','we','50.00','public/eshop/upload/inter_shop_ge/2018_10_11/2018_10_11-FSKsMyHn1UnOreHFlPsIpl9DX5mRSq8Q.jpg','a:0:{}','<p>333</p>',0,0,1538985183,1539247897,1,0,0,0,NULL,NULL,'9',1,NULL,'2018-10-08 07:53:03','2018-10-29 07:08:24'),(11,50,32,'fada1',NULL,'batata1',NULL,'add1','100.00','public/eshop/upload/inter_shop_ge/2018_11_21/2018_11_21-g4lC7ok6a4kM7JxI12XjBWCVT52hy9FW.jpg','a:0:{}','<p>dasd1</p>',0,0,1542768193,1542778572,1,0,0,0,NULL,NULL,'991',1,NULL,'2018-11-21 02:43:13','2018-11-21 05:36:12');

/*Table structure for table `go_shopcodes_1` */

DROP TABLE IF EXISTS `go_shopcodes_1`;

CREATE TABLE `go_shopcodes_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `s_id` int(10) unsigned NOT NULL,
  `s_cid` smallint(5) unsigned NOT NULL,
  `s_len` smallint(5) DEFAULT NULL,
  `s_codes` text,
  `s_codes_tmp` text,
  `updated_at` datetime DEFAULT NULL,
  `created_At` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `s_id` (`s_id`) USING BTREE,
  KEY `s_cid` (`s_cid`) USING BTREE,
  KEY `s_len` (`s_len`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=206 DEFAULT CHARSET=utf8;

/*Data for the table `go_shopcodes_1` */

insert  into `go_shopcodes_1`(`id`,`s_id`,`s_cid`,`s_len`,`s_codes`,`s_codes_tmp`,`updated_at`,`created_At`) values (182,166,0,0,'a:0:{}','a:5:{i:0;i:10000003;i:1;i:10000004;i:2;i:10000002;i:3;i:10000001;i:4;i:10000005;}','2018-11-12 09:02:04','2018-11-01 02:49:43'),(196,180,0,0,'a:0:{}','a:5:{i:0;i:10000005;i:1;i:10000004;i:2;i:10000003;i:3;i:10000001;i:4;i:10000002;}','2018-11-17 02:00:38','2018-11-12 09:02:07'),(188,172,0,0,'a:0:{}','a:2:{i:0;i:10000002;i:1;i:10000001;}','2018-11-01 06:55:54','2018-11-01 06:42:37'),(183,167,0,0,'a:0:{}','a:3:{i:0;i:10000003;i:1;i:10000001;i:2;i:10000002;}','2018-11-01 06:48:00','2018-11-01 02:56:11'),(189,173,0,0,'a:0:{}','a:3:{i:0;i:10000003;i:1;i:10000001;i:2;i:10000002;}','2018-11-02 01:58:04','2018-11-01 06:48:05'),(184,168,0,0,'a:0:{}','a:2:{i:0;i:10000001;i:1;i:10000002;}','2018-11-01 03:28:52','2018-11-01 03:01:01'),(185,169,0,0,'a:0:{}','a:1:{i:0;i:10000001;}','2018-11-01 03:30:27','2018-11-01 03:04:31'),(186,170,0,0,'a:0:{}','a:2:{i:0;i:10000001;i:1;i:10000002;}','2018-11-01 06:42:35','2018-11-01 03:28:54'),(187,171,0,0,'a:0:{}','a:1:{i:0;i:10000001;}','2018-11-01 16:37:55','2018-11-01 03:30:31'),(192,176,0,0,'a:0:{}','a:3:{i:0;i:10000002;i:1;i:10000003;i:2;i:10000001;}','2018-11-06 02:49:43','2018-11-02 01:58:06'),(190,174,1,1,'a:1:{i:0;i:10000001;}','a:2:{i:0;i:10000002;i:1;i:10000001;}','2018-11-06 02:54:40','2018-11-01 06:55:56'),(191,175,0,0,'a:0:{}','a:1:{i:0;i:10000001;}','2018-11-17 04:26:23','2018-11-01 16:37:57'),(193,177,0,0,'a:0:{}','a:3:{i:0;i:10000003;i:1;i:10000001;i:2;i:10000002;}','2018-11-06 02:54:40','2018-11-06 02:49:45'),(194,178,1,2,'a:2:{i:0;i:10000003;i:1;i:10000002;}','a:3:{i:0;i:10000001;i:1;i:10000003;i:2;i:10000002;}','2018-11-17 04:19:52','2018-11-06 02:54:14'),(195,179,1,1,'a:1:{i:0;i:10000002;}','a:3:{i:0;i:10000003;i:1;i:10000001;i:2;i:10000002;}','2018-11-17 04:51:06','2018-11-06 02:54:42'),(197,181,0,0,'a:0:{}','a:5:{i:0;i:10000002;i:1;i:10000004;i:2;i:10000001;i:3;i:10000003;i:4;i:10000005;}','2018-11-24 01:44:56','2018-11-17 02:00:40'),(204,188,1,5,'a:5:{i:0;i:10000003;i:1;i:10000005;i:2;i:10000001;i:3;i:10000004;i:4;i:10000002;}','a:5:{i:0;i:10000003;i:1;i:10000005;i:2;i:10000001;i:3;i:10000004;i:4;i:10000002;}','2018-11-24 01:44:57','2018-11-24 01:44:57'),(198,182,0,0,'a:0:{}','a:1:{i:0;i:10000001;}','2018-11-19 01:27:02','2018-11-17 04:26:25'),(199,183,0,0,'a:0:{}','a:1:{i:0;i:10000001;}','2018-11-21 02:37:46','2018-11-19 01:27:05'),(200,184,1,1,'a:1:{i:0;i:10000001;}','a:1:{i:0;i:10000001;}','2018-11-19 02:46:47','2018-11-19 02:46:47'),(201,185,1,10,'a:10:{i:0;i:10000001;i:1;i:10000004;i:2;i:10000008;i:3;i:10000009;i:4;i:10000003;i:5;i:10000007;i:6;i:10000006;i:7;i:10000005;i:8;i:10000002;i:9;i:10000010;}','a:10:{i:0;i:10000001;i:1;i:10000004;i:2;i:10000008;i:3;i:10000009;i:4;i:10000003;i:5;i:10000007;i:6;i:10000006;i:7;i:10000005;i:8;i:10000002;i:9;i:10000010;}','2018-11-19 02:47:55','2018-11-19 02:47:55'),(202,186,1,1,'a:1:{i:0;i:10000001;}','a:1:{i:0;i:10000001;}','2018-11-21 02:37:47','2018-11-21 02:37:47'),(203,187,1,1,'a:1:{i:0;i:10000001;}','a:1:{i:0;i:10000001;}','2018-11-23 17:34:42','2018-11-23 17:34:42'),(205,189,1,50,'a:50:{i:0;i:10000035;i:1;i:10000011;i:2;i:10000007;i:3;i:10000050;i:4;i:10000026;i:5;i:10000008;i:6;i:10000002;i:7;i:10000044;i:8;i:10000005;i:9;i:10000024;i:10;i:10000014;i:11;i:10000020;i:12;i:10000030;i:13;i:10000025;i:14;i:10000019;i:15;i:10000010;i:16;i:10000006;i:17;i:10000009;i:18;i:10000012;i:19;i:10000045;i:20;i:10000004;i:21;i:10000013;i:22;i:10000038;i:23;i:10000036;i:24;i:10000041;i:25;i:10000048;i:26;i:10000001;i:27;i:10000029;i:28;i:10000040;i:29;i:10000022;i:30;i:10000018;i:31;i:10000023;i:32;i:10000017;i:33;i:10000034;i:34;i:10000049;i:35;i:10000046;i:36;i:10000037;i:37;i:10000021;i:38;i:10000015;i:39;i:10000031;i:40;i:10000028;i:41;i:10000033;i:42;i:10000032;i:43;i:10000047;i:44;i:10000003;i:45;i:10000027;i:46;i:10000042;i:47;i:10000039;i:48;i:10000043;i:49;i:10000016;}','a:50:{i:0;i:10000035;i:1;i:10000011;i:2;i:10000007;i:3;i:10000050;i:4;i:10000026;i:5;i:10000008;i:6;i:10000002;i:7;i:10000044;i:8;i:10000005;i:9;i:10000024;i:10;i:10000014;i:11;i:10000020;i:12;i:10000030;i:13;i:10000025;i:14;i:10000019;i:15;i:10000010;i:16;i:10000006;i:17;i:10000009;i:18;i:10000012;i:19;i:10000045;i:20;i:10000004;i:21;i:10000013;i:22;i:10000038;i:23;i:10000036;i:24;i:10000041;i:25;i:10000048;i:26;i:10000001;i:27;i:10000029;i:28;i:10000040;i:29;i:10000022;i:30;i:10000018;i:31;i:10000023;i:32;i:10000017;i:33;i:10000034;i:34;i:10000049;i:35;i:10000046;i:36;i:10000037;i:37;i:10000021;i:38;i:10000015;i:39;i:10000031;i:40;i:10000028;i:41;i:10000033;i:42;i:10000032;i:43;i:10000047;i:44;i:10000003;i:45;i:10000027;i:46;i:10000042;i:47;i:10000039;i:48;i:10000043;i:49;i:10000016;}','2018-11-27 16:54:32','2018-11-27 16:54:32');

/*Table structure for table `go_shoplist` */

DROP TABLE IF EXISTS `go_shoplist`;

CREATE TABLE `go_shoplist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `sid` int(10) unsigned DEFAULT NULL COMMENT '同一个商品',
  `cateid` smallint(6) unsigned DEFAULT NULL COMMENT '所属栏目ID',
  `brandid` smallint(6) unsigned DEFAULT NULL COMMENT '所属品牌ID',
  `title` varchar(300) DEFAULT NULL COMMENT '商品标题',
  `title_style` varchar(100) DEFAULT NULL,
  `title2` varchar(300) DEFAULT NULL COMMENT '副标题',
  `keywords` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `money` decimal(10,2) DEFAULT '0.00' COMMENT '金额',
  `yunjiage` decimal(4,2) unsigned DEFAULT '1.00' COMMENT '云购人次价格',
  `zongrenshu` int(10) unsigned DEFAULT '0' COMMENT '总需人数',
  `canyurenshu` int(10) unsigned DEFAULT '0' COMMENT '已参与人数',
  `shenyurenshu` int(10) unsigned DEFAULT NULL,
  `def_renshu` int(10) unsigned DEFAULT '0',
  `qishu` smallint(6) unsigned DEFAULT '0' COMMENT '期数',
  `maxqishu` smallint(5) unsigned DEFAULT '1' COMMENT ' 最大期数',
  `thumb` varchar(255) DEFAULT NULL,
  `picarr` text COMMENT '商品图片',
  `content` mediumtext COMMENT '商品内容详情',
  `codes_table` char(20) DEFAULT NULL,
  `xsjx_time` int(10) unsigned DEFAULT NULL,
  `pos` tinyint(4) unsigned DEFAULT NULL COMMENT '是否推荐',
  `renqi` tinyint(4) unsigned DEFAULT '0' COMMENT '是否人气商品0否1是',
  `time` int(10) unsigned DEFAULT NULL COMMENT '时间',
  `order` int(10) unsigned DEFAULT '1',
  `q_uid` int(10) unsigned DEFAULT NULL COMMENT '中奖人ID',
  `q_user` text COMMENT '中奖人信息',
  `q_user_code` char(20) DEFAULT NULL COMMENT '中奖码',
  `q_content` mediumtext COMMENT '揭晓内容',
  `q_counttime` char(20) DEFAULT NULL COMMENT '总时间相加',
  `q_end_time` char(20) DEFAULT NULL COMMENT '揭晓时间',
  `q_showtime` char(1) DEFAULT 'N' COMMENT 'Y/N揭晓动画',
  `renqipos` tinyint(4) unsigned DEFAULT '0',
  `newpos` tinyint(4) unsigned DEFAULT NULL,
  `bannershop` tinyint(4) unsigned DEFAULT NULL,
  `posthumb` varchar(255) DEFAULT NULL,
  `zhiding` int(11) DEFAULT NULL,
  `scene` tinyint(1) NOT NULL DEFAULT '2' COMMENT '场景模式',
  `code` char(32) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `feedback` int(2) DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `renqi` (`renqi`) USING BTREE,
  KEY `order` (`yunjiage`) USING BTREE,
  KEY `q_uid` (`q_uid`) USING BTREE,
  KEY `sid` (`sid`) USING BTREE,
  KEY `shenyurenshu` (`shenyurenshu`) USING BTREE,
  KEY `q_showtime` (`q_showtime`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=190 DEFAULT CHARSET=utf8 COMMENT='商品表';

/*Data for the table `go_shoplist` */

insert  into `go_shoplist`(`id`,`sid`,`cateid`,`brandid`,`title`,`title_style`,`title2`,`keywords`,`description`,`money`,`yunjiage`,`zongrenshu`,`canyurenshu`,`shenyurenshu`,`def_renshu`,`qishu`,`maxqishu`,`thumb`,`picarr`,`content`,`codes_table`,`xsjx_time`,`pos`,`renqi`,`time`,`order`,`q_uid`,`q_user`,`q_user_code`,`q_content`,`q_counttime`,`q_end_time`,`q_showtime`,`renqipos`,`newpos`,`bannershop`,`posthumb`,`zhiding`,`scene`,`code`,`created_at`,`updated_at`,`feedback`) values (166,166,18,14,'Apple 1 (Apple) iPhone 6 (A1586) 16GB Gold Mobile',NULL,'The size is larger, but it is slimmer; the performance is stronger','qqqqqq','Apple iPhone 6 (A1586) 16GB Gold Mobile Unicom Telecom 4G Phone\r\nThe size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary. It is a masterpiece of the iPhone\'s new generation.','5.00','1.00',5,5,0,0,1,30,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-AqspE8FsX68iHcZIDjq1hgSkPoQglzAk.png','a:2:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-z9jnMszUOGJacu8X2UeW4wXhUURn1uNO.png\";i:1;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-0olDrSJkXj4yPRcQto3ihv4IgfBkU6Uw.png\";}','<p><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1423/56/49948014/167416/49fd9611/5552c211Nacafcb2c.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1159/109/1215716544/157649/9beca81c/55801c8dN54ca77f9.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1657/348/408811025/68858/adec72ad/559cc657N92c48837.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1429/229/51249179/248853/b2df3222/5552c1c2Naad88d5d.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1405/318/55836508/196738/63474143/5552c1caN0001170d.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1444/160/52540804/499173/a218e8e7/5552c1dcNb92fa98f.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1594/73/54012279/144573/e6903610/5552c1e4N242750d4.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1417/37/48862432/269985/963f5fe3/5552c1edN7c578c09.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t997/72/878792930/139462/41ea30aa/5552c1f3N963592eb.jpg\" /></p>',NULL,0,1,0,1541040583,1,44,'a:6:{s:2:\"id\";i:44;s:6:\"avatar\";s:25:\"public\\avatar\\default.jpg\";s:4:\"name\";s:5:\"cliff\";s:5:\"email\";s:15:\"cliff@gmail.com\";s:13:\"mobile_number\";s:10:\"012***6167\";s:7:\"address\";s:21:\"test shipping address\";}','10000005',NULL,NULL,'1542013425.104','N',0,NULL,0,NULL,NULL,2,NULL,'2018-11-01 02:49:43','2018-11-21 02:02:33',NULL),(167,167,17,15,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',NULL,'2015 Huawei flagship product! Bamboo silk texture, warm touch, fresh and natural temperament!',NULL,NULL,'3.00','1.00',3,3,0,0,1,100,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-3o9nCl6Ek5AY4M8ONsc6ZVheCruzU0MH.png','a:1:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-49gPtjDC4JYqqSaOfDzeZgD4Jqz7DHE9.png\";}','<img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1360/327/592755287/381969/9855235a/559cc134N655f87c5.jpg\" />',NULL,0,0,0,1541040971,1,40,'a:6:{s:2:\"id\";i:40;s:6:\"avatar\";s:25:\"public\\avatar\\default.jpg\";s:4:\"name\";s:5:\"Ricky\";s:5:\"email\";s:15:\"abcd@sample.com\";s:13:\"mobile_number\";s:10:\"016***4195\";s:7:\"address\";s:16:\"1, Jalan Parlima\";}','10000002',NULL,NULL,'1541054980.909','N',0,NULL,0,NULL,NULL,2,NULL,'2018-11-01 02:56:11','2018-11-01 06:48:05',NULL),(168,168,17,16,'Huawei Ascend Mate7 Moonlight Silver Mobile Unicom Dual 4G Mobile Phone Dual SIM Dual Standby',NULL,'6-inch high-definition large screen, all-metal slim body, smart super eight-core, push-type fingerprint recognition!',NULL,'6-inch high-definition large screen, all-metal slim body, smart super eight-core, push-type fingerprint recognition!','2.00','1.00',2,2,0,0,1,100,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-gWRw67GN9A65pbDnpG5UKTPfAMqLDHj2.png','a:1:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-eWFFP6wKuHAMeYN9M3xcnoEJLd6QqwHF.png\";}','<p><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t835/66/1421199740/1035697/496c650d/559f5be6Nd6b1dcf5.jpg\" /></p>',NULL,0,0,0,1541041261,1,21,'a:6:{s:2:\"id\";i:21;s:6:\"avatar\";s:44:\"public/avatar/515254438192hrbkaixk4hofr3.jpg\";s:4:\"name\";s:11:\"admintester\";s:5:\"email\";s:14:\"test@gmail.com\";s:13:\"mobile_number\";s:13:\"861***8147560\";s:7:\"address\";s:13:\"admin address\";}','10000001',NULL,NULL,'1541043032.506','N',0,NULL,0,NULL,NULL,2,NULL,'2018-11-01 03:01:01','2018-11-01 03:28:53',NULL),(169,169,18,14,'Apple iPhone 6 Plus (A1524) 16GB Gold Mobile',NULL,'42/5000 Chǐcùn gèng dà, què yùjiā xiān báo; xìngnéng gèng qiáng, què xiàonéng fēifán. Kān chēng iPhone xīn yīdài zhì wéi chūzhòng de dàzuò The size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary.',NULL,'42/5000\r\nChǐcùn gèng dà, què yùjiā xiān báo; xìngnéng gèng qiáng, què xiàonéng fēifán. Kān chēng iPhone xīn yīdài zhì wéi chūzhòng de dàzuò\r\nThe size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary.','1.00','1.00',1,1,0,0,1,56,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-vsFildIRF2HbMZc2UTHiiuweCNAGi8p7.png','a:3:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-d4uqdRMjzuVd2pQe4i5RkF4pyObpbTIL.png\";i:1;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-jjf9Sn561hN8KwJ2gzSbsDjH4AOq9KWY.png\";i:2;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-YHMyBAFeF88Jcu1GDL50tf0UVkYZAzkg.png\";}','<img src=\"http://img11.360buyimg.com/cms/jfs/t1123/199/918637918/36904/c6241b20/555c6639N4b923027.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1039/269/941290939/161921/1c43f0ca/555c663aNddab735e.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1609/100/365924528/29841/43299a27/5578f3e1N42204d7d.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1447/129/130036195/146673/e068cff7/555c663aN56164cd3.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1579/338/125656056/49569/e0ad4ef5/555c663bN6e00e04f.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1231/290/958201603/40255/dfc56734/555c663bN82b32713.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1261/358/923273453/103766/fe3b2d9a/555c663cN77a97e3f.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t838/274/1151135836/24031/8ada7f11/5578f841Nb83b9d3b.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1213/237/939358538/111267/6cdb548f/555c663cN151afd17.jpg\" /><img src=\"http://img11.360buyimg.com/cms/jfs/t1603/325/163606204/157915/d18e4b52/555ea872Ncae1b4e4.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1204/69/927554119/125558/8a93c6cd/555c663dN8105b2e2.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1090/270/1011333307/207060/23601960/556584f7Nbe45922b.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1495/246/129042585/74566/4c87d23a/555c663eN0832219b.jpg\" /><img src=\"http://img14.360buyimg.com/cms/jfs/t1642/286/227447214/124384/8946f618/556584f6N9e9071bc.jpg\" />',NULL,0,0,0,1541041471,1,39,'a:6:{s:2:\"id\";i:39;s:6:\"avatar\";s:25:\"public\\avatar\\default.jpg\";s:4:\"name\";s:5:\"xiang\";s:5:\"email\";s:15:\"xiang@gmail.com\";s:13:\"mobile_number\";s:10:\"012***6789\";s:7:\"address\";s:8:\"shipping\";}','10000001',NULL,NULL,'1541043127.822','N',0,NULL,0,NULL,NULL,2,NULL,'2018-11-01 03:04:31','2018-11-01 03:30:31',NULL),(170,168,17,16,'Huawei Ascend Mate7 Moonlight Silver Mobile Unicom Dual 4G Mobile Phone Dual SIM Dual Standby',NULL,'6-inch high-definition large screen, all-metal slim body, smart super eight-core, push-type fingerprint recognition!',NULL,'6-inch high-definition large screen, all-metal slim body, smart super eight-core, push-type fingerprint recognition!','2.00','1.00',2,2,0,0,2,100,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-gWRw67GN9A65pbDnpG5UKTPfAMqLDHj2.png','a:1:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-eWFFP6wKuHAMeYN9M3xcnoEJLd6QqwHF.png\";}','<p><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t835/66/1421199740/1035697/496c650d/559f5be6Nd6b1dcf5.jpg\" /></p>',NULL,0,0,0,1541042934,1,40,'a:6:{s:2:\"id\";i:40;s:6:\"avatar\";s:25:\"public\\avatar\\default.jpg\";s:4:\"name\";s:1:\"r\";s:5:\"email\";s:15:\"abcd@sample.com\";s:13:\"mobile_number\";s:10:\"016***4195\";s:7:\"address\";s:1:\"1\";}','10000001',NULL,NULL,'1541054655.712','N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-01 03:28:54','2018-11-01 06:42:36',1),(171,169,18,14,'Apple iPhone 6 Plus (A1524) 16GB Gold Mobile',NULL,'42/5000 Chǐcùn gèng dà, què yùjiā xiān báo; xìngnéng gèng qiáng, què xiàonéng fēifán. Kān chēng iPhone xīn yīdài zhì wéi chūzhòng de dàzuò The size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary.',NULL,'42/5000\r\nChǐcùn gèng dà, què yùjiā xiān báo; xìngnéng gèng qiáng, què xiàonéng fēifán. Kān chēng iPhone xīn yīdài zhì wéi chūzhòng de dàzuò\r\nThe size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary.','1.00','1.00',1,1,0,0,2,56,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-vsFildIRF2HbMZc2UTHiiuweCNAGi8p7.png','a:3:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-d4uqdRMjzuVd2pQe4i5RkF4pyObpbTIL.png\";i:1;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-jjf9Sn561hN8KwJ2gzSbsDjH4AOq9KWY.png\";i:2;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-YHMyBAFeF88Jcu1GDL50tf0UVkYZAzkg.png\";}','<img src=\"http://img11.360buyimg.com/cms/jfs/t1123/199/918637918/36904/c6241b20/555c6639N4b923027.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1039/269/941290939/161921/1c43f0ca/555c663aNddab735e.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1609/100/365924528/29841/43299a27/5578f3e1N42204d7d.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1447/129/130036195/146673/e068cff7/555c663aN56164cd3.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1579/338/125656056/49569/e0ad4ef5/555c663bN6e00e04f.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1231/290/958201603/40255/dfc56734/555c663bN82b32713.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1261/358/923273453/103766/fe3b2d9a/555c663cN77a97e3f.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t838/274/1151135836/24031/8ada7f11/5578f841Nb83b9d3b.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1213/237/939358538/111267/6cdb548f/555c663cN151afd17.jpg\" /><img src=\"http://img11.360buyimg.com/cms/jfs/t1603/325/163606204/157915/d18e4b52/555ea872Ncae1b4e4.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1204/69/927554119/125558/8a93c6cd/555c663dN8105b2e2.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1090/270/1011333307/207060/23601960/556584f7Nbe45922b.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1495/246/129042585/74566/4c87d23a/555c663eN0832219b.jpg\" /><img src=\"http://img14.360buyimg.com/cms/jfs/t1642/286/227447214/124384/8946f618/556584f6N9e9071bc.jpg\" />',NULL,0,0,0,1541043031,1,21,'a:6:{s:2:\"id\";i:21;s:6:\"avatar\";s:44:\"public/avatar/515254438192hrbkaixk4hofr3.jpg\";s:4:\"name\";s:11:\"admintester\";s:5:\"email\";s:14:\"test@gmail.com\";s:13:\"mobile_number\";s:10:\"012***6789\";s:7:\"address\";s:13:\"admin address\";}','10000001',NULL,NULL,'1541090375.912','N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-01 03:30:31','2018-11-01 16:37:56',1),(172,168,17,16,'Huawei Ascend Mate7 Moonlight Silver Mobile Unicom Dual 4G Mobile Phone Dual SIM Dual Standby',NULL,'6-inch high-definition large screen, all-metal slim body, smart super eight-core, push-type fingerprint recognition!',NULL,'6-inch high-definition large screen, all-metal slim body, smart super eight-core, push-type fingerprint recognition!','2.00','1.00',2,2,0,0,3,100,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-gWRw67GN9A65pbDnpG5UKTPfAMqLDHj2.png','a:1:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-eWFFP6wKuHAMeYN9M3xcnoEJLd6QqwHF.png\";}','<p><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t835/66/1421199740/1035697/496c650d/559f5be6Nd6b1dcf5.jpg\" /></p>',NULL,0,0,0,1541054557,1,40,'a:6:{s:2:\"id\";i:40;s:6:\"avatar\";s:25:\"public\\avatar\\default.jpg\";s:4:\"name\";s:5:\"Ricky\";s:5:\"email\";s:15:\"abcd@sample.com\";s:13:\"mobile_number\";s:10:\"016***4195\";s:7:\"address\";s:16:\"1, Jalan Parlima\";}','10000001',NULL,NULL,'1541055454.454','N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-01 06:42:37','2018-11-01 06:55:55',1),(173,167,17,15,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',NULL,'2015 Huawei flagship product! Bamboo silk texture, warm touch, fresh and natural temperament!',NULL,NULL,'3.00','1.00',3,3,0,0,2,100,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-3o9nCl6Ek5AY4M8ONsc6ZVheCruzU0MH.png','a:1:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-49gPtjDC4JYqqSaOfDzeZgD4Jqz7DHE9.png\";}','<img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1360/327/592755287/381969/9855235a/559cc134N655f87c5.jpg\" />',NULL,0,0,0,1541054885,1,40,'a:6:{s:2:\"id\";i:40;s:6:\"avatar\";s:25:\"public\\avatar\\default.jpg\";s:4:\"name\";s:5:\"Ricky\";s:5:\"email\";s:15:\"abcd@sample.com\";s:13:\"mobile_number\";s:10:\"016***4195\";s:7:\"address\";s:16:\"1, Jalan Parlima\";}','10000001',NULL,NULL,'1541123984.742','N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-01 06:48:05','2018-11-02 01:58:05',1),(174,168,17,16,'Huawei Ascend Mate7 Moonlight Silver Mobile Unicom Dual 4G Mobile Phone Dual SIM Dual Standby',NULL,'6-inch high-definition large screen, all-metal slim body, smart super eight-core, push-type fingerprint recognition!',NULL,'6-inch high-definition large screen, all-metal slim body, smart super eight-core, push-type fingerprint recognition!','2.00','1.00',2,1,1,0,4,100,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-gWRw67GN9A65pbDnpG5UKTPfAMqLDHj2.png','a:1:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-eWFFP6wKuHAMeYN9M3xcnoEJLd6QqwHF.png\";}','<p><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t835/66/1421199740/1035697/496c650d/559f5be6Nd6b1dcf5.jpg\" /></p>',NULL,0,0,0,1541055356,1,NULL,NULL,NULL,NULL,NULL,NULL,'N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-01 06:55:56','2018-11-06 02:54:40',1),(175,169,18,14,'Apple iPhone 6 Plus (A1524) 16GB Gold Mobile',NULL,'42/5000 Chǐcùn gèng dà, què yùjiā xiān báo; xìngnéng gèng qiáng, què xiàonéng fēifán. Kān chēng iPhone xīn yīdài zhì wéi chūzhòng de dàzuò The size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary.',NULL,'42/5000\r\nChǐcùn gèng dà, què yùjiā xiān báo; xìngnéng gèng qiáng, què xiàonéng fēifán. Kān chēng iPhone xīn yīdài zhì wéi chūzhòng de dàzuò\r\nThe size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary.','1.00','1.00',1,1,0,0,3,2,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-vsFildIRF2HbMZc2UTHiiuweCNAGi8p7.png','a:3:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-d4uqdRMjzuVd2pQe4i5RkF4pyObpbTIL.png\";i:1;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-jjf9Sn561hN8KwJ2gzSbsDjH4AOq9KWY.png\";i:2;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-YHMyBAFeF88Jcu1GDL50tf0UVkYZAzkg.png\";}','<p><img src=\"http://img11.360buyimg.com/cms/jfs/t1123/199/918637918/36904/c6241b20/555c6639N4b923027.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1039/269/941290939/161921/1c43f0ca/555c663aNddab735e.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1609/100/365924528/29841/43299a27/5578f3e1N42204d7d.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1447/129/130036195/146673/e068cff7/555c663aN56164cd3.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1579/338/125656056/49569/e0ad4ef5/555c663bN6e00e04f.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1231/290/958201603/40255/dfc56734/555c663bN82b32713.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1261/358/923273453/103766/fe3b2d9a/555c663cN77a97e3f.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t838/274/1151135836/24031/8ada7f11/5578f841Nb83b9d3b.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1213/237/939358538/111267/6cdb548f/555c663cN151afd17.jpg\" /><img src=\"http://img11.360buyimg.com/cms/jfs/t1603/325/163606204/157915/d18e4b52/555ea872Ncae1b4e4.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1204/69/927554119/125558/8a93c6cd/555c663dN8105b2e2.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1090/270/1011333307/207060/23601960/556584f7Nbe45922b.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1495/246/129042585/74566/4c87d23a/555c663eN0832219b.jpg\" /><img src=\"http://img14.360buyimg.com/cms/jfs/t1642/286/227447214/124384/8946f618/556584f6N9e9071bc.jpg\" /></p>',NULL,0,0,0,1541090277,1,39,'a:6:{s:2:\"id\";i:39;s:6:\"avatar\";s:47:\"public/avatar/2018_11_17-Uq4VRW67FVZetPFV36.jpg\";s:4:\"name\";s:5:\"xiang\";s:5:\"email\";s:15:\"xiang@gmail.com\";s:13:\"mobile_number\";s:10:\"012***6780\";s:7:\"address\";s:8:\"shipping\";}','10000001',NULL,NULL,'1542428883.496','N',0,NULL,0,NULL,NULL,2,NULL,'2018-11-01 16:37:57','2018-11-19 02:55:06',NULL),(176,167,17,15,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',NULL,'2015 Huawei flagship product! Bamboo silk texture, warm touch, fresh and natural temperament!',NULL,NULL,'3.00','1.00',3,3,0,0,3,100,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-3o9nCl6Ek5AY4M8ONsc6ZVheCruzU0MH.png','a:1:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-49gPtjDC4JYqqSaOfDzeZgD4Jqz7DHE9.png\";}','<img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1360/327/592755287/381969/9855235a/559cc134N655f87c5.jpg\" />',NULL,0,0,0,1541123886,1,44,'a:6:{s:2:\"id\";i:44;s:6:\"avatar\";s:25:\"public\\avatar\\default.jpg\";s:4:\"name\";s:5:\"cliff\";s:5:\"email\";s:15:\"cliff@gmail.com\";s:13:\"mobile_number\";s:10:\"012***6167\";s:7:\"address\";s:21:\"test shipping address\";}','10000002',NULL,NULL,'1541472683.186','N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-02 01:58:06','2018-11-06 02:49:43',1),(177,167,17,15,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',NULL,'2015 Huawei flagship product! Bamboo silk texture, warm touch, fresh and natural temperament!',NULL,NULL,'3.00','1.00',3,3,0,0,4,100,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-3o9nCl6Ek5AY4M8ONsc6ZVheCruzU0MH.png','a:1:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-49gPtjDC4JYqqSaOfDzeZgD4Jqz7DHE9.png\";}','<img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1360/327/592755287/381969/9855235a/559cc134N655f87c5.jpg\" />',NULL,0,0,0,1541472585,1,46,'a:6:{s:2:\"id\";i:46;s:6:\"avatar\";s:25:\"public\\avatar\\default.jpg\";s:4:\"name\";s:4:\"alex\";s:5:\"email\";s:14:\"alex@email.com\";s:13:\"mobile_number\";s:10:\"012***7698\";s:7:\"address\";s:21:\"alex shipping address\";}','10000002',NULL,NULL,'1541472980.991','N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-06 02:49:45','2018-11-06 02:54:41',1),(178,167,17,15,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',NULL,'2015 Huawei flagship product! Bamboo silk texture, warm touch, fresh and natural temperament!',NULL,NULL,'3.00','1.00',3,1,2,0,5,100,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-3o9nCl6Ek5AY4M8ONsc6ZVheCruzU0MH.png','a:1:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-49gPtjDC4JYqqSaOfDzeZgD4Jqz7DHE9.png\";}','<img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1360/327/592755287/381969/9855235a/559cc134N655f87c5.jpg\" />',NULL,0,0,0,1541472854,1,NULL,NULL,NULL,NULL,NULL,NULL,'N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-06 02:54:14','2018-11-17 04:19:52',1),(179,167,17,15,'Huawei P8 Youth Edition White Mobile 4G Mobile Phone',NULL,'2015 Huawei flagship product! Bamboo silk texture, warm touch, fresh and natural temperament!',NULL,NULL,'3.00','1.00',3,2,1,0,5,100,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-3o9nCl6Ek5AY4M8ONsc6ZVheCruzU0MH.png','a:1:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-49gPtjDC4JYqqSaOfDzeZgD4Jqz7DHE9.png\";}','<img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1360/327/592755287/381969/9855235a/559cc134N655f87c5.jpg\" />',NULL,0,0,0,1541472882,1,NULL,NULL,NULL,NULL,NULL,NULL,'N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-06 02:54:42','2018-11-17 04:51:06',1),(180,166,18,14,'Apple 1 (Apple) iPhone 6 (A1586) 16GB Gold Mobile',NULL,'The size is larger, but it is slimmer; the performance is stronger',NULL,'Apple iPhone 6 (A1586) 16GB Gold Mobile Unicom Telecom 4G Phone\r\nThe size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary. It is a masterpiece of the iPhone\'s new generation.','5.00','1.00',5,5,0,0,2,30,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-AqspE8FsX68iHcZIDjq1hgSkPoQglzAk.png','a:2:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-z9jnMszUOGJacu8X2UeW4wXhUURn1uNO.png\";i:1;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-0olDrSJkXj4yPRcQto3ihv4IgfBkU6Uw.png\";}','<img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1423/56/49948014/167416/49fd9611/5552c211Nacafcb2c.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1159/109/1215716544/157649/9beca81c/55801c8dN54ca77f9.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1657/348/408811025/68858/adec72ad/559cc657N92c48837.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1429/229/51249179/248853/b2df3222/5552c1c2Naad88d5d.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1405/318/55836508/196738/63474143/5552c1caN0001170d.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1444/160/52540804/499173/a218e8e7/5552c1dcNb92fa98f.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1594/73/54012279/144573/e6903610/5552c1e4N242750d4.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1417/37/48862432/269985/963f5fe3/5552c1edN7c578c09.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t997/72/878792930/139462/41ea30aa/5552c1f3N963592eb.jpg\" />',NULL,0,0,0,1542013327,1,45,'a:6:{s:2:\"id\";i:45;s:6:\"avatar\";s:61:\"public/avatar/2018_11_02-p2IdjHEjSNUaekQKkDNzrd3NchWN5q7i.png\";s:4:\"name\";s:5:\"frank\";s:5:\"email\";s:15:\"frank@gmail.com\";s:13:\"mobile_number\";s:10:\"012***1821\";s:7:\"address\";s:22:\"frank shipping address\";}','10000004',NULL,NULL,'1542420138.418','N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-12 09:02:07','2018-11-17 02:00:39',1),(181,166,18,14,'Apple 1 (Apple) iPhone 6 (A1586) 16GB Gold Mobile',NULL,'The size is larger, but it is slimmer; the performance is stronger',NULL,'Apple iPhone 6 (A1586) 16GB Gold Mobile Unicom Telecom 4G Phone\r\nThe size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary. It is a masterpiece of the iPhone\'s new generation.','5.00','1.00',5,5,0,0,3,30,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-AqspE8FsX68iHcZIDjq1hgSkPoQglzAk.png','a:2:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-z9jnMszUOGJacu8X2UeW4wXhUURn1uNO.png\";i:1;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-0olDrSJkXj4yPRcQto3ihv4IgfBkU6Uw.png\";}','<img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1423/56/49948014/167416/49fd9611/5552c211Nacafcb2c.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1159/109/1215716544/157649/9beca81c/55801c8dN54ca77f9.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1657/348/408811025/68858/adec72ad/559cc657N92c48837.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1429/229/51249179/248853/b2df3222/5552c1c2Naad88d5d.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1405/318/55836508/196738/63474143/5552c1caN0001170d.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1444/160/52540804/499173/a218e8e7/5552c1dcNb92fa98f.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1594/73/54012279/144573/e6903610/5552c1e4N242750d4.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1417/37/48862432/269985/963f5fe3/5552c1edN7c578c09.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t997/72/878792930/139462/41ea30aa/5552c1f3N963592eb.jpg\" />',NULL,0,0,0,1542420040,1,21,'a:6:{s:2:\"id\";i:21;s:6:\"avatar\";s:44:\"public/avatar/515254438192hrbkaixk4hofr3.jpg\";s:4:\"name\";s:11:\"admintester\";s:5:\"email\";s:14:\"test@gmail.com\";s:13:\"mobile_number\";s:10:\"012***6789\";s:7:\"address\";s:13:\"admin address\";}','10000005',NULL,NULL,'1543023996.268','N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-17 02:00:40','2018-12-11 05:49:32',0),(182,169,18,14,'Apple iPhone 6 Plus (A1524) 16GB Gold Mobile',NULL,'42/5000 Chǐcùn gèng dà, què yùjiā xiān báo; xìngnéng gèng qiáng, què xiàonéng fēifán. Kān chēng iPhone xīn yīdài zhì wéi chūzhòng de dàzuò The size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary.',NULL,'42/5000\r\nChǐcùn gèng dà, què yùjiā xiān báo; xìngnéng gèng qiáng, què xiàonéng fēifán. Kān chēng iPhone xīn yīdài zhì wéi chūzhòng de dàzuò\r\nThe size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary.','1.00','1.00',1,1,0,0,4,56,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-vsFildIRF2HbMZc2UTHiiuweCNAGi8p7.png','a:3:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-d4uqdRMjzuVd2pQe4i5RkF4pyObpbTIL.png\";i:1;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-jjf9Sn561hN8KwJ2gzSbsDjH4AOq9KWY.png\";i:2;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-YHMyBAFeF88Jcu1GDL50tf0UVkYZAzkg.png\";}','<img src=\"http://img11.360buyimg.com/cms/jfs/t1123/199/918637918/36904/c6241b20/555c6639N4b923027.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1039/269/941290939/161921/1c43f0ca/555c663aNddab735e.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1609/100/365924528/29841/43299a27/5578f3e1N42204d7d.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1447/129/130036195/146673/e068cff7/555c663aN56164cd3.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1579/338/125656056/49569/e0ad4ef5/555c663bN6e00e04f.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1231/290/958201603/40255/dfc56734/555c663bN82b32713.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1261/358/923273453/103766/fe3b2d9a/555c663cN77a97e3f.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t838/274/1151135836/24031/8ada7f11/5578f841Nb83b9d3b.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1213/237/939358538/111267/6cdb548f/555c663cN151afd17.jpg\" /><img src=\"http://img11.360buyimg.com/cms/jfs/t1603/325/163606204/157915/d18e4b52/555ea872Ncae1b4e4.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1204/69/927554119/125558/8a93c6cd/555c663dN8105b2e2.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1090/270/1011333307/207060/23601960/556584f7Nbe45922b.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1495/246/129042585/74566/4c87d23a/555c663eN0832219b.jpg\" /><img src=\"http://img14.360buyimg.com/cms/jfs/t1642/286/227447214/124384/8946f618/556584f6N9e9071bc.jpg\" />',NULL,0,0,0,1542428785,1,49,'a:6:{s:2:\"id\";i:49;s:6:\"avatar\";s:25:\"public\\avatar\\default.jpg\";s:4:\"name\";s:2:\"wk\";s:5:\"email\";N;s:13:\"mobile_number\";s:10:\"016***4195\";s:7:\"address\";s:1:\"e\";}','10000001',NULL,NULL,'1542590922.262','N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-17 04:26:25','2018-11-19 01:27:04',1),(183,169,18,14,'Apple iPhone 6 Plus (A1524) 16GB Gold Mobile',NULL,'42/5000 Chǐcùn gèng dà, què yùjiā xiān báo; xìngnéng gèng qiáng, què xiàonéng fēifán. Kān chēng iPhone xīn yīdài zhì wéi chūzhòng de dàzuò The size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary.',NULL,'42/5000\r\nChǐcùn gèng dà, què yùjiā xiān báo; xìngnéng gèng qiáng, què xiàonéng fēifán. Kān chēng iPhone xīn yīdài zhì wéi chūzhòng de dàzuò\r\nThe size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary.','1.00','1.00',1,1,0,0,5,56,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-vsFildIRF2HbMZc2UTHiiuweCNAGi8p7.png','a:3:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-d4uqdRMjzuVd2pQe4i5RkF4pyObpbTIL.png\";i:1;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-jjf9Sn561hN8KwJ2gzSbsDjH4AOq9KWY.png\";i:2;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-YHMyBAFeF88Jcu1GDL50tf0UVkYZAzkg.png\";}','<img src=\"http://img11.360buyimg.com/cms/jfs/t1123/199/918637918/36904/c6241b20/555c6639N4b923027.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1039/269/941290939/161921/1c43f0ca/555c663aNddab735e.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1609/100/365924528/29841/43299a27/5578f3e1N42204d7d.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1447/129/130036195/146673/e068cff7/555c663aN56164cd3.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1579/338/125656056/49569/e0ad4ef5/555c663bN6e00e04f.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1231/290/958201603/40255/dfc56734/555c663bN82b32713.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1261/358/923273453/103766/fe3b2d9a/555c663cN77a97e3f.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t838/274/1151135836/24031/8ada7f11/5578f841Nb83b9d3b.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1213/237/939358538/111267/6cdb548f/555c663cN151afd17.jpg\" /><img src=\"http://img11.360buyimg.com/cms/jfs/t1603/325/163606204/157915/d18e4b52/555ea872Ncae1b4e4.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1204/69/927554119/125558/8a93c6cd/555c663dN8105b2e2.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1090/270/1011333307/207060/23601960/556584f7Nbe45922b.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1495/246/129042585/74566/4c87d23a/555c663eN0832219b.jpg\" /><img src=\"http://img14.360buyimg.com/cms/jfs/t1642/286/227447214/124384/8946f618/556584f6N9e9071bc.jpg\" />',NULL,0,0,0,1542590825,1,49,'a:6:{s:2:\"id\";i:49;s:6:\"avatar\";s:25:\"public\\avatar\\default.jpg\";s:4:\"name\";s:2:\"wk\";s:5:\"email\";N;s:13:\"mobile_number\";s:10:\"016***4195\";s:7:\"address\";s:1:\"e\";}','10000001',NULL,NULL,'1542767966.327','N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-19 01:27:05','2018-11-21 02:37:47',1),(186,169,18,14,'Apple iPhone 6 Plus (A1524) 16GB Gold Mobile',NULL,'42/5000 Chǐcùn gèng dà, què yùjiā xiān báo; xìngnéng gèng qiáng, què xiàonéng fēifán. Kān chēng iPhone xīn yīdài zhì wéi chūzhòng de dàzuò The size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary.',NULL,'42/5000\r\nChǐcùn gèng dà, què yùjiā xiān báo; xìngnéng gèng qiáng, què xiàonéng fēifán. Kān chēng iPhone xīn yīdài zhì wéi chūzhòng de dàzuò\r\nThe size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary.','1.00','1.00',1,0,1,0,6,56,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-vsFildIRF2HbMZc2UTHiiuweCNAGi8p7.png','a:3:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-d4uqdRMjzuVd2pQe4i5RkF4pyObpbTIL.png\";i:1;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-jjf9Sn561hN8KwJ2gzSbsDjH4AOq9KWY.png\";i:2;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-YHMyBAFeF88Jcu1GDL50tf0UVkYZAzkg.png\";}','<img src=\"http://img11.360buyimg.com/cms/jfs/t1123/199/918637918/36904/c6241b20/555c6639N4b923027.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1039/269/941290939/161921/1c43f0ca/555c663aNddab735e.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1609/100/365924528/29841/43299a27/5578f3e1N42204d7d.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1447/129/130036195/146673/e068cff7/555c663aN56164cd3.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1579/338/125656056/49569/e0ad4ef5/555c663bN6e00e04f.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1231/290/958201603/40255/dfc56734/555c663bN82b32713.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1261/358/923273453/103766/fe3b2d9a/555c663cN77a97e3f.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t838/274/1151135836/24031/8ada7f11/5578f841Nb83b9d3b.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1213/237/939358538/111267/6cdb548f/555c663cN151afd17.jpg\" /><img src=\"http://img11.360buyimg.com/cms/jfs/t1603/325/163606204/157915/d18e4b52/555ea872Ncae1b4e4.jpg\" /><img src=\"http://img13.360buyimg.com/cms/jfs/t1204/69/927554119/125558/8a93c6cd/555c663dN8105b2e2.jpg\" /><img src=\"http://img12.360buyimg.com/cms/jfs/t1090/270/1011333307/207060/23601960/556584f7Nbe45922b.jpg\" /><img src=\"http://img10.360buyimg.com/cms/jfs/t1495/246/129042585/74566/4c87d23a/555c663eN0832219b.jpg\" /><img src=\"http://img14.360buyimg.com/cms/jfs/t1642/286/227447214/124384/8946f618/556584f6N9e9071bc.jpg\" />',NULL,0,0,0,1542767867,1,NULL,NULL,NULL,NULL,NULL,NULL,'N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-21 02:37:47','2018-11-21 02:37:47',1),(187,187,17,16,'this is test mobile',NULL,'sub title-2',NULL,NULL,'1.00','1.00',1,0,1,0,1,100,'public/eshop/upload/inter_shop/2018_11_23/XZuV5u7JiOHgbTegBuJvzuI7EKUvo0zQ.jpg','a:0:{}','',NULL,0,0,0,1542994482,1,NULL,NULL,NULL,NULL,NULL,NULL,'N',0,NULL,0,NULL,NULL,2,NULL,'2018-11-23 17:34:42','2018-11-23 17:35:18',NULL),(188,166,18,14,'Apple 1 (Apple) iPhone 6 (A1586) 16GB Gold Mobile',NULL,'The size is larger, but it is slimmer; the performance is stronger',NULL,'Apple iPhone 6 (A1586) 16GB Gold Mobile Unicom Telecom 4G Phone\r\nThe size is larger, but it is slimmer; the performance is stronger, but the performance is extraordinary. It is a masterpiece of the iPhone\'s new generation.','5.00','1.00',5,0,5,0,4,30,'public/eshop/upload/inter_shop/2018_11_01/2018_11_01-AqspE8FsX68iHcZIDjq1hgSkPoQglzAk.png','a:2:{i:0;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-z9jnMszUOGJacu8X2UeW4wXhUURn1uNO.png\";i:1;s:89:\"public/eshop/upload/inter_shop/2018_11_01/2018_11_01-0olDrSJkXj4yPRcQto3ihv4IgfBkU6Uw.png\";}','<img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1423/56/49948014/167416/49fd9611/5552c211Nacafcb2c.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1159/109/1215716544/157649/9beca81c/55801c8dN54ca77f9.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1657/348/408811025/68858/adec72ad/559cc657N92c48837.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1429/229/51249179/248853/b2df3222/5552c1c2Naad88d5d.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1405/318/55836508/196738/63474143/5552c1caN0001170d.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1444/160/52540804/499173/a218e8e7/5552c1dcNb92fa98f.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1594/73/54012279/144573/e6903610/5552c1e4N242750d4.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t1417/37/48862432/269985/963f5fe3/5552c1edN7c578c09.jpg\" /><img src=\"http://img30.360buyimg.com/jgsq-productsoa/jfs/t997/72/878792930/139462/41ea30aa/5552c1f3N963592eb.jpg\" />',NULL,0,0,0,1543023897,1,NULL,NULL,NULL,NULL,NULL,NULL,'N',0,NULL,NULL,NULL,NULL,2,NULL,'2018-11-24 01:44:57','2018-11-24 01:44:57',1),(189,189,17,16,'5 yuan test product',NULL,NULL,NULL,'sdf','250.00','5.00',50,0,50,0,1,100,'public/eshop/upload/inter_shop/2018_11_27/J7ZBCMMbR1iO0qLGdBCmKZOfpX2FiMKy.jpg','a:0:{}','<p>666</p>',NULL,0,0,0,1543337672,1,NULL,NULL,NULL,NULL,NULL,NULL,'N',0,NULL,0,NULL,NULL,2,NULL,'2018-11-27 16:54:32','2018-11-27 16:54:32',NULL);

/*Table structure for table `go_slide` */

DROP TABLE IF EXISTS `go_slide`;

CREATE TABLE `go_slide` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `img` varchar(100) DEFAULT NULL COMMENT '幻灯片',
  `title` varchar(100) DEFAULT NULL,
  `order` int(2) DEFAULT NULL,
  `visible` int(1) DEFAULT '1',
  `filename` varchar(50) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `img` (`img`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='幻灯片表';

/*Data for the table `go_slide` */

insert  into `go_slide`(`id`,`img`,`title`,`order`,`visible`,`filename`,`updated_at`,`created_at`) values (1,'public/eshop/img/banner01.jpg','1',1,0,'banner01.jpg','2018-12-05 10:23:12',NULL),(4,'public/eshop/img/banner03.jpg',NULL,3,1,'banner03.jpg','2018-12-04 06:23:57',NULL),(5,'public/eshop/img/banner04.jpg',NULL,4,1,'banner04.jpg','2018-12-04 06:24:11',NULL),(6,'public/eshop/img/banner05.jpg','sss',6,1,'banner05.jpg','2018-12-04 06:24:15',NULL);

/*Table structure for table `go_test` */

DROP TABLE IF EXISTS `go_test`;

CREATE TABLE `go_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

/*Data for the table `go_test` */

insert  into `go_test`(`id`,`content`,`created_at`,`updated_at`) values (35,'a:3:{s:6:\"status\";s:1:\"0\";s:7:\"message\";s:27:\"Customer Cancel Transaction\";s:4:\"data\";a:26:{s:12:\"MerchantCode\";s:6:\"M17669\";s:9:\"PaymentId\";s:1:\"2\";s:5:\"RefNo\";s:18:\"C15410420188245211\";s:6:\"Amount\";s:4:\"1.00\";s:8:\"Discount\";s:0:\"\";s:8:\"Currency\";s:3:\"MYR\";s:6:\"Remark\";s:19:\"Some remarks here..\";s:7:\"TransId\";s:13:\"T159027453400\";s:8:\"AuthCode\";s:0:\"\";s:6:\"Status\";s:1:\"0\";s:7:\"ErrDesc\";s:27:\"Customer Cancel Transaction\";s:10:\"PayerEmail\";s:0:\"\";s:10:\"ExpiryDate\";s:0:\"\";s:9:\"Signature\";s:64:\"7173f21a1254f31241870d58512d5fbbb5eaf645e9dfd2ac6b11ea197ae836d1\";s:6:\"CCName\";s:0:\"\";s:4:\"CCNo\";s:0:\"\";s:10:\"S_bankname\";s:0:\"\";s:9:\"S_country\";s:0:\"\";s:7:\"TokenId\";s:0:\"\";s:15:\"BindCardErrDesc\";s:0:\"\";s:10:\"PANTrackNo\";s:0:\"\";s:10:\"ActionType\";s:0:\"\";s:7:\"BankMID\";s:0:\"\";s:10:\"PayChannel\";s:10:\"DirectLink\";s:10:\"OldTokenId\";s:0:\"\";s:8:\"TranDate\";s:10:\"2018-11-01\";}}','2018-11-01 03:13:49','2018-11-01 03:13:49'),(36,'a:3:{s:6:\"status\";s:1:\"0\";s:7:\"message\";s:20:\"Permission not allow\";s:4:\"data\";a:19:{s:12:\"MerchantCode\";s:6:\"M17669\";s:9:\"PaymentId\";s:1:\"2\";s:5:\"RefNo\";s:18:\"C15425979403693709\";s:6:\"Amount\";s:4:\"1.00\";s:8:\"Currency\";s:3:\"MYR\";s:6:\"Remark\";s:19:\"Some remarks here..\";s:7:\"TransId\";s:13:\"T161589802600\";s:8:\"AuthCode\";s:0:\"\";s:6:\"Status\";s:1:\"0\";s:7:\"ErrDesc\";s:20:\"Permission not allow\";s:9:\"Signature\";s:0:\"\";s:11:\"HiddenToURL\";s:55:\"http://haipsy3.selfip.com/satumall/ipaypayment/response\";s:10:\"ActionType\";s:0:\"\";s:7:\"TokenId\";s:0:\"\";s:13:\"CCCOriTokenId\";s:0:\"\";s:9:\"PromoCode\";s:0:\"\";s:16:\"DiscountedAmount\";s:0:\"\";s:9:\"MTVersion\";s:0:\"\";s:7:\"MTLogId\";s:1:\"0\";}}','2018-11-19 03:25:40','2018-11-19 03:25:40'),(37,'a:3:{s:6:\"status\";s:1:\"0\";s:7:\"message\";s:20:\"Permission not allow\";s:4:\"data\";a:19:{s:12:\"MerchantCode\";s:6:\"M17669\";s:9:\"PaymentId\";s:1:\"2\";s:5:\"RefNo\";s:18:\"C15425979849167204\";s:6:\"Amount\";s:4:\"1.00\";s:8:\"Currency\";s:3:\"MYR\";s:6:\"Remark\";s:19:\"Some remarks here..\";s:7:\"TransId\";s:13:\"T161589896200\";s:8:\"AuthCode\";s:0:\"\";s:6:\"Status\";s:1:\"0\";s:7:\"ErrDesc\";s:20:\"Permission not allow\";s:9:\"Signature\";s:0:\"\";s:11:\"HiddenToURL\";s:55:\"http://haipsy3.selfip.com/satumall/ipaypayment/response\";s:10:\"ActionType\";s:0:\"\";s:7:\"TokenId\";s:0:\"\";s:13:\"CCCOriTokenId\";s:0:\"\";s:9:\"PromoCode\";s:0:\"\";s:16:\"DiscountedAmount\";s:0:\"\";s:9:\"MTVersion\";s:0:\"\";s:7:\"MTLogId\";s:1:\"0\";}}','2018-11-19 03:26:25','2018-11-19 03:26:25'),(38,'a:3:{s:6:\"status\";s:1:\"0\";s:7:\"message\";s:20:\"Permission not allow\";s:4:\"data\";a:19:{s:12:\"MerchantCode\";s:6:\"M17669\";s:9:\"PaymentId\";s:1:\"2\";s:5:\"RefNo\";s:18:\"C15425988040046385\";s:6:\"Amount\";s:4:\"1.00\";s:8:\"Currency\";s:3:\"MYR\";s:6:\"Remark\";s:19:\"Some remarks here..\";s:7:\"TransId\";s:13:\"T161591641300\";s:8:\"AuthCode\";s:0:\"\";s:6:\"Status\";s:1:\"0\";s:7:\"ErrDesc\";s:20:\"Permission not allow\";s:9:\"Signature\";s:0:\"\";s:11:\"HiddenToURL\";s:55:\"http://haipsy3.selfip.com/satumall/ipaypayment/response\";s:10:\"ActionType\";s:0:\"\";s:7:\"TokenId\";s:0:\"\";s:13:\"CCCOriTokenId\";s:0:\"\";s:9:\"PromoCode\";s:0:\"\";s:16:\"DiscountedAmount\";s:0:\"\";s:9:\"MTVersion\";s:0:\"\";s:7:\"MTLogId\";s:1:\"0\";}}','2018-11-19 03:40:04','2018-11-19 03:40:04'),(39,'a:3:{s:6:\"status\";s:1:\"0\";s:7:\"message\";s:27:\"Customer Cancel Transaction\";s:4:\"data\";a:26:{s:12:\"MerchantCode\";s:6:\"M17669\";s:9:\"PaymentId\";s:1:\"2\";s:5:\"RefNo\";s:18:\"C15428963664617005\";s:6:\"Amount\";s:4:\"1.00\";s:8:\"Discount\";s:0:\"\";s:8:\"Currency\";s:3:\"MYR\";s:6:\"Remark\";s:19:\"Some remarks here..\";s:7:\"TransId\";s:13:\"T162060996100\";s:8:\"AuthCode\";s:0:\"\";s:6:\"Status\";s:1:\"0\";s:7:\"ErrDesc\";s:27:\"Customer Cancel Transaction\";s:10:\"PayerEmail\";s:0:\"\";s:10:\"ExpiryDate\";s:0:\"\";s:9:\"Signature\";s:64:\"fdad8875d5e38865dd2dc7c62f7acf25bacd942ccb0459b9f3c27a490d5e0db9\";s:6:\"CCName\";s:0:\"\";s:4:\"CCNo\";s:0:\"\";s:10:\"S_bankname\";s:0:\"\";s:9:\"S_country\";s:0:\"\";s:7:\"TokenId\";s:0:\"\";s:15:\"BindCardErrDesc\";s:0:\"\";s:10:\"PANTrackNo\";s:0:\"\";s:10:\"ActionType\";s:0:\"\";s:7:\"BankMID\";s:0:\"\";s:10:\"PayChannel\";s:10:\"DirectLink\";s:10:\"OldTokenId\";s:0:\"\";s:8:\"TranDate\";s:10:\"2018-11-22\";}}','2018-11-22 14:24:27','2018-11-22 14:24:27');

/*Table structure for table `go_upload_setting` */

DROP TABLE IF EXISTS `go_upload_setting`;

CREATE TABLE `go_upload_setting` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file_size` varchar(100) DEFAULT NULL,
  `file_types` varchar(100) DEFAULT NULL,
  `image_type` varchar(100) DEFAULT NULL,
  `media_type` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `go_upload_setting` */

insert  into `go_upload_setting`(`id`,`file_size`,`file_types`,`image_type`,`media_type`,`created_at`,`updated_at`) values (1,'102400000','zip,gz,rar,iso,doc,ppt,wps,xls','png,jpg,gif,jpeg','swf,flv,mp3,wav,wma,rmvb','2018-08-30 22:21:43','2018-11-17 02:22:57');

/*Table structure for table `go_wechat` */

DROP TABLE IF EXISTS `go_wechat`;

CREATE TABLE `go_wechat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `avatar` varchar(100) DEFAULT NULL,
  `nick` varchar(50) DEFAULT NULL,
  `ghid` varchar(50) DEFAULT NULL,
  `appid` varchar(100) DEFAULT NULL,
  `appsecret` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `go_wechat` */

insert  into `go_wechat`(`id`,`user`,`username`,`avatar`,`nick`,`ghid`,`appid`,`appsecret`,`created_at`,`updated_at`) values (3,'lucky winner','lucky winner','public/eshop/img/2018_11_12-dJ6NoEvrSKCxmqCMfWHrokSGDW9EuWb0.jpg',NULL,NULL,'wx9541gebc456bnds3099x','fadd3loepckd5ldqaand09sdf3434kdf939303ddsf','0000-00-00 00:00:00','2018-11-12 14:05:52');

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `migrations` */

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `mobile_number` varchar(50) DEFAULT NULL,
  `countries_id` char(25) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `network_type_id` int(10) DEFAULT NULL,
  `password` char(60) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `avatar` varchar(255) DEFAULT 'public\\avatar\\default.jpg',
  `status` enum('pending','active','suspended','delete') DEFAULT 'pending',
  `role` enum('normal','admin') DEFAULT 'normal',
  `remember_token` varchar(100) DEFAULT NULL,
  `token` varchar(80) DEFAULT NULL,
  `confirmation_code` varchar(125) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `paypal_account` varchar(200) DEFAULT NULL,
  `payment_gateway` varchar(50) DEFAULT NULL,
  `bank` text,
  `registration_ip_address` varchar(16) DEFAULT NULL,
  `last_login_ip_address` varchar(16) DEFAULT NULL,
  `openid` varchar(50) DEFAULT NULL,
  `mobile` char(11) DEFAULT NULL,
  `user_ip` varchar(255) DEFAULT NULL,
  `qianming` text,
  `groupid` tinyint(4) DEFAULT NULL,
  `addgroup` varchar(255) DEFAULT NULL,
  `money` decimal(10,2) DEFAULT '0.00',
  `emailcode` char(21) DEFAULT '-1',
  `mobilecode` char(21) DEFAULT '-1',
  `passcode` char(21) DEFAULT '-1',
  `session_id` varchar(100) DEFAULT NULL,
  `api_token` varchar(100) DEFAULT NULL,
  `score` int(10) DEFAULT '0',
  `jingyan` int(10) DEFAULT '0',
  `yaoqing` int(10) DEFAULT NULL,
  `band` varchar(10) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `login_time` int(10) DEFAULT '0',
  `sign_in_time` int(10) DEFAULT '0',
  `sign_in_date` char(100) DEFAULT '',
  `sign_in_time_all` mediumint(8) DEFAULT '0',
  `auto_user` tinyint(4) DEFAULT NULL,
  `fx_img` varchar(255) DEFAULT NULL,
  `address` text,
  `zip_code` varchar(200) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `username` (`status`),
  KEY `role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

/*Data for the table `users` */

insert  into `users`(`id`,`name`,`last_name`,`company_name`,`mobile_number`,`countries_id`,`state`,`network_type_id`,`password`,`email`,`date`,`avatar`,`status`,`role`,`remember_token`,`token`,`confirmation_code`,`updated_at`,`created_at`,`paypal_account`,`payment_gateway`,`bank`,`registration_ip_address`,`last_login_ip_address`,`openid`,`mobile`,`user_ip`,`qianming`,`groupid`,`addgroup`,`money`,`emailcode`,`mobilecode`,`passcode`,`session_id`,`api_token`,`score`,`jingyan`,`yaoqing`,`band`,`time`,`login_time`,`sign_in_time`,`sign_in_date`,`sign_in_time_all`,`auto_user`,`fx_img`,`address`,`zip_code`,`city`) values (21,'admintester','manager',NULL,'0123456789',NULL,NULL,NULL,'$2y$10$fxvLw.RLnNgyN0z02hBpFen9mwbJUg9SnJjlxAaJdMVVCWELf42Bm','test@gmail.com','2018-07-31 02:33:30','public/avatar/515254438192hrbkaixk4hofr3.jpg','active','admin','dpP64PScJmhxalEHw0Y6eMZTlvZb4ClgzG76IsnCAbObDvNf1UZOxo4IGy7V',NULL,NULL,'2018-12-12 00:42:54','2018-07-30 18:33:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,NULL,'7987.00','1','1','-1','Zu3U2z6Jd3g0BGsuxaNpfGHk0oBsFSeFQYjjc1w3','b876002c82821dd2af7fc55991081d4f',42370,660,NULL,NULL,NULL,1543340278,1538441222,'',0,NULL,NULL,'admin address','1100104','city'),(39,'xiang','jin',NULL,'0123456780',NULL,NULL,NULL,'$2y$10$HRwwhqrA.2fJk8eV88keOufynEGK6ITb5/Um8sQmq93U7sbiz5W0a','xiang@gmail.com','2018-11-01 10:14:59','public/avatar/2018_11_17-Uq4VRW67FVZetPFV36.jpg','active','admin','Iw1qW70ngAAgzQh85qpcW0o476NZ7I38aY9YU8CunN9FsvgNPdUNwvyay5Jq','ygIXozdrVKGB0stk6vPkQu6Y7uW3GSri12s3hETi',NULL,'2018-11-27 20:34:25','2018-11-01 02:14:59',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,NULL,'0.00','-1','1','-1','jr98AViwy0mJjDgX9ChIBB0N1gAau06wki6KDakN','41b934a88cac20353b1018e4f27395ca',100,80,NULL,NULL,1541038498,1543350865,1541038498,'',0,NULL,NULL,'shipping','postal','city'),(40,'Ricky','Yoo',NULL,'01653441956',NULL,NULL,NULL,'$2y$10$S1fG7UUxByhFVxg3Y3/hP.iowf719escTY10fhjYd6tNKv.m/WNhK','abcd@sample.com','2018-11-01 11:48:21','public\\avatar\\default.jpg','active','normal','jojNk5dp2pmAtL1Q520DZExQExNDxalsY5CxdFOYhXjIBYN0UfpfP30Kspfx','vWyYBO21KuBmdHKAWwTDMeNU975b0AX36fsc3clV',NULL,'2018-11-02 03:29:55','2018-11-01 03:48:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'42.190.209.246',NULL,NULL,NULL,'990.00','-1','1','-1',NULL,NULL,200,100,NULL,NULL,1541044101,1541129395,1541044101,'',0,NULL,NULL,'1, Jalan Parlima','50080','K.L'),(43,'4','4',NULL,'0123456788',NULL,NULL,NULL,'$2y$10$irQDuuUC5YPgsvFxbJLFbeW1SohF0l5Kj40qiUhyXLlowo.E2WmDy',NULL,'2018-11-02 09:51:09','public\\avatar\\default.jpg','pending','normal','DOy1jetldRjSCupZ5lgFJsHm4027hhnDuUrW84CKfmW0Cl3zToiMK0XeXSxr','7CGPOI06sZMoTWLALHCeh56qJsdmLoWbbMB6bxKv',NULL,'2018-11-02 01:51:09','2018-11-02 01:51:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'42.190.209.246',NULL,NULL,NULL,'0.00','-1','-1','-1',NULL,NULL,0,0,NULL,NULL,1541123468,1541123468,1541123468,'',0,NULL,NULL,'d','33333','d'),(44,'cliff','cliff',NULL,'0122126167',NULL,NULL,NULL,'$2y$10$xRcm0olFiSAGWGtKR9OtUeMmjzyTocGemKdCC9.VTyqugyfAsd8mC','cliff@gmail.com','2018-11-02 10:00:01','public\\avatar\\default.jpg','active','admin','EufEryiP01DOkVWfzXr9XijiyOIAs3MMeTafahfG1ex4dsDq43UVQfh3mVqQ',NULL,NULL,'2018-11-23 09:09:41','2018-11-02 02:00:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'180.171.163.183',NULL,NULL,NULL,'497.00','-1','1','-1','086BLtXBRn5GVS5phlDNCqQcBUrtn0J1msGmLire',NULL,60,60,NULL,NULL,1541124001,1542964181,1541124001,'',0,NULL,NULL,'test shipping address','5500021','k.l'),(45,'frank','frank',NULL,'0123881821',NULL,NULL,NULL,'$2y$10$pjghGdy4gqzhDFn7GGdkeO/iN1LH4Z9RnOGyOiWrEbZg9m2qoWM2G','frank@gmail.com','2018-11-02 10:09:28','public/avatar/2018_11_02-p2IdjHEjSNUaekQKkDNzrd3NchWN5q7i.png','active','admin','eVorVXZHWRMTIdbAfngLKEaVtArYVrO3JVPEbJL5nXwx7ppSk45xxha8bfTa',NULL,NULL,'2018-11-23 09:19:34','2018-11-02 02:09:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'192.228.220.0',NULL,NULL,NULL,'96.00','-1','1','-1','aQf5cWvy0VueFhz8vuRPOHFFRjDE88BS98e9FaZr',NULL,80,20,NULL,NULL,1541124568,1542964774,1541124568,'',0,NULL,NULL,'frank shipping address','555213','k.l.2'),(46,'alex','alex',NULL,'0123357698',NULL,NULL,NULL,'$2y$10$UGwLNoP/BUIqeP.lp1XQg.uvGAe5J8ZERHawqi7HC/ORAyAXksMfK','alex@email.com','2018-11-02 10:10:42','public\\avatar\\default.jpg','active','admin','DvQifJaB7PKj6xKBHjvwViBmBgJigshHwcKuNjG7tn61V8dieQDrGmJeQFkU',NULL,NULL,'2018-11-23 06:29:57','2018-11-02 02:10:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'192.228.220.0',NULL,NULL,NULL,'993.00','-1','1','-1','8BocpUJ2Z0gNB0nwwLpz5WbEjwzY8HKbWzkxFvAo',NULL,140,100,NULL,NULL,1541124642,1542954597,1541124642,'',0,NULL,NULL,'alex shipping address','554127','k.l-4'),(48,'te','te',NULL,'0107655623',NULL,NULL,NULL,'$2y$10$3pl1ismNxLKv4WeYH97x2.CQ30fQvpM6/XJDmD5o/cFcLh2nmYsfC',NULL,'2018-11-02 11:28:18','public\\avatar\\default.jpg','active','admin','yzkhM53hXCyO5GIeb7uL1NgLYHCsJ8atU8oFfJkyyWLdvhZoCHthlV5D4ccn',NULL,NULL,'2018-11-02 03:28:50','2018-11-02 03:28:18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'42.190.209.246',NULL,NULL,NULL,'0.00','-1','-1','-1',NULL,NULL,0,0,NULL,NULL,1541129298,1541129330,1541129298,'',0,NULL,NULL,'d','13213','d'),(49,'wk','wk',NULL,'0165344195',NULL,NULL,NULL,'$2y$10$gdhBIRlRCxDev0qwKh8xz.fsQl9GfyFfC1J7qczlQqEHi0WuP6a.u',NULL,'2018-11-02 13:25:16','public\\avatar\\default.jpg','active','normal','qOdYsAikxVsA0hYJXwwHRuN4b9J3JtTsMzLARZFFdlF0QCpV5uGWPYH8QTiV','heZkDE5V0Qv0wZXC7Q7IYzVSVHSHWsCzfzfTO6mO',NULL,'2018-11-21 03:04:46','2018-11-02 05:25:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'192.228.220.0',NULL,NULL,NULL,'898.00','-1','-1','-1','CjJEJMeGrjhuwrLqj17UTWUoKHdLHj1E93jtasuD','74e24cea4e8f3a0f0cbcd3948bcb73bf',140,60,NULL,NULL,1541136315,1542769486,1541136315,'',0,NULL,NULL,'e','32345','e'),(50,NULL,NULL,NULL,'0161234566',NULL,NULL,NULL,'$2y$10$rvdjQPFlc9QS8Ug27sTxae95uZHSLrz8633x7kHwLcKJCG31kR.Ui',NULL,'2018-11-13 11:05:56','public\\avatar\\default.jpg','pending','normal','2C2cIUd7YZh1kXFJ5nLrhZtgWZmPRbfaiCMb4mJC9RWxeLYUwMVgfC6qhZBawYKXpmPiwzHvLu8','2C2cIUd7YZh1kXFJ5nLrhZtgWZmPRbfaiCMb4mJC9RWxeLYUwMVgfC6qhZBawYKXpmPiwzHvLu8',NULL,'2018-11-13 03:06:54','2018-11-13 03:05:56',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'113.210.55.211',NULL,NULL,NULL,'0.00','-1','-1','-1',NULL,'22b0317dcd350110db97b666d02a741f',0,0,NULL,NULL,1542078355,1542078355,1542078355,'',0,NULL,NULL,NULL,NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
