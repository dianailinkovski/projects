<?php
	require_once('../../../wp-load.php');
	global $wpdb;
	
	if(isset($_REQUEST["request"]))
	{
		$request = $_REQUEST["request"];
		if($request == "getSetting")
		{
			$query = "select * from fd_setting";
			$result = $wpdb->get_results($query);
			$data = array();
			foreach ( $result as $row )  
			{
				$data[$row->name] = $row->value;
			}
			echo json_encode($data);
		}
		if($request == "saveSetting")
		{
			$pane_width = $_REQUEST["pane_width"];
			$pane_height = $_REQUEST["pane_height"];
			$wpdb->update('fd_setting', array(
			    'value' => $pane_width
				),	
				array('name' => 'pane_width')
			);
			$wpdb->update('fd_setting', array(
			    'value' => $pane_height
				),	
				array('name' => 'pane_height')
			);
		}
		if($request == "getShapeData")
		{
			$query = "SELECT * FROM fd_shape ORDER BY order_id";
			$result = $wpdb->get_results($query);
			echo json_encode($result);
		}
		if($request == "saveShapeData")
		{
			$data = json_decode(str_replace('\"', '"', $_REQUEST["data"]));
			for ($i=0; $i < count($data); $i++) { 
				$row = $data[$i];

				$id = $row->id;
				$name = $row->name;
				$base_price = $row->base_price;
				$sqm_price = $row->sqm_price;
				$edge_price = $row->edge_price;
				
				$wpdb->update('fd_shape', array(
						'name' => $name,
						'base_price' => $base_price,
				    'sqm_price' => $sqm_price,
				    'edge_price' => $edge_price
					),	
					array('id' => $id)
				);
			}
		}
	}
?>