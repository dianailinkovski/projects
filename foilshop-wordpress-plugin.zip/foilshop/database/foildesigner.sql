-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2019 at 10:32 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foildesigner`
--

-- --------------------------------------------------------

--
-- Table structure for table `fd_setting`
--

DROP TABLE IF EXISTS `fd_setting`;

CREATE TABLE `fd_setting` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `fd_setting` */

insert  into `fd_setting`(`id`,`name`,`value`) values (1,'pane_width','6000'),(2,'pane_height','1500'),(3,'price_calculation','1');

/*Table structure for table `fd_shape` */

DROP TABLE IF EXISTS `fd_shape`;

CREATE TABLE `fd_shape` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `shape_type` varchar(100) NOT NULL DEFAULT 'polygon',
  `preview` varchar(500) NOT NULL,
  `default_setting` varchar(500) NOT NULL,
  `base_price` double NOT NULL,
  `sqm_price` double NOT NULL,
  `edge_price` double NOT NULL,
  `min_width` int(11) NOT NULL,
  `min_height` int(11) NOT NULL,
  `max_width` int(11) NOT NULL,
  `max_height` int(11) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `order_id` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `fd_shape` */

insert  into `fd_shape`(`id`,`name`,`shape_type`,`preview`,`default_setting`,`base_price`,`sqm_price`,`edge_price`,`min_width`,`min_height`,`max_width`,`max_height`,`active`,`order_id`) values (1,'Triangle','triangle','triangle.png','[500]',10,5,5,0,0,0,0,1,0),(2,'Rectangle','rect','rectangle.png','{\"x\":200,\"y\":200,\"width\":200,\"height\":200,\"strokeWidth\":2,\"stroke\":\"black\"}',20,5,5,0,0,0,0,1,1),(3,'Round Rectangle','r_rect','round_rect.png','{\"x\":200,\"y\":200,\"width\":200,\"height\":200,\"cornerRadius\":50,\"strokeWidth\":2,\"stroke\":\"black\"}',20,5,10,0,0,0,0,1,2),(4,'Pentagon','pentagon','pentagon.png','{\"centerX\":200,\"centerY\":200,\"n\":6,\"length\":200}',30,5,5,0,0,0,0,1,4),(5,'Hexagon','hexagon','hexagon.png','{\"centerX\":200,\"centerY\":200,\"n\":8,\"length\":150}',30,5,5,0,0,0,0,1,3),(6,'Circle','circle','circle.png','{\"x\":100,\"y\":100,\"radius\":100,\"stroke\":\"black\",\"strokeWidth\":2}',15,5,0,0,0,0,0,1,5),(7,'Oval','oval','oval.png','{\"x\":100,\"y\":100,\"radiusX\":100,\"radiusY\":50,\"gap\":10,\"stroke\":\"black\",\"strokeWidth\":2}',15,5,0,0,0,0,0,1,6),(8,'Text','text','text.png','{\"x\": 150, \"y\": 150, \"text\": \"TEXT HERE\", \"fontSize\": 20, \"fontFamily\": \"Calibri\", \"fill\":\"green\"}',0,0,0,0,0,0,0,1,11),(9,'Draw shape','draw','draw.png','',20,5,5,0,0,0,0,1,12),(10,'Oval1','oval1','oval1.png','[]',10,0,0,0,0,0,0,1,7),(11,'Oval2','oval2','oval2.png','[]',10,0,0,0,0,0,0,1,8),(12,'Bootsform','bootsform','bootsform.png','[]',10,0,0,0,0,0,0,1,9),(13,'Bootsform Abgerundet','bootsform_a','bootsform_a.png','[]',10,0,0,0,0,0,0,1,10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fd_setting`
--
ALTER TABLE `fd_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fd_shape`
--
ALTER TABLE `fd_shape`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fd_setting`
--
ALTER TABLE `fd_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fd_shape`
--
ALTER TABLE `fd_shape`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1001;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
