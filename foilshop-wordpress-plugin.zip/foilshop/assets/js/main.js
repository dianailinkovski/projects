jQuery(document).ready(function () {
	setInitialState();
	jQuery(".save_change input").on("click", function(){
		var pane_width = jQuery("#pane_width").val();
		var pane_height = jQuery("#pane_height").val();
		if (Math.min(parseFloat(pane_width), parseFloat(pane_height)) > 1670 || Math.max(parseFloat(pane_width), parseFloat(pane_height)) > 6000) {
			alert('The Size is wrong. The maximize of area must be 1670x6000mm size.');
			return;
		}
		jQuery.ajax({
		    url: plugin_dir_url + "server.php",
		    async:false,
		    data: {"request":"saveSetting", pane_width:pane_width, pane_height:pane_height},
		    type: 'post',
		    success: function(result) {
		    	alert("The changes are saved.");
		    }
		});
	})
});

function setInitialState()
{
	jQuery.ajax({
	    url: plugin_dir_url + "server.php",
	    async:false,
	    data: {"request":"getSetting"},
	    type: 'post',
	    dataType: 'json',
	    success: function(result) {
	    	jQuery("#pane_width").val(result["pane_width"]);
	    	jQuery("#pane_height").val(result["pane_height"]);
	    }
	});
}