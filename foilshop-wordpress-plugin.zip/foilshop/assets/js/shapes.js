jQuery(document).ready(function () {
	getShapeData();
	jQuery(".save_change input").on("click", function(){
		var data = [];
		jQuery("#shape_table tbody tr").each(function(){
			var row = {};
			row["id"] = jQuery(this).attr("shape_id");
			row["name"] =  jQuery(this).children("td").eq(3).find("input").val();
			row["base_price"] =  jQuery(this).children("td").eq(4).find("input").val();
			row["sqm_price"] =  jQuery(this).children("td").eq(5).find("input").val();
			row["edge_price"] =  jQuery(this).children("td").eq(6).find("input").val();
			
			data.push(row);
		})
		jQuery.ajax({
		    url: plugin_dir_url + "server.php",
		    async:false,
		    data: {"request":"saveShapeData", data:JSON.stringify(data)},
		    type: 'post',
		    success: function(result) {
		    	alert("The changes are saved.");
	    	}
		});
	});
});
function getShapeData()
{
	jQuery.ajax({
	    url: plugin_dir_url + "server.php",
	    async:false,
	    data: {"request":"getShapeData"},
	    type: 'post',
	    dataType: 'json',
	    success: function(result) {
	    	jQuery("#shape_table tbody").html("");
	    	for (var i = 0; i < result.length; i++) {
	    		var shape = result[i];
	    		var row = jQuery('<tr shape_id="'+shape.id+'">');
	    		var no = jQuery('<td>' + (i+1) + '</td>');
	    		var name = jQuery('<td><input type="text" value="'+shape.name+'"></td>');
	    		var preview = jQuery('<td class="preview"><img src="'+plugin_dir_url+'editor/assets/images/'+shape.preview+'"></td>');
	    		var base_price = jQuery('<td><input type="text" value="'+shape.base_price+'"></td>');
	    		var sqm_price = jQuery('<td><input type="text" value="'+shape.sqm_price+'"></td>');
					var edge_price = jQuery('<td><input type="text" value="'+shape.edge_price+'"></td>');
					var activeStr = parseInt(shape.active) > 0 ? 'checked': '';
					row.append(no);
					row.append(preview);
	    		row.append(name);
	    		row.append(base_price);
	    		row.append(sqm_price);
					row.append(edge_price);					
	    		jQuery("#shape_table tbody").append(row);
	    	}
	    }
	});
}