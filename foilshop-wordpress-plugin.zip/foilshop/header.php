<link rel="stylesheet" type="text/css" media="screen" href="<?php echo plugin_dir_url( __FILE__ ) ?>assets/style.css" />
<script type="text/javascript">
	var plugin_dir_url = '<?php echo plugin_dir_url( __FILE__ ) ?>';
</script>