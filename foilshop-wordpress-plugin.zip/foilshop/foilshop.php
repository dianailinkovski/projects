<?php
/**
 * Plugin Name: FoilShop
 * Description: An eCommerce toolkit that helps you sell table foil. Beautifully.
 * Version: 3.6.2
 * Text Domain: foilshop
 * Domain Path: /languages/
 */

defined( 'ABSPATH' ) || exit;

global $woocommerce;

function create_plugin_database_table()
{
	global $wpdb;
    $wp_track_table = 'fd_shape';
    if($wpdb->get_var( "SHOW TABLES LIKE '$wp_track_table'" ) != $wp_track_table) 
    {
        $sql = file_get_contents(plugin_dir_url( __FILE__ ) . "database/foildesigner.sql");
        require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        dbDelta($sql);
    }
}

register_activation_hook( __FILE__, 'create_plugin_database_table' );

function foil_editor($atts) {
    $arguments = shortcode_atts( array( 
                                    'visible' => null, 
                                    'export' => null, 
                                    'price_calculation' => null, 
                                    'max_width' => null,
                                    'max_height' => null,
                                    'min_width' => null,
                                    'min_height' => null,
                                    'origin_data' => null,
                                    'product_page' => null, 
                                    'shapes' => null ), $atts );
    $visibleClass = $arguments['visible'] == null ? "in-active" : $arguments['visible'];
    $price_calculation = $arguments['price_calculation'] == null ? "normal" : $arguments['price_calculation'];
    $shapes = !isset($arguments['shapes']) ? "all" : $arguments['shapes'];
    $max_width = $arguments['max_width'] == null ? "" : $arguments['max_width'];
    $max_height = $arguments['max_height'] == null ? "" : $arguments['max_height'];
    $min_width = $arguments['min_width'] == null ? "" : $arguments['min_width'];
    $min_height = $arguments['min_height'] == null ? "" : $arguments['min_height'];
    $origin_data = $arguments['origin_data'] == null ? "" : $arguments['origin_data'];
    $export = $arguments['export'] == null ? "" : $arguments['export'];
    $base_price = "";
    $sqm_price = "";
    $edge_price = "";

    if ($arguments['product_page'] == 'yes') {
        global $product;
        $price_calculation = get_post_meta( $product->get_id(), 'price_calculation', true );
        $shapes = get_post_meta( $product->get_id(), 'available_shapes', true );
        $max_width = get_post_meta( $product->get_id(), 'max_width', true );
        $max_height = get_post_meta( $product->get_id(), 'max_height', true );
        $min_width = get_post_meta( $product->get_id(), 'min_width', true );
        $min_height = get_post_meta( $product->get_id(), 'min_height', true );
        $max_width = str_replace('"',"*",json_encode($max_width));
        $min_width = str_replace('"',"*",json_encode($min_width));
        $max_height = str_replace('"',"*",json_encode($max_height));
        $min_height = str_replace('"',"*",json_encode($min_height));
        $sqm_price = get_post_meta( $product->get_id(), 'sqm_price', true );
        $edge_price = get_post_meta( $product->get_id(), 'edge_price', true );
        $sqm_price = str_replace('"',"*",json_encode($sqm_price));
        $edge_price = str_replace('"',"*",json_encode($edge_price));
        $shapes = implode("#", $shapes);
        $shapes = !isset($shapes) ? "all": $shapes;
        $base_price = $product->get_regular_price();
        if( $product->is_on_sale() ) {
            $base_price = $product->get_sale_price();
        }        
    }
    
    $html = '
            <link rel="stylesheet" type="text/css" href="'. plugin_dir_url( __FILE__ ) . 'editor/assets/style.css">
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
                integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
            <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
            <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
                integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
            <link rel="stylesheet" type="text/css" media="screen" href="'. plugin_dir_url( __FILE__ ) . 'editor/assets/playground.css" />
            <script src="https://code.jquery.com/jquery-3.3.1.js"
                integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
            <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
            <script src="'. plugin_dir_url( __FILE__ ) . 'editor/assets/browser.maker.js" type="text/javascript"></script>
            <script src="https://pomax.github.io/bezierjs/bezier.js" type="text/javascript"></script>
            <script src="http://opentype.js.org/dist/opentype.js" type="text/javascript"></script>
            <script type="text/javascript">
                var plugin_dir_url = "'. plugin_dir_url( __FILE__ ) . '";
                var price_calculation = "'. $price_calculation . '";
                var visibleClass = "'. $visibleClass . '";
                var available_shapes = "'. $shapes . '"; 
                var max_width = "'. $max_width . '"; 
                var max_height = "'. $max_height . '"; 
                var min_width = "'. $min_width . '"; 
                var min_height = "'. $min_height . '"; 
                var base_price = "'. $base_price . '";
                var sqm_price = "'. $sqm_price . '"; 
                var edge_price = "'. $edge_price . '"; 
                var origin_data = "'. $origin_data .'";
                var makerjs = require("makerjs");
            </script>
            <script src="'. plugin_dir_url( __FILE__ ) . 'editor/assets/pointer.js"></script>
            <script src="'. plugin_dir_url( __FILE__ ) . 'editor/assets/playground.js"></script>
            <script src="'. plugin_dir_url( __FILE__ ) . 'editor/assets/initialize.js" type="text/javascript"></script>
            <script src="'. plugin_dir_url( __FILE__ ) . 'editor/assets/index.js" type="text/javascript"></script>
            <script src="'. plugin_dir_url( __FILE__ ) . 'editor/assets/event.js"></script>
            <script src="'. plugin_dir_url( __FILE__ ) . 'editor/assets/draw.js"></script>
            
            <div id="TF-wrapper" v-attr="'.($visibleClass == 'in-active'? 'hide': 'show').'" class="'.$visibleClass.'">
                <div id="TF-main">
                    <div id="TF-shapes">
                        <div id="pattern-bar">
                            <div class="list-toggle done uppercase">
                                <div class="list-toggle-title bold">'.__('SELECT SHAPE', 'foilshop').'</div>
                            </div>
                        </div>
                        <div id="pattern-list">
                        </div>
                    </div>
                    <div id="TF-design">
                        <div id="TF-statusbar">
                            <div class="shape-option">
                                <div>
                                    <select class="form-control" id="dimension-unit">
                                        <option value="Millimeter">mm</option>
                                        <option value="Centimeter">cm</option>
                                    </select>
                                </div>
                            </div>
                            <div class="shape-action">
                                <button type="button" action="undo" title="'.__('Undo', 'foilshop').'" class="btn btn-secondary"><i class="fas fa-undo"></i></button>
                                <button type="button" action="redo" title="'.__('Redo', 'foilshop').'" class="btn btn-secondary"><i class="fas fa-redo"></i></button>
                                <button action="measurelength" title="'.__('Length Measurement', 'foilshop').'" class="btn btn-secondary"><i
                                        id="ruler" class="fas fa-ruler-horizontal"></i></button>
                                <button action="clear" title="'.__('Remove Selected Shape', 'foilshop').'" class="btn btn-secondary"><i
                                        class="fa fa-trash"></i></button>
                                <button action="clearall" title="'.__('Remove All Shapes', 'foilshop').'" class="btn btn-secondary"><i
                                        class="fas fa-sync-alt"></i></button>';
                                if ($export == 'visible')
                                    $html = $html.'<button action="export" title="'.__('Export as DXF file', 'foilshop').'" class="btn btn-secondary"><i
                                class="fas fa-file-export"></i></button>';
                                $html = $html.'<button action="zoomin" title="'.__('Zoom In', 'foilshop').'" class="btn btn-secondary"><i
                                    class="fas fa-search-plus"></i></button>
                                <button action="zoom" title="'.__('Reset Zoom', 'foilshop').'" class="btn btn-secondary"><i
                                    class="fas fa-search"></i></button>
                                <button action="zoomout" title="'.__('Zoom Out', 'foilshop').'" class="btn btn-secondary"><i
                                    class="fas fa-search-minus"></i></button>                        
                            </div>
                            
                        </div>
                        <div id="TF-background">
                            <svg id="grid">
                                <defs>
                                    <pattern id="pattern1" x="0" y="0" width=".1" height=".1">
                                        <line x1="0" y1="0" x2="0" y2="100%" class="grid-line-1"></line>
                                        <line x1="0" y1="0" x2="100%" y2="0" class="grid-line-1"></line>
                                    </pattern>
                                    <pattern id="pattern10" x="0" y="0" width="1" height="1">
                                        <line x1="0" y1="0" x2="0" y2="100%" class="grid-line-10"></line>
                                        <line x1="0" y1="0" x2="100%" y2="0" class="grid-line-10"></line>
                                    </pattern>
                                    <pattern id="gridPattern" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse"
                                        patternTransform="translate(0,0)">
                                        <rect id="gridPatternFill" fill="url(#pattern1)" width="100" height="100" x="0" y="0">
                                        </rect>
                                        <rect fill="url(#pattern10)" width="100%" height="100%" x="0" y="0"></rect>
                                    </pattern>
                                </defs>
                                <rect fill="url(#gridPattern)" width="100%" height="100%" x="0" y="0">

                                </rect>
                                <!-- <g id="crosshairs">
                                    <line x1="-50%" x2="50%" y1="0" y2="0"></line>
                                    <line x1="0" x2="0" y1="-50%" y2="50%"></line>
                                </g> -->
                                <!-- <circle style="display: none" class="sel-point" id="selector" cx="100" cy="100" r="5" /> -->
                            </svg>
                        </div>
                        <div id="TF-drawing">
                            <div id="view-params" style="height: 100%">
                                <div id="view" touch-action="none" class="noselect">
                                    <div id="view-svg-container"></div>
                                    <svg id="pointers" xmlns="http://www.w3.org/2000/svg"></svg>
                                    <div id="touch-shield"></div>
                                </div>                        
                            </div>
                            <div id="selector" style="visibility: hidden;" class="sel-point"></div>
                        </div>
                    </div>
                </div>
                <div id="TF-other">
                    <h4>'.__('Your Estimated Price', 'foilshop').'</h4>
                    <h6 class="bold">'.__('Selected Shape', 'foilshop').'</h6>
                    <div class="base-price align-left">
                        <label class="price-item">'.__('Base Price', 'foilshop').':</label>&nbsp;<span class="value"></span>€
                    </div>
                    <div class="area align-left">
                        <label>'.__('Squaremeter', 'foilshop').': </label>&nbsp;<span class="value"></span>㎡
                    </div>
                    <div class="shape-price align-left">
                        <label>'.__('Price', 'foilshop').':</label>&nbsp;<span class="value"></span>€
                    </div>
                    <div class="total">
                        <strong>'.__('Total', 'foilshop').':</strong>&nbsp;<span class="value"></span>€
                    </div>
                    <button class="btn btn-primary" id="add-basket">'.__('Add to Cart', 'foilshop').'&nbsp;<i
                            class="fa fa-shopping-cart"></i></button>
                </div>
                <div id="TF-form" title="'.__('Edit Dimensions', 'foilshop').'">
                    <fieldset>
                        <label for="name">'.__('Dimension', 'foilshop').'</label>
                        <input type="text" name="radius" id="radius" value="0"
                            class="text ui-widget-content ui-corner-all">
                        <span class="units">mm</span>
                    </fieldset>
                </div>
                <div id="TF-text-form" title="'.__('Edit Text', 'foilshop').'">
                    <fieldset>
                        <label for="name">'.__('Font Size', 'foilshop').'</label>
                        <input type="number" style="margin-left: 20px" min="10" max="100" name="fontSize" id="fontSize" value="10"
                            class="text ui-widget-content ui-corner-all"><br/>
                        <label for="name">'.__('Text', 'foilshop').'</label>
                        <input type="text" name="text" id="text" value="text"
                                class="text ui-widget-content ui-corner-all">
                    </fieldset>
                </div>
                <div id="TF-message" title="'.__('Error', 'foilshop').'">
                    <p style="color: red; font-size: 16pt">
                    '.__('Invalid Value input or Exceeding max value!', 'foilshop').'!
                    </p>            
                </div>
            </div>
            ';
    return $html;
}
function foileditor_register_shortcode() {
    add_shortcode( 'foileditor', 'foil_editor' );
}
add_action( 'init', 'foileditor_register_shortcode' );

function add_editoroption_method() {
    $args = array(
        'id' => 'editor_option', // required. The meta_key ID for the stored value
        'wrapper_class' => '', // a custom wrapper class if needed
        'desc_tip' => true, // makes your description show up with a "?" symbol and as a tooltip
        'description' => __('A customer can use foil editor by selecting Enable.', 'foilshop'),
        'label' => __( 'Foil Editor', 'foilshop' ),
        'options' => array(
            'disable' => __( 'Disable', 'foilshop' ),
            'enable' => __( 'Enable', 'foilshop' )
        )
    );
    woocommerce_wp_select( $args );
}
add_action( 'woocommerce_product_options_general_product_data', 'add_editoroption_method', 18 );

add_action( 'plugins_loaded', 'foilshop_plugin_load_text_domain' );
function foilshop_plugin_load_text_domain() {
    load_plugin_textdomain( 'foilshop', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}

function save_editoroption_method( $post_id ) {
    $editor_option = isset( $_POST[ 'editor_option' ] ) ?  $_POST[ 'editor_option' ] : '';
    $product = wc_get_product( $post_id );
    $product->update_meta_data( 'editor_option', $editor_option );
    $product->save();
}
add_action( 'woocommerce_process_product_meta', 'save_editoroption_method' );

function add_price_calculation_method() {
    $args = array(
        'id' => 'price_calculation', // required. The meta_key ID for the stored value
        'wrapper_class' => '', // a custom wrapper class if needed
        'desc_tip' => true, // makes your description show up with a "?" symbol and as a tooltip
        'description' => __('Select how to calculate price of this product.', 'foilshop'),
        'label' => __( 'Price Calculation', 'foilshop' ),
        'options' => array(
            'normal' => __( 'Based on square meter', 'foilshop' ),
            'baseprice' => __( 'Based on square meter and a fixed price', 'foilshop' ),
            'edge' => __( 'Based on square meter and a fixed sum for each edge of the shape', 'foilshop' )
        )
    );
    woocommerce_wp_select( $args );
}
add_action( 'woocommerce_product_options_general_product_data', 'add_price_calculation_method', 19 );

function save_price_calculation_method( $post_id ) {
    $calculation_method = isset( $_POST[ 'price_calculation' ] ) ?  $_POST[ 'price_calculation' ] : '';
    $product = wc_get_product( $post_id );
    $product->update_meta_data( 'price_calculation', $calculation_method );
    $product->save();
}
add_action( 'woocommerce_process_product_meta', 'save_price_calculation_method' );

function woocommerce_wp_multi_checkbox( $field ) {
    global $thepostid, $post, $wpdb;

    $query = "SELECT * FROM fd_setting";
    $result = $wpdb->get_results($query);
    $maxW = 0;
    $maxH = 0;
    foreach ( $result as $row )  
    {
        if ($row->name == 'pane_width') $maxW = $row->value;
        else if ($row->name == 'pane_height') $maxH = $row->value;
    }

    $field['value'] = get_post_meta( $thepostid, $field['id'], true );
    $max_width = get_post_meta( $thepostid, "max_width", true );
    $max_height = get_post_meta( $thepostid, "max_height", true );
    $min_width = get_post_meta( $thepostid, "min_width", true );
    $min_height = get_post_meta( $thepostid, "min_height", true );
    $sqm_price = get_post_meta( $thepostid, "sqm_price", true );
    $edge_price = get_post_meta( $thepostid, "edge_price", true );

    $thepostid              = empty( $thepostid ) ? $post->ID : $thepostid;
    $field['class']         = isset( $field['class'] ) ? $field['class'] : 'select short';
    $field['style']         = isset( $field['style'] ) ? $field['style'] : '';
    $field['wrapper_class'] = isset( $field['wrapper_class'] ) ? $field['wrapper_class'] : '';
    $field['value']         = isset( $field['value'] ) ? (array)$field['value'] : array();
    $field['name']          = isset( $field['name'] ) ? $field['name'] : $field['id'];
    $field['desc_tip']      = isset( $field['desc_tip'] ) ? $field['desc_tip'] : false;

    echo '<fieldset class="form-field ' . esc_attr( $field['id'] ) . '_field ' . esc_attr( $field['wrapper_class'] ) . '">
    <legend>' . wp_kses_post( $field['label'] ) . '</legend>';

    if ( ! empty( $field['description'] ) && false !== $field['desc_tip'] ) {
        echo wc_help_tip( $field['description'] );
    }

    echo '<table class="wc-radios available_shapes_setting_table">
            <thead>
                <th></th>
                <th style="min-width:100px; text-align:left;">'.__('Name', 'foilshop').'</th>
                <th>'.__('Max Width', 'foilshop').'</th>
                <th>'.__('Max Height', 'foilshop').'</th>
                <th>'.__('Min Width', 'foilshop').'</th>
                <th>'.__('Min Height', 'foilshop').'</th>
                <th>'.__( 'Fixed Rate', 'foilshop' ).'</th>
                <th>'.__( 'Edge Price', 'foilshop' ).'</th>
            </thead>';

    foreach ( $field['options'] as $key => $value ) {

        echo '<tr>
                <td>
                    <input
                        name="' . esc_attr( $field['name'] ) . '"
                        value="' . esc_attr( $key ) . '"
                        type="checkbox"
                        class="' . esc_attr( $field['class'] ) . '"
                        style="' . esc_attr( $field['style'] ) . '"
                        ' . ( in_array( $key, $field['value'] ) ? 'checked="checked"' : '' ) . ' />
                </td>
                <td>
                    ' . esc_html( $value ) . '
                </td>
                <td>
                    <input type="text" style="Width:100%;" name="max_width[]" value="'.(!empty($max_width) ? $max_width[$key] : $maxW).'">
                </td>
                <td>
                    <input type="text" style="Width:100%;" name="max_height[]" value="'.(!empty($max_height) ? $max_height[$key] : $maxH).'">
                </td>
                <td>
                    <input type="text" style="Width:100%;" name="min_width[]" value="'.(!empty($min_width) ? $min_width[$key] : 0).'">
                </td>
                <td>
                    <input type="text" style="Width:100%;" name="min_height[]" value="'.(!empty($min_height) ? $min_height[$key] : 0).'">
                </td>
                <td>
                    <input type="text" style="Width:100%;" name="sqm_price[]" value="'.(!empty($sqm_price) ? $sqm_price[$key] : 0).'">
                </td>
                <td>
                    <input type="text" style="Width:100%;" name="edge_price[]" value="'.(!empty($edge_price) ? $edge_price[$key] : 0).'">
                </td>
        </tr>';
    }
    echo '</table>';

    if ( ! empty( $field['description'] ) && false === $field['desc_tip'] ) {
        echo '<span class="description">' . wp_kses_post( $field['description'] ) . '</span>';
    }

    echo '</fieldset>';
}

$GLOBALS['shapes_list'] = array(
    "triangle" => "Triangle",
    "rect" => "Rectangle",
    "r_rect" => "Round Rectangle",
    "pentagon" => "Pentagon",
    "hexagon" => "Hexagon",
    "circle" => "Circle",
    "oval" => "Oval",
    "oval1" => "Oval1",
    "oval2" => "Oval2",
    "bootsform" => "Bootsform",
    "bootsform_a" => "Bootsform abgerundet",
    "text" => "Text",
    "draw" => "Draw shape");

add_action( 'woocommerce_product_options_general_product_data', 'add_available_shapes', 20 );
function add_available_shapes() {
    global $post;

    echo '<div class="options_group hide_if_variable"">'; // Hidding in variable products

    $options = array();
    foreach ($GLOBALS['shapes_list'] as $key => $value) {
        $options[$key] = __( $value, 'foilshop' );
    }
    woocommerce_wp_multi_checkbox( array(
        'id'    => 'available_shapes',
        'name'  => 'available_shapes[]',
        'label' => __('Available Shapes', 'foilshop'),
        'options' => $options
    ) );

    echo '</div>';
}

// Save custom multi-checkbox fields to database when submitted in Backend (for all other product types)
add_action( 'woocommerce_process_product_meta', 'save_available_shapes', 30, 1 );
function save_available_shapes( $post_id ){
    if( isset( $_POST['available_shapes'] ) )
    {
        $post_data = $_POST['available_shapes'];
        // Data sanitization
        $sanitize_data = array();
        if( is_array($post_data) && sizeof($post_data) > 0 ){
            foreach( $post_data as $value ){
                $sanitize_data[] = esc_attr( $value );
            }
        }
        $max_width = array();
        $max_height = array();
        $min_width = array();
        $min_height = array();
        $sqm_price = array();
        $edge_price = array();
        $index = 0;
        foreach ($GLOBALS['shapes_list'] as $key => $value) {
            $max_width[$key] = $_POST['max_width'][$index];
            $max_height[$key] = $_POST['max_height'][$index];
            $min_width[$key] = $_POST['min_width'][$index];
            $min_height[$key] = $_POST['min_height'][$index];
            $sqm_price[$key] = $_POST['sqm_price'][$index];
            $edge_price[$key] = $_POST['edge_price'][$index];
            $index++;
        }
        update_post_meta( $post_id, 'available_shapes', $sanitize_data );
        update_post_meta( $post_id, 'max_width', $max_width );
        update_post_meta( $post_id, 'max_height', $max_height );
        update_post_meta( $post_id, 'min_width', $min_width );
        update_post_meta( $post_id, 'min_height', $min_height );
        update_post_meta( $post_id, 'sqm_price', $sqm_price );
        update_post_meta( $post_id, 'edge_price', $edge_price );
    }
    else
    {
        update_post_meta( $post_id, 'available_shapes', array() );
        update_post_meta( $post_id, 'max_width', array() );
        update_post_meta( $post_id, 'max_height', array() );
        update_post_meta( $post_id, 'min_width', array() );
        update_post_meta( $post_id, 'min_height', array() );
        update_post_meta( $post_id, 'sqm_price', array() );
        update_post_meta( $post_id, 'edge_price', array() );
    }
}

function cfwc_create_custom_field() {
    $args = array(
        'id' => 'dxf_data',
        'value'=>'DXF-Data',
        'label' => __( 'DXF Data Title', 'foilshop' ),
        'class' => 'foilshop-custom-field',
        'desc_tip' => true,
        'description' => __( 'Enter the title of the dxf data field.', 'foilshop' ),
    );
    woocommerce_wp_text_input( $args );
}
//add_action( 'woocommerce_product_options_general_product_data', 'cfwc_create_custom_field' );

function cfwc_save_custom_field( $post_id ) {
    $product = wc_get_product( $post_id );
    $data = isset( $_POST['dxf_data'] ) ? $_POST['dxf_data'] : '';
    $product->update_meta_data( 'dxf_data', sanitize_text_field( $data ) );
    $product->save();
}
//add_action( 'woocommerce_process_product_meta', 'cfwc_save_custom_field' );

function cfwc_display_custom_field() {
    global $post;
    $product = wc_get_product( $post->ID );
    $data = $product->get_meta( 'dxf_data' );
    if(!$data)
    {
        $product->update_meta_data( 'dxf_data', "DXF-Data" );
        $product->save();
        $data = "DXF-Data";
    }
    printf(
        '<div class="foilshop-custom-field-wrapper dxf-data-wrapper"><label for="cfwc-title-field">%s</label><input type="text" id="cfwc-title-field" name="cfwc-title-field" value=""></div>',
        esc_html( $data )
    );
}
add_action( 'woocommerce_before_add_to_cart_button', 'cfwc_display_custom_field' );

function cfwc_add_custom_field_item_data( $cart_item_data, $product_id, $variation_id, $quantity ) {
    if( ! empty( $_POST['cfwc-title-field'] ) ) 
    {
        $cart_item_data['title_field'] = $_POST['cfwc-title-field'];
        $product = wc_get_product( $product_id ); // Expanded function
        $price = $product->get_price(); // Expanded function
        $cart_item_data['total_price'] = explode("&&", $_POST['cfwc-title-field'])[1];
    }
    return $cart_item_data;
}
add_filter( 'woocommerce_add_cart_item_data', 'cfwc_add_custom_field_item_data', 10, 4 );

function cfwc_before_calculate_totals( $cart_obj ) {
    if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
        return;
    }
    foreach( $cart_obj->get_cart() as $key=>$value ) 
    {
        if( isset( $value['total_price'] ) ) 
        {
            $price = $value['total_price'];
            $value['data']->set_price( ( $price ) );
        }
    }
}
add_action( 'woocommerce_before_calculate_totals', 'cfwc_before_calculate_totals', 10, 1 );

function cfwc_cart_item_name( $name, $cart_item, $cart_item_key ) {
    if( isset( $cart_item["title_field"] ) ) 
    {
        $name = sprintf('<p>%s</p>', esc_html( explode("&&", $cart_item["title_field"])[2] ));        
    }
    return $name;
}
add_filter( 'woocommerce_cart_item_name', 'cfwc_cart_item_name', 10, 3 );

function cfwc_add_custom_data_to_order( $item, $cart_item_key, $values, $order ) {
    foreach( $item as $cart_item_key=>$values ) 
    {
        if( isset( $values['title_field'] ) ) {
            $item->add_meta_data( 'DXF-Data', $values['title_field'], true );
        }
    }
}
add_action( 'woocommerce_checkout_create_order_line_item', 'cfwc_add_custom_data_to_order', 10, 4 );

function add_createnew_button_on_product_page(  ) { 
    global $product;
    $editor_option = get_post_meta( $product->get_id(), 'editor_option', true );
    if($editor_option == "enable")
    echo '<div>
        <button id="foileditor_new" style="display:none" href="javascript:;" onclick="document.getElementById('."'TF-wrapper'".').classList.remove('."'in-active'".');" title="You can create your own foil with editor by clicking here.">'.__('Create New', 'foilshop').'</button>
    </div>';
}
add_filter( 'woocommerce_product_meta_end', 'add_createnew_button_on_product_page', 98 );

function add_foildesigner_on_order_page($order_get_id) { 
    $order = new WC_Order( $order_get_id );
    $items = $order->get_items();    
    echo 
        '<tbody id="foil-editor">
            <tr>
                <td colspan="7">'.
                    do_shortcode( 
                        '[foileditor 
                        export="visible"
                        shapes="all"]'
                    )
                .'</td>
            </tr>
        </tbody>';   
}
add_filter( 'woocommerce_admin_order_items_after_line_items', 'add_foildesigner_on_order_page', 98 );
// add_filter( 'woocommerce_admin_order_data_after_order_details', 'add_foildesigner_on_order_page', 98 );

add_action( 'woocommerce_admin_order_item_values', 'view_button_admin_order_item_values', 10, 3 );
function view_button_admin_order_item_values( $null, $item, $item_id ) {
    $dxf_data = wc_get_order_item_meta( $item_id, 'DXF-Data', true );
    if ($dxf_data && sizeof($dxf_data) > 0) {
        echo '<td class="view-data"><a class="button tips" href="javascript: getShapeDatas('.$item_id.')" data-tip="'.__('View Shapes', 'foilshop').'">'.__('View', 'foilshop').'</td>';
    } else {
        echo '<td class="view-data"></td>';
    }      
}

function add_customcss_admin() { 
    echo 
        '<style type="text/css">
            .woocommerce_order_items .display_meta tbody tr td p
            {
                text-overflow:ellipsis; 
                white-space:nowrap; 
                overflow:hidden; 
                max-width:250px;
                cursor:pointer;
            }

            .woocommerce_order_items td.view-data
            {
                width: 60px;
                max-width: 60px;
            }
            .woocommerce_order_items_wrapper #foil-editor #TF-other
            {
                display: none;
            }
            .foilshop-custom-field-wrapper {
                display: none;
            }

            .woocommerce_order_items_wrapper tbody:not(#order_line_items) .view-data a.button {
                display: none;
            }
        </style>';
    echo '<th class="item view-data">'.__('View', 'foilshop').'</th>"';
}
add_filter( 'woocommerce_admin_order_item_headers', 'add_customcss_admin', 99 );

function add_customcss_user() { 
    echo 
        '<style type="text/css">
            .woocommerce-cart-form__cart-item .product-name p, .woocommerce-checkout-review-order-table .product-name p, .woocommerce-table--order-details .wc-item-meta p
            {
                text-overflow:ellipsis; 
                white-space:nowrap; 
                overflow:hidden; 
                max-width:250px;
            }
            .foilshop-custom-field-wrapper {
                display: none;
            }
        </style>';
}
add_filter( 'woocommerce_before_cart', 'add_customcss_user', 99 );
add_filter( 'woocommerce_before_checkout_form', 'add_customcss_user', 99 );
add_filter( 'woocommerce_view_order', 'add_customcss_user', 99 );
add_filter( 'woocommerce_thankyou', 'add_customcss_user', 99 );