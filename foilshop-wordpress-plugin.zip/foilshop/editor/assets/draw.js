function drawModel(key = "circle") {
  var model = null;
  measurePoints = [];
  measureStatus = false;
  var paths = {};
  if (foilModels.paths) {
    Object.keys(foilModels.paths).forEach(key => {
      if (key != "measure") paths[key] = foilModels.paths[key];
    });
  }
  foilModels.paths = paths;
  jQuery(".measure-number").remove();
  if (key != "text") {
    var radius = [500, 500];
    if (dimentsionLimits.max_w[key] < 1000) radius[0] = parseInt(dimentsionLimits.max_w[key]/2);
    if (dimentsionLimits.max_h[key] < 1000) radius[1] = parseInt(dimentsionLimits.max_h[key]/2);
    
    if (key == "circle") {
      var minR = Math.min(...radius);
      radius = [minR, minR];
      model = drawEllipse(radius);
      model.radius = radius;
      model.origin = [0, 0];
    } else if (key == "hexagon") {
      var minR = Math.min(...radius);
      radius = [minR, minR];
      // var rR = parseInt(radius[0] / 0.866);
      model = drawPolygons(8, radius[0], 22.5);
      model.radius = [radius[0]];
      model.origin = [0, 0];
    } else if (key == "oval") {
      radius[1] = 250;
      if (dimentsionLimits.max_h[key] < 500) radius[1] = parseInt(dimentsionLimits.max_h[key]/2);
      model = drawEllipse(radius);
      model.radius = radius;
      model.origin = [0, 0];
    } else if (key == "oval1") {
      radius[1] = 250;
      if (dimentsionLimits.max_h[key] < 500) radius[1] = parseInt(dimentsionLimits.max_h[key]/2);
      model = drawRoundRect(radius[0] * 2, radius[1] * 2, 0, true);
      model.radius = [radius[0] * 2, radius[1] * 2];
      model.origin = [-radius[0], -radius[1]];
    } else if (key == "oval2") {
      radius[1] = 250;
      if (dimentsionLimits.max_h[key] < 500) radius[1] = parseInt(dimentsionLimits.max_h[key]/2);
      var minR = Math.min(...radius);
      radius.push(minR < 100? minR: 100);
      model = drawOval2(radius);
      model.radius = radius;
      model.origin = [0, 0];
    } else if (key == "pentagon") {
      var minR = Math.min(...radius);
      radius = [minR, minR];
      model = drawPolygons(6, radius[0], 0);
      model.radius = [radius[0]];
      model.origin = [0, 0];
    } else if (key == "rect") {
      model = new makerjs.models.Rectangle(radius[0] * 2, radius[1] * 2);
      model.radius = [radius[0] * 2, radius[1] * 2, 0];
      model.origin = [-radius[0], -radius[1]];
    } else if (key == "r_rect") {
      var minR = Math.min(...radius);
      radius.push(minR/2 <= 50? minR: 50);
      radius.push(minR/2 <= 100? minR: 100);
      radius.push(minR/2 <= 150? minR: 150);
      radius.push(minR/2 <= 200? minR: 200);
      radius[0] = radius[0] * 2;
      radius[1] = radius[1] * 2;
      model = drawMultiRoundedRect(radius);
      model.radius = radius;
      model.origin = [0, 0];
    } else if (key == "triangle") {
      var minR = Math.min(...radius);
      model = drawPolygons(3, minR, 90);
      model.radius = [minR];
      model.origin = [0, 0];
    } else if (key == "bootsform") {  
      radius = [500, 200];
      if (dimentsionLimits.max_w[key] < 500) radius[0] = parseInt(dimentsionLimits.max_w[key]);
      if (dimentsionLimits.max_h[key] < 250) radius[1] = parseInt(dimentsionLimits.max_h[key]) - 10;
      radius.push(dimentsionLimits.max_h[key] < 250? parseInt(dimentsionLimits.max_h[key]): 250);
      model = drawBootsForm(radius);
      model.origin = [0, 0];
    } else if (key == "bootsform_a") { 
      radius = [500, 200];
      if (dimentsionLimits.max_w[key] < 600) radius[0] = parseInt(dimentsionLimits.max_w[key]) - 10;
      if (dimentsionLimits.max_h[key] < 250) radius[1] = parseInt(dimentsionLimits.max_h[key]) - 10;
      radius.push(dimentsionLimits.max_h[key] < 250? parseInt(dimentsionLimits.max_h[key]): 250);
      radius.push(dimentsionLimits.max_w[key] < 600? parseInt(dimentsionLimits.max_w[key]): 600);
      model = drawBootsForm(radius);     
      model.origin = [0, 0];      
    } else if (key == "draw") {
      model = {};
      model.origin = [0, 0];
      model.sPoints = [];
    }

    var objKeys = Object.keys(foilModels.models);

    if (key == 'draw' && objKeys.length <= 0 && objKeys.indexOf('background') < 0) {
      var background = drawEllipse([500, 500]);
      background.layer = 'white';
      foilModels.models.background = background;
    }

    var objKey = `m${objKeys.length}`;
    model.myKey = key;
    if (["triangle", "draw"].indexOf(key) < 0)
      model = makerjs.model.center(model);
    model.showFlag = true;
    foilModels.models[objKey] = model;
    addHistory();
    MakerJsPlayground.setProcessedModel(foilModels, null);
    // $('#view-svg-container').append(makerjs.exporter.toSVG(foilModels));
  } else {
    opentype.load(plugin_dir_url + 'editor/assets/fonts/roboto/Roboto-Black.ttf', function (err, font) {
      if (err) {
        alert('the font could not be loaded :(');
      } else {
        globalFont = font;
        model = new makerjs.models.Text(font, 'text', 50);
        var objKeys = Object.keys(foilModels.models);
        var objKey = `m${objKeys.length}`;
        model.text = 'text';
        model.fontSize = 50;
        model.myKey = key;
        model.origin = [0, 0];
        foilModels.models[objKey] = model;

        for (var i = 0; i < objKeys.length; i++) {
          makerjs.model.center(foilModels.models[objKeys[i]]);
        }
        addHistory();
        MakerJsPlayground.setProcessedModel(foilModels, null);        
      }
    });
  }
}

function drawEllipse(radius) {
  return new makerjs.models.Ellipse(radius[0], radius[1]);
}

function drawPolygons(sides, radius, angle) {
  return new makerjs.models.Polygon(sides, radius, angle);
}

function drawRoundRect(width, height, radius, flag) {
  if (flag) radius = Math.min(width, height)/2;
  return new makerjs.models.RoundRectangle(width, height, radius);
}

function drawMultiRoundedRect(radius) {
  var width = radius[0] - 2*radius[2];
  var height = radius[1] - 2 * radius[2];
  var ltPoint = [-radius[0]/2, radius[1]/2];
  var lbPoint = [-radius[0]/2, -radius[1]/2];
  var rtPoint = [radius[0]/2, radius[1]/2];
  var rlPoint = [radius[0]/2, -radius[1]/2];

  var p = makerjs.point;
  var model ={};
  var leftLine = new makerjs.paths.Line(p.subtract(ltPoint, [0, radius[2]]), p.add(lbPoint, [0, radius[5]]));
  makerjs.path.addTo(leftLine, model, 'left-side');
  var tlRadius = new makerjs.paths.Arc(p.add(ltPoint, [radius[2], -radius[2]]), radius[2], 90, 180);
  makerjs.path.addTo(tlRadius, model, 'top-left-corner');
  
  var topLine = new makerjs.paths.Line(p.add(ltPoint, [radius[2], 0]), p.subtract(rtPoint, [radius[3], 0]));
  makerjs.path.addTo(topLine, model, 'top-side');
  var trRadius = new makerjs.paths.Arc(p.subtract(rtPoint, [radius[3], radius[3]]), radius[3], 0, 90);
  makerjs.path.addTo(trRadius, model, 'top-right-corner');

  var rightLine = new makerjs.paths.Line(p.subtract(rtPoint, [0, radius[3]]), p.add(rlPoint, [0, radius[4]]));
  makerjs.path.addTo(rightLine, model, 'right-side');
  var brRadius = new makerjs.paths.Arc(p.add(rlPoint, [-radius[4], radius[4]]), radius[4], 270, 0);
  makerjs.path.addTo(brRadius, model, 'bottom-right-corner');
  
  var bottomLine = new makerjs.paths.Line(p.subtract(rlPoint, [radius[4], 0]), p.add(lbPoint, [radius[5], 0]));
  makerjs.path.addTo(bottomLine, model, 'bottom-side');
  var blRadius = new makerjs.paths.Arc(p.add(lbPoint, [radius[5], radius[5]]), radius[5], 180, 270);
  makerjs.path.addTo(blRadius, model, 'bottom-left-corner'); 

  makerjs.model.moveRelative(model, [-radius[0]/2, -radius[1]/2]);
  return model;
}

function drawOval2(radius) {
  var a = (radius[0] - radius[2])/2;
  var oval1 = new makerjs.models.EllipticArc(90, 270, a, radius[1]/2);
  var oval2 = makerjs.model.move(oval1, [-radius[2]/2, 0]);
  var oval3 = makerjs.model.mirror(oval2, true, false);
  var result =  makerjs.model.combine(oval2, oval3, true, true, true, true);
  var line1 = new makerjs.paths.Line([-radius[2]/2, radius[1]/2], [radius[2]/2, radius[1]/2]);
  var line2 = makerjs.path.mirror(line1, false, true);
  makerjs.path.addTo(line1, result, "top", false);
  makerjs.path.addTo(line2, result, "bottom", false);

  return result;
}

function drawBootsForm(radius) {
  var a = calcER(radius);
  var modelA = new makerjs.models.Ellipse(a, radius[2]/2);

  var modelB = null;
  var bA = 0;
  var bootsform = null;
  if (radius.length > 3) {
    bA = calcER([radius[1], radius[0], radius[3]]);
    modelB = new makerjs.models.Ellipse(bA, radius[3]/2);
    modelB = makerjs.model.rotate(modelB, 90);
    bootsform = (bA > 0 && bA > radius[2]/2)? makerjs.model.combineIntersection(modelA, modelB): makerjs.model.combineUnion(modelA, modelB);    
  } else {
    modelB = makerjs.model.move(new makerjs.models.Rectangle(radius[0], radius[2] + 50), [-radius[0]/2, -radius[2]/2 - 20]);
    bootsform = makerjs.model.combine(modelA, modelB, true, false, false, false);
    var leftTopP = makerjs.point.add([0, 0], [radius[0]/2, radius[1]/2]);
    var rightTopP = makerjs.point.add([0, 0], [-radius[0]/2, radius[1]/2]);
    var rightBottomP = makerjs.point.add([0, 0], [-radius[0]/2, -radius[1]/2]);
    var leftBottomP = makerjs.point.add([0, 0], [radius[0]/2, -radius[1]/2]);
    makerjs.model.addPath(bootsform, new makerjs.paths.Line(leftTopP, leftBottomP), 'left-l', true);
    makerjs.model.addPath(bootsform, new makerjs.paths.Line(rightTopP, rightBottomP), 'right-l', true);
  }
  
  bootsform.radius = radius;  
  return bootsform;  
}

function calcER(radius) {
  var b = radius[2]/2;
  var rate = Math.pow(radius[0]/2, 2)/(Math.pow(radius[2]/2, 2) - Math.pow(radius[1]/2, 2));
  return Math.sqrt(Math.pow(b, 2) * rate);
}

function drawCustoms(sPoints, finished) {
  var model = {};  
  for (var i = 1; i < sPoints.length; i++) {
    makerjs.path.addTo(new makerjs.paths.Line(makerjs.point.mirror(sPoints[i-1], false, true), makerjs.point.mirror(sPoints[i], false, true)), model, 'L_' + i);
  }
  if (finished) {
    makerjs.path.addTo(new makerjs.paths.Line(makerjs.point.mirror(sPoints[0], false, true), makerjs.point.mirror(sPoints[sPoints.length -1], false, true)), model, 'L_' + sPoints.length);
  }
  return model;
}

function reRenderModels(model) {
  var temp = null;
  if (model.myKey == "circle") {
    temp = drawEllipse(model.radius);
  } else if (model.myKey == "hexagon") {
    temp = drawPolygons(8, model.radius[0], 22.5);
  } else if (model.myKey == "oval") {
    temp = drawEllipse(model.radius);
  } else if (model.myKey == "pentagon") {
    temp = drawPolygons(6, model.radius[0], 0);
  } else if (model.myKey == 'rect') {
    temp = new makerjs.models.Rectangle(model.radius[0], model.radius[1]);
    makerjs.model.move(temp, model.origin);  
  } else if (model.myKey == "r_rect") {
    temp = drawMultiRoundedRect(model.radius);
  } else if (model.myKey == "oval1") {
    temp = drawRoundRect(model.radius[0], model.radius[1], model.radius[2], model.myKey == "oval1");
    // temp.origin = makerjs.point.add(model.origin, [model.radius[0] / 2, model.radius[1] / 2]);
    makerjs.model.move(temp, model.origin);    
  } else if (model.myKey == "triangle") {
    temp = drawPolygons(3, model.radius[0], 90);
  } else if (model.myKey.indexOf("bootsform") >= 0) {
    console.log(model.radius);
    temp = drawBootsForm(model.radius);
  } else if (model.myKey == "oval2") {
    temp = drawOval2(model.radius);
  } else if (model.myKey == 'draw') {
    temp = drawCustoms(model.sPoints, model.finished);
    temp.sPoints = model.sPoints;
    temp.finished = model.finished;
  } else if (model.myKey == 'text') {
    if (globalFont) {
      temp = new makerjs.models.Text(globalFont, model.text, model.fontSize);
      temp.fontSize = model.fontSize;
      temp.text = model.text;
      temp.sPoints = model.sPoints;
    } else {
      temp = model;
    }
  }
  var rect = makerjs.measure.modelExtents(temp);
  const width = parseInt(rect.width);
  const height = parseInt(rect.height);
  if (width > Number(dimentsionLimits.max_w[model.myKey]) || width < Number(dimentsionLimits.min_w[model.myKey])) {
    return null;
  }

  if (height > Number(dimentsionLimits.max_h[model.myKey]) || height < Number(dimentsionLimits.min_h[model.myKey])) {
    return null;
  }
  
  temp.myKey = model.myKey;
  temp.radius = model.radius;
  temp.showFlag = model.showFlag;
  // if (model.myKey != "rect")
    temp.origin = model.origin;
    temp.layer = model.layer;
    temp.selected = model.selected;
  if (model.orgRadius)
    temp.orgRadius = model.orgRadius;
  return temp;
}