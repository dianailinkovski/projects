(function () {
    $(document).ready(function () {
        $("#foileditor_new").css('display', 'inline');
        MakerJsPlayground.onload();
        initialize();
        eventInitialize();                
    });
})();