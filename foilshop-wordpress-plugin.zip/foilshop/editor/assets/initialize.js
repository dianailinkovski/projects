var server_url = plugin_dir_url + "editor/server.php";
var shape_list = [];
var backgroundModel = null;
var foilModels = {
    models: {},
    paths: {},
    units: 'mm'
};
var dimensionEditor = null;
var errorMessage = null;
var errorMsgText = '';
var measureStatus = false;
var measurePoints = [];
var foilHistorys = [];
var historyIndex = 0;
var customDrawing = false;
var globalFont = null;
var textEditor = null;
var units = 'mm';
var dimentsionLimits = {};

function initialize() {
    if (max_width.length > 0) {
        var maxWs = JSON.parse(max_width.replace(/\*/g, '"'));
        var minWs = JSON.parse(min_width.replace(/\*/g, '"'));
        var maxHs = JSON.parse(max_height.replace(/\*/g, '"'));
        var minHs = JSON.parse(min_height.replace(/\*/g, '"'));

        dimentsionLimits = {
            max_w: maxWs,
            min_w: minWs,
            max_h: maxHs,
            min_h: minHs
        };
    }

    dimensionEditor = jQuery("#TF-form").dialog({
        autoOpen: false,
        height: 250,
        width: 350,
        modal: true,
        buttons: {
            Ok: function () {
                var res = editDimension();
                if (!res.status) {
                    errorMsgText = res.msg;
                    errorMessage.dialog("open");
                } else {
                    dimensionEditor.dialog("close");
                }
            }
        },
        close: function () {},
        open: function(event) {
            var modalEl = event.target;
            $(modalEl).find('input[type="text"]').keyup(function(e) {
                var keyVal = e.keyCode || e.which;
                if (keyVal == 13 ) {
                    var res = editDimension();
                    if (!res.status) {
                        errorMsgText = res.msg;
                        errorMessage.dialog("open");
                    } else {
                        dimensionEditor.dialog("close");
                    }
                }
            });
        }
    });

    textEditor = jQuery("#TF-text-form").dialog({
        autoOpen: false,
        height: 250,
        width: 350,
        modal: true,
        buttons: {
            Ok: function () {
                var flag = editText();
                if (flag) {
                    errorMessage.dialog("open");
                } else {
                    textEditor.dialog("close");
                }
            }
        },
        close: function () {},
        open: function(event) {
            var modalEl = event.target;
            $(modalEl).find('input[type="text"]').keyup(function(e) {
                var keyVal = e.keyCode || e.which;
                if (keyVal == 13 ) {
                    var flag = editText();
                    if (flag) {
                        errorMessage.dialog("open");
                    } else {
                        textEditor.dialog("close");
                    }
                }
            });
        }
    });

    errorMessage = jQuery("#TF-message").dialog({
        modal: true,
        autoOpen: false,
        buttons: {
            Ok: function () {
                jQuery(this).dialog("close");
            }
        },
        open: function(e) {
            var modalEl = e.target;
            jQuery('#TF-message p').html(errorMsgText);
        }
    });

    setShapeList();
    setBackground();
    foilHistorys = [];
    historyIndex = 0;
    jQuery(".shape-action button[action='undo']").attr("disabled", true);
    jQuery(".shape-action button[action='redo']").attr("disabled", true);
    if (parseInt(origin_data) > 0) {
        jQuery.ajax({
            url: server_url,
            async: false,
            data: {"request":"get_dxf_data", "item_id": origin_data},
            type: 'post',
            dataType: 'json',
            success: function(res) {
                if (res.result == 'success') {
                    var temp = JSON.parse(res.dxf_data.replace(/\\/g, ''));
                    foilModels = temp;
                    addHistory();
                    MakerJsPlayground.setProcessedModel(foilModels, null);
                }
            }
        });
    } else {
        foilModels.units = makerjs.unitType.Millimeter;
    }
}

function getShapeDatas(product_id) {
    const flag = jQuery("#foil-editor #TF-wrapper").attr('v-attr');
    if (flag == 'hide') {
        jQuery("#foil-editor #TF-wrapper").attr('v-attr', 'show');
        jQuery("#foil-editor #TF-wrapper").removeClass('in-active');
        if (parseInt(product_id) > 0) {
            jQuery.ajax({
                url: server_url,
                async: false,
                data: {"request":"get_dxf_data", "item_id": product_id},
                type: 'post',
                dataType: 'json',
                success: function(res) {
                    if (res.result == 'success') {
                        if (res.dxf_data.length > 0) {
                            var temp = JSON.parse(res.dxf_data.replace(/\\/g, ''));
                            foilModels = temp;
                            addHistory();
                            MakerJsPlayground.setProcessedModel(foilModels, null);
                        }
                    }
                }
            });         
        } else {
            foilModels.units = makerjs.unitType.Millimeter;
        }
    } else {
        jQuery("#foil-editor #TF-wrapper").attr('v-attr', 'hide');
        jQuery("#foil-editor #TF-wrapper").addClass('in-active');
    }
}

function setShapeList() {
    jQuery("#pattern-list").html("");
    jQuery.ajax({
        url: server_url,
        async: false,
        data: {"request":"getshapedata"},
        type: 'post',
        dataType: 'json',
        success: function(result) {
            pane_width = Number(result["pane_width"]);
            pane_height = Number(result["pane_height"]);
            var temp = [];
            if(available_shapes == "all")
         		temp = result["shape"];
         	else
         	{
         		var arr = available_shapes.split("#");
         		for (var i = 0; i < result["shape"].length; i++) {
         			if(arr.indexOf(result["shape"][i].shape_type) > -1)
         				temp.push(result["shape"][i]);
         		}
            }
            var bases = sqm_price.length > 0? JSON.parse(sqm_price.replace(/\*/g, '"')): {};
            var edges = edge_price.length > 0? JSON.parse(edge_price.replace(/\*/g, '"')): {};
            shape_list = temp.map(item => {
                return {
                    id: item.shape_type,
                    name: item.name,
                    preview: item.preview,
                    base_price: bases[item.shape_type]? bases[item.shape_type]: 0,
                    sqm_price: base_price,
                    edge_price: edges[item.shape_type]? edges[item.shape_type]: 0
                }
            });
            var shape_preview_url = plugin_dir_url + "editor/assets/images/";
            for (var i = 0; i < shape_list.length; i++) {
                var shape = shape_list[i];
                var shape_group = jQuery('<div class="vltTDT-patternBar-patternGroup" shape_id="' + shape.id + '">');
                var shape_name = jQuery('<h3 title="' + shape.name + '">' + shape.name + '</h3>');
                var shape_body = jQuery('<div class="vltTDT-patternBar-pattern"></div>');
                var shape_preview = jQuery('<div class="shape"></div>');
                if (shape.preview.length > 0)
                    shape_preview.css("background-image", "url(" + shape_preview_url + shape.preview + ")");
                else
                    shape_preview.html(shape.name);
                shape_body.append(shape_preview);
                shape_group.append(shape_name);
                shape_group.append(shape_body);
                jQuery("#pattern-list").append(shape_group);
            } 
        }
    });    
}

function setBackground() {
    jQuery("#gridPattern").attr('patternTransform', 'translate(' + 50 + ',' + 50 + ')');
    jQuery("#crosshairs").attr('transform', 'translate(' + 350 + ',' + 350 + ')');
}

function editDimension() {
    var val = parseFloat(dimensionEditor.find("#radius").val());
    if (isNaN(val)) return {
        status: false,
        msg: 'Invalid Number Type.'
    };
    if (units == 'cm') val = parseFloat(val) * 10;
    var model = null;
    var selectedKey = null;
    var retVal = {
        status: true,
        msg: ''
    }
    Object.keys(foilModels.models).forEach(key => {
        if (foilModels.models[key].selected) {
            selectedKey = key;
            model = JSON.parse(JSON.stringify(foilModels.models[key]));
        }
    });
    
    if (model) {
        var rIndex = parseInt(dimensionEditor.rIndex);
        if (val == 0) {
            if (model.myKey !== 'r_rect') {
                return {
                    msg: `This dimention can not be 0!`,
                    status: false
                };
            } else if (rIndex < 2) {
                return {
                    msg: `This dimention can not be 0!`,
                    status: false
                };
            }
        }
        var myKey = model.myKey;
        if (val > Math.max(Number(dimentsionLimits.max_w[model.myKey]), Number(dimentsionLimits.max_h[model.myKey]))) {
            return {
                msg: `This shape can have ${dimentsionLimits.max_w[model.myKey]}mm x ${dimentsionLimits.max_h[model.myKey]}mm as maximize size!`,
                status: false
            };            
        }        
        if (model.myKey == "triangle") {
            model.radius[0] = Math.floor(parseFloat(val) / Math.sqrt(3) / 2);
            model.orgRadius = parseFloat(val);            
        }
        else if (["rect", "r_rect", "oval", "oval1", "oval2", "bootsform", "bootsform_a"].indexOf(model.myKey) >= 0) {
            var radius = parseFloat(val);
            var temp = model.radius[parseInt(dimensionEditor.rIndex)];
            if (model.myKey == "oval1") radius = 2 * radius;
            model.radius[parseInt(dimensionEditor.rIndex)] = radius;

            if (model.myKey == "r_rect") {
                if (rIndex > 1 && (model.radius[0] / 2 < radius || model.radius[1] / 2 < radius)) {
                    model.radius[parseInt(dimensionEditor.rIndex)] = temp;
                    retVal = {
                        status: false,
                        msg: 'The Radius can not be greater than width or height!'
                    }
                } else if (rIndex < 2 && radius < Math.max(model.radius[2], model.radius[3], model.radius[4], model.radius[5])) {
                    model.radius[rIndex] = temp;
                    retVal = {
                        status: false,
                        msg: 'The Width or Height can not be less than radius!'
                    }
                }
            } else if (model.myKey == "bootsform") {
                if (model.radius[1] >= model.radius[2]) {
                    model.radius[parseInt(dimensionEditor.rIndex)] = temp;
                    retVal = {
                        status: false,
                        msg: rIndex < 2? `The value can not be greater than ${model.radius[2]}mm!`: `The value can not be less than ${model.radius[1]}mm!`
                    }
                }
            } else if (model.myKey == "bootsform_a") {
                if ((rIndex ==1 || rIndex == 2) && model.radius[1] >= model.radius[2]) {
                    model.radius[parseInt(dimensionEditor.rIndex)] = temp;
                    retVal = {
                        status: false,
                        msg: `The value can not be greater than ${model.radius[2]}mm!`
                    }
                    if (rIndex == 2)
                        retVal.msg = `The value can not be less than ${model.radius[1]}mm!`;
                } else if ( (rIndex ==0 || rIndex == 3) && model.radius[0] >= model.radius[3] ) {
                    model.radius[parseInt(dimensionEditor.rIndex)] = temp;
                    retVal = {
                        status: false,
                        msg: `The value can not be greater than ${model.radius[3]}mm!`
                    }
                    if (rIndex == 3) 
                        retVal.msg = `The value can not be less than ${model.radius[0]}mm!`;
                }
            }
        } else if (model.myKey == "hexagon") {
            var radius = parseFloat(val) / 2;
            radius = radius / Math.sin(Math.PI / 8);
            model.radius[0] = Math.round(radius * 100) / 100;
        } else if (model.myKey == "pentagon" || model.myKey == "circle") {
            if (val/2 > Math.min(Number(dimentsionLimits.max_w[model.myKey]), Number(dimentsionLimits.max_h[model.myKey]))) {
                return {
                    msg: `This shape can have ${dimentsionLimits.max_w[model.myKey]}mm x ${dimentsionLimits.max_h[model.myKey]}mm as maximize size!`,
                    status: false
                };            
            }
            model.radius[0] = parseFloat(val);
            model.radius[1] = parseFloat(val);
        } else if (model.myKey == 'draw') {
            if (dimensionEditor.angleFlag) {
                var fPoint = model.sPoints[rIndex];
                var lPoint = model.sPoints[rIndex + 1];
                var nPoint = model.sPoints[rIndex + 2];
                if (rIndex >= model.sPoints.length - 1) {
                    lPoint = model.sPoints[0];
                }
                if (rIndex + 2 > model.sPoints.length - 1) {
                    nPoint = model.sPoints[rIndex + 2 - model.sPoints.length];
                }
                var newPoint = makerjs.point.add(lPoint, [makerjs.measure.pointDistance(fPoint, lPoint), 0]);
                var angle = makerjs.angle.ofPointInDegrees(lPoint, nPoint);
                var mPoint = makerjs.point.rotate(newPoint, angle - val, lPoint);
                model.sPoints[rIndex] = mPoint;                
            } else {
                var fPoint = model.sPoints[rIndex - 1];
                var lPoint = model.sPoints[rIndex];
                if (rIndex >= model.sPoints.length)
                    lPoint = model.sPoints[0];
                var angle = makerjs.angle.ofPointInDegrees(fPoint, lPoint);
                var nPoint = makerjs.point.add(fPoint, [val, 0]);
                nPoint = makerjs.point.rotate(nPoint, angle, fPoint);
                if (rIndex >= model.sPoints.length) {
                    model.sPoints[0] = nPoint;
                } else {
                    model.sPoints[rIndex] = nPoint;
                }
            }
        }
        model = reRenderModels(model);
        if (model) {
            foilModels.models[selectedKey] = model;            
            MakerJsPlayground.renderWithModels(foilModels);
            // MakerJsPlayground.fitOnScreen();
            addHistory();

            var key = Object.keys(foilModels.models).find(key => (foilModels.models[key].selected));
            if (key) {
                var area = MakerJsPlayground.calculateAreaPerShape(key);
                calculateArea(area, foilModels.models[key].myKey);
            }
        } else {
            return {
                msg: `This shape can have ${dimentsionLimits.max_w[myKey]}mm x ${dimentsionLimits.max_h[myKey]}mm as maximize size!`,
                status: false
            }
        }
        return retVal;
    }    
}

function editText() {    
    var fontSize = textEditor.find("#fontSize").val();
    var model = null;
    var selectedKey = null;
    var flag = false;
    Object.keys(foilModels.models).forEach(key => {
        if (foilModels.models[key].selected) {
            selectedKey = key;
            model = foilModels.models[key];
        }
    });
    if (model) {
        model.fontSize = fontSize;
        model.text = textEditor.find("#text").val();
        if (model.text.length <= 0) return true;
        if (fontSize < 10 || fontSize > 100) return true;
        model = reRenderModels(model);
        foilModels.models[selectedKey] = model;
        addHistory();
        MakerJsPlayground.renderWithModels(foilModels);
    }
    return flag;
}

function addHistory() {
    foilHistorys.push(JSON.parse(JSON.stringify(foilModels)));
    if (foilHistorys.length > 10) foilHistorys =foilHistorys.slice(-10);
    historyIndex = foilHistorys.length - 1;
    jQuery(".shape-action  button[action='redo']").attr("disabled", true);
    jQuery(".shape-action  button[action='undo']").attr("disabled", false);
    MakerJsPlayground.calculateAreaTotal()
	.then(function(totalPrice, area) {
        jQuery('#TF-other .total .value').html(totalPrice.toFixed(2));
        jQuery('#TF-other .area .value').html(area);
        var tmodels = JSON.parse(JSON.stringify(foilModels));
        delete tmodels.paths;
        var aModels = {};
        var keys = [];
        Object.keys(tmodels.models).forEach(key => {
            if (key != 'background') {
                var model = tmodels.models[key];
                model.layer = "VCUT";
                aModels[key] = model;
                keys.push(model.myKey);
            }
        });
        tmodels.models = aModels;
        var dxfString = makerjs.exporter.toDXF(tmodels, {units: foilModels.units});
        jQuery("#cfwc-title-field").val(JSON.stringify(tmodels) + "&&" + totalPrice.toFixed(2) + '&&' + keys.join(','));
    });
}