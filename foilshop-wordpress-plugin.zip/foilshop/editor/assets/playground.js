var MakerJsPlayground;
(function (MakerJsPlayground) {
    //classes
    var QueryStringParams = /** @class */ (function () {
        function QueryStringParams(querystring) {
            if (querystring === void 0) { querystring = document.location.search.substring(1); }
            if (querystring) {
                var pairs = querystring.split('&');
                for (var i = 0; i < pairs.length; i++) {
                    var pair = pairs[i].split('=');
                    this[pair[0]] = decodeURIComponent(pair[1]);
                }
            }
        }
        return QueryStringParams;
    }());
    //private members
    var minDockSideBySide = 1024;
    var pixelsPerInch = 100;
    var view;
    var viewSvgContainer;
    var gridPattern;
    var crosshairs;
    var gridPatternFill;
    var paramsDiv;
    var measurementDiv;
    var margin;
    var processed = {
        error: '',
        html: '',
        kit: null,
        model: null,
        measurement: null,
        paramValues: []
    };
    var init = true;
    var errorMarker;
    var exportWorker = null;
    var paramActiveTimeout;
    var longHoldTimeout;
    var viewModelRootSelector = 'svg#drawing > g > g';
    var viewOrigin;
    var viewPanOffset = [10, 20];
    var keepEventElement = null;
    var renderInWorker = {
        requestId: 0,
        worker: null,
        hasKit: false
    };
    var setParamTimeoutId;
    var setProcessedModelTimer;
    var animationTimeoutId;
    var dockModes = {
        None: '',
        SideBySide: 'side-by-side',
        FullScreen: 'full-screen'
    };
    function isHttp(url) {
        return "http" === url.substr(0, 4);
    }
    function isIJavaScriptErrorDetails(result) {
        if (!result)
            return false;
        var sample = {
            colno: 0,
            lineno: 0,
            message: '',
            name: ''
        };
        for (var key in sample) {
            if (!(key in result)) {
                return false;
            }
        }
        return true;
    }
    var Frown = /** @class */ (function () {
        function Frown() {
            this.paths = {
                head: new makerjs.paths.Circle([0, 0], 85),
                eye1: new makerjs.paths.Circle([-25, 25], 10),
                eye2: new makerjs.paths.Circle([25, 25], 10),
                frown: new makerjs.paths.Arc([0, -75], 50, 45, 135)
            };
        }
        return Frown;
    }());
    var StraightFace = /** @class */ (function () {
        function StraightFace() {
            this.paths = {
                head: new makerjs.paths.Circle([0, 0], 85),
                eye1: new makerjs.paths.Circle([-25, 25], 10),
                eye2: new makerjs.paths.Circle([25, 25], 10),
                mouth: new makerjs.paths.Line([-30, -30], [30, -30])
            };
        }
        return StraightFace;
    }());
    var Wait = /** @class */ (function () {
        function Wait() {
            var wireFrame = {
                paths: {
                    rim: new makerjs.paths.Circle([0, 0], 85),
                    hand1: new makerjs.paths.Line([0, 0], [40, 30]),
                    hand2: new makerjs.paths.Line([0, 0], [0, 60])
                }
            };
            this.models = {
                x: makerjs.model.expandPaths(wireFrame, 5)
            };
        }
        return Wait;
    }());
    var Warning = /** @class */ (function () {
        function Warning() {
            this.models = {
                triangle: new makerjs.models.ConnectTheDots(true, [[-200, 0], [200, 0], [0, 346]]),
                exclamation: new makerjs.models.ConnectTheDots(true, [[-10, 110], [10, 110], [16, 210], [-16, 210]])
            };
            this.paths = {
                point: new makerjs.paths.Circle([0, 75], 16)
            };
        }
        return Warning;
    }());
    function getModelNaturalSize() {
        var measure = processed.measurement;
        var modelWidthNatural = measure.high[0] - measure.low[0];
        var modelHeightNatural = measure.high[1] - measure.low[1];
        return [modelWidthNatural, modelHeightNatural];
    }
    function getViewSize() {
        var viewHeight = view.offsetHeight - 2 * margin[1];
        var viewWidth = view.offsetWidth - 2 * margin[0];
        var width = viewWidth - 20;        
        return [width, viewHeight];
    }
    function initialize() {
        window.addEventListener('resize', onWindowResize);
        window.addEventListener('orientationchange', onWindowResize);
        MakerJsPlayground.pointers = new Pointer.Manager(view, '#pointers', margin, getZoom, setZoom, onPointerClick, onPointerReset);
        if (MakerJsPlayground.onInit) {
            MakerJsPlayground.onInit();
        }
    }
    function onPointerClick(srcElement) {
        if (!keepEventElement && srcElement && srcElement.tagName && srcElement.tagName == 'text') {
            var text = srcElement;
            var path = text.previousSibling;            
        }
    }
    function onPointerReset() {
        if (keepEventElement) {
            view.removeChild(keepEventElement);
        }
        keepEventElement = null;
    }
    function getZoom() {
        return {
            origin: viewOrigin,
            pan: viewPanOffset,
            zoom: MakerJsPlayground.viewScale
        };
    }
    MakerJsPlayground.getZoom = getZoom;
    function setZoom(panZoom) {
        if (document.body.classList.contains('wait'))
            return;
        var svgElement = viewSvgContainer.children[0];
        if (!svgElement)
            return;
        // checkFitToScreen.checked = false;
        viewPanOffset = panZoom.pan;
        console.log(panZoom.zoom);
        if (panZoom.zoom == MakerJsPlayground.viewScale) {
            //just pan
            //no need to re-render, just move the margin
            svgElement.style.left = viewPanOffset[0] + 'px';
            svgElement.style.top = viewPanOffset[1] + 'px';
            panGrid();
        }
        else {
            //zoom and pan
            if (!keepEventElement) {
                keepEventElement = svgElement;
                viewSvgContainer.removeChild(keepEventElement);
                keepEventElement.style.visibility = 'hidden';
                this.view.appendChild(keepEventElement);
            }
            MakerJsPlayground.viewScale = panZoom.zoom;
            render();
        }
    }
    MakerJsPlayground.setZoom = setZoom;
    function getGridScale() {
        var gridScale = 1;
        while (MakerJsPlayground.viewScale * gridScale < 6) {
            gridScale *= 10;
        }
        while (MakerJsPlayground.viewScale * gridScale > 60) {
            gridScale /= 10;
        }
        return gridScale;
    }
    function zoomGrid() {
        var gridScale = (getGridScale() * 10 * MakerJsPlayground.viewScale).toString();
        gridPattern.setAttribute('width', gridScale);
        gridPattern.setAttribute('height', gridScale);
        gridPatternFill.setAttribute('width', gridScale);
        gridPatternFill.setAttribute('height', gridScale);
        
        renderSelectors();
        renderDimensions();
    }
    function panGrid() {
        var p = makerjs.point.add(viewPanOffset, viewOrigin);
        var op = makerjs.point.add(p, margin);
        gridPattern.setAttribute('patternTransform', 'translate(' + p[0] + ',' + p[1] + ')');
        // crosshairs.setAttribute('transform', 'translate(' + op[0] + ',' + op[1] + ')');
        // $(".sel-point").css('transform', 'translate(' + op[0] + 'px,' + op[1] + 'px)');
        renderSelectors();
        renderDimensions();
    }
    function getUnits() {
        if (processed.model && processed.model.units) {
            return processed.model.units;
        }
        return null;
    }
    function setProcessedModel(model, error) {
        clearTimeout(setProcessedModelTimer);
        var oldUnits = getUnits();
        var oldMeasurement = processed.measurement;
        processed.model = model;
        processed.measurement = null;
        processed.error = error;
        var newUnits = getUnits();
        if (!error) {
            if (errorMarker) {
                errorMarker.clear();
                errorMarker = null;
            }
        }
        if (!processed.model)
            return;
        //now safe to render, so register a resize listener
        if (init && model) {
            init = false;
            initialize();
        }
        //todo: find minimum viewScale
        if (!makerjs.isPoint(processed.model.origin))
            processed.model.origin = [0, 0];
        var newMeasurement = makerjs.measure.modelExtents(processed.model);
        // makerjs.model.getAllCaptionsOffset(processed.model).forEach(function (caption) {
        //     makerjs.measure.increase(newMeasurement, makerjs.measure.pathExtents(caption.anchor), true);
        // });
        processed.measurement = newMeasurement;
        if (!processed.measurement) {
            setProcessedModelTimer = setTimeout(function () {
                setProcessedModel(new StraightFace(), 'Your model code was processed, but it resulted in a model with no measurement. It probably does not have any paths. Here is the JSON representation: \n\n' + mdCode(processed.model));
            }, 2500);
            return;
        }
        if (!customDrawing)
            fitOnScreen();
        var oKeys = Object.keys(foilModels.models);
        if (oKeys.length == 2 && oKeys.indexOf('background') >= 0) {
            fitOnScreen();
        }
        document.body.classList.remove('wait');
        if (newUnits)
            document.body.classList.add('has-units');
        else {
            document.body.classList.remove('has-units');
        }
        render();
        var measureText;
        if (processed.error) {
            //sync notes and checkbox            
            document.body.classList.remove('collapse-notes');
            measureText = '';
        }
        else {
            var size = getModelNaturalSize();
            measureText = size[0].toFixed(2) + ' x ' + size[1].toFixed(2) + ' ' + (newUnits || 'units');            
        }
        if (measurementDiv) {
            measurementDiv.innerText = measureText;
        }
        if (MakerJsPlayground.onViewportChange) {
            MakerJsPlayground.onViewportChange();
        }
    }
    MakerJsPlayground.setProcessedModel = setProcessedModel;
    MakerJsPlayground.codeMirrorOptions = {
        extraKeys: {
            "Ctrl-Enter": function () { runCodeFromEditor(); },
            "Ctrl-I": function () { toggleClass('collapse-insert-menu'); }
        },
        lineNumbers: true,
        gutters: ["CodeMirror-lint-markers"],
        lint: true,
        theme: 'twilight',
        viewportMargin: Infinity
    };
    MakerJsPlayground.relativePath = '';
    MakerJsPlayground.svgStrokeWidth = 2;
    MakerJsPlayground.svgFontSize = 14;
    MakerJsPlayground.useWorkerThreads = true;
    function fitOnScreen() {
        if (MakerJsPlayground.pointers)
            MakerJsPlayground.pointers.reset();
        if (!processed.measurement)
            return;
        var size = getViewSize();
        var halfWidth = size[0] / 2;
        var modelNaturalSize = getModelNaturalSize();
        MakerJsPlayground.viewScale = 1;
        viewPanOffset = [10, 20];
        // checkFitToScreen.checked = true;
        var scaleHeight = (size[1] - 20) / modelNaturalSize[1];
        var scaleWidth = (size[0] - 20) / modelNaturalSize[0];
        MakerJsPlayground.viewScale *= Math.min(scaleWidth, scaleHeight);
        halfWidth -= (modelNaturalSize[0] / 2 + processed.measurement.low[0]) * MakerJsPlayground.viewScale;
        viewOrigin = [halfWidth, processed.measurement.high[1] * MakerJsPlayground.viewScale];        
    }
    MakerJsPlayground.fitOnScreen = fitOnScreen;
    function browserIsMicrosoft() {
        var clues = ['Edge/', 'Trident/'];
        for (var i = 0; i < clues.length; i++) {
            if (navigator.userAgent.indexOf(clues[i]) > 0) {
                return true;
            }
        }
        return false;
    }
    MakerJsPlayground.browserIsMicrosoft = browserIsMicrosoft;
    function render() {
        viewSvgContainer.innerHTML = '';
        var html = '';
        var strokeWidth = MakerJsPlayground.svgStrokeWidth;
        if (processed.model) {
            var fontSize = MakerJsPlayground.svgFontSize;
            var renderOptions = {
                origin: viewOrigin,
                // annotate: true,
                // flow: { size: 8 },
                svgAttrs: {
                    "id": 'drawing',
                    "style": 'left:' + viewPanOffset[0] + 'px; top:' + viewPanOffset[1] + 'px'
                },
                layerOptions: {
                    background: {
                        strokeWidth: '0px',
                        // fill: 'rgb(0,0,255)'
                    }                    
                },
                strokeWidth: strokeWidth + 'px',
                fill: 'rgb(100, 100, 100)',
                fontSize: fontSize + 'px',
                scale: MakerJsPlayground.viewScale,
                useSvgPathOnly: false
            };
            panGrid();
            zoomGrid();
            //do not use actual units when rendering
            var units = processed.model.units;
            delete processed.model.units;
            html += makerjs.exporter.toSVG(processed.model, renderOptions);
            if (units)
                processed.model.units = units;
        }
        viewSvgContainer.innerHTML = html;
        $(viewSvgContainer).find('svg').css('position', 'absolute');
        if (processed.lockedPath) {
            var path = getLockedPathSvgElement();
            if (path) {
                path.setAttribute('class', 'locked');
                path.style.strokeWidth = (2 * strokeWidth) + 'px';
            }
        }

        
    }
    MakerJsPlayground.render = render;
    MakerJsPlayground.renderWithModels = function(model, flag = false) {
        jQuery(".selector").remove();
        jQuery("#TF-other .base-price .value").html('0');
        jQuery("#TF-other .shape-price .value").html('0');
        jQuery('#TF-other .area .value').html('0');
        
        renderSelectors(flag);
        $(".dimension-number").remove();
        $(".dimension-angle").remove();
        jQuery(".measure-number").remove();
        var p = makerjs.point;
        var paths = model.paths && model.paths["measure"];
        model.paths = {};
        if (paths) {
            model.paths["measure"] = paths;
            var dim = makerjs.measure.pointDistance(paths.points[0].fromDrawingOrigin, paths.points[1].fromDrawingOrigin);
            dim = Math.round(dim * 100)/100;

            var dimPoint = p.average(paths.points[0].fromCanvas, paths.points[1].fromCanvas);
            dimPoint = p.add(dimPoint, [10 , 10]);
            var rPoint = p.average(paths.points[0].fromDrawingOrigin, paths.points[1].fromDrawingOrigin);
            if (units == 'cm') dim = dim/10;
            var dDiv = document.createElement("div");
            $(dDiv).addClass("measure-number");
            $(dDiv).css("top", dimPoint[1]);
            $(dDiv).css("left", dimPoint[0]);
            $(dDiv).html(Number(dim).toFixed(2));
            $(dDiv).attr("point", JSON.stringify(rPoint));
            $("#view-params").append(dDiv);
        }
        /**
         * render dimensions
         */
        var keys = Object.keys(model.models);
        var tAreaFlag = true;
        var tArea = 0;
        keys.forEach(key => {
            if (key != "background") {
                if (model.models[key].selected) {
                    model.paths = getDimensions(model.models[key]);
                }                
                var area = calculateAreaPerShape(key);
                tArea += parseFloat(area.value);
                tAreaFlag = tAreaFlag && !model.models[key].selected;
            }
        });
        if (tAreaFlag) {
            jQuery('#TF-other .area .value').html(Number(tArea).toFixed(2));
        }
        processed.model = model;
        render();        
    };

    function renderSelectors(flag) {
        // calculateArea();
        $('.selector').remove();
        $('.text-selector').remove();
        var keys = Object.keys(foilModels.models);
        keys.forEach(key => {
            if (key != "background") {
                var model = foilModels.models[key];
                if (!model.showFlag) return;
                var sPoints = [];
                sPoints.push(model.origin? model.origin: [0, 0]);
                sPoints[0] = [sPoints[0][0], -sPoints[0][1]];   
                // console.log(model.origin);
                if (model.myKey == "circle") {
                    var point = makerjs.point.add([model.origin[0], -model.origin[1]], [model.radius[0], 0]);
                    sPoints.push(point);
                } else if (model.myKey == "hexagon") {
                    for(var alpa = 22.5; alpa < 360; alpa = alpa + 45) {
                        var point = makerjs.point.rotate([model.radius[0], 0], alpa, [0, 0]);
                        point = makerjs.point.add(point, [model.origin[0], -model.origin[1]]);
                        sPoints.push(point);
                    }
                } else if (model.myKey == "oval") {
                    sPoints = sPoints.concat([
                        makerjs.point.add([model.origin[0], -model.origin[1]], [model.radius[0], 0]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [0, -model.radius[1]]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [-model.radius[0], 0]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [0, model.radius[1]]),
                    ]);
                } else if (model.myKey == "pentagon") {
                    for(var alpa = 0; alpa < 360; alpa = alpa + 60) {
                        var point = makerjs.point.rotate([model.radius[0], 0], alpa, [0, 0]);
                        point = makerjs.point.add(point, [model.origin[0], -model.origin[1]]);
                        sPoints.push(point);
                    }
                } else if (model.myKey == "rect") {
                    var point = makerjs.point.add(model.origin, [model.radius[0]/2, model.radius[1]/2]);
                    sPoints[0] = point;
                    sPoints[0] = [sPoints[0][0], -sPoints[0][1]];   
                    sPoints = sPoints.concat([
                        makerjs.point.add(sPoints[0], [-model.radius[0]/2, -model.radius[1]/2]),
                        makerjs.point.add(sPoints[0], [-model.radius[0]/2, model.radius[1]/2]),
                        makerjs.point.add(sPoints[0], [model.radius[0]/2, model.radius[1]/2]),
                        makerjs.point.add(sPoints[0], [model.radius[0]/2, -model.radius[1]/2])
                    ]);
                } else if (model.myKey == 'r_rect') {
                    var point = model.origin;
                    sPoints[0] = point;
                    sPoints[0] = [sPoints[0][0], -sPoints[0][1]];
                    sPoints = sPoints.concat([
                        makerjs.point.add(sPoints[0], [model.radius[0]/2, 0]),
                        makerjs.point.add(sPoints[0], [0, model.radius[1]/2]),
                        makerjs.point.add(sPoints[0], [-model.radius[0]/2, 0]),
                        makerjs.point.add(sPoints[0], [0, -model.radius[1]/2]),
                    ]);
                } else if (model.myKey == "oval1") {
                    var point = makerjs.point.add(model.origin, [model.radius[0]/2, model.radius[1]/2]);
                    sPoints[0] = point;
                    sPoints[0] = [sPoints[0][0], -sPoints[0][1]];
                    sPoints = sPoints.concat([
                        makerjs.point.add(sPoints[0], [model.radius[0]/2, 0]),
                        makerjs.point.add(sPoints[0], [0, model.radius[1]/2]),
                        makerjs.point.add(sPoints[0], [-model.radius[0]/2, 0]),
                        makerjs.point.add(sPoints[0], [0, -model.radius[1]/2]),
                    ]);
                } else if (model.myKey == "triangle") {
                    for(var alpa = 30; alpa < 360; alpa = alpa + 120) {
                        var point = makerjs.point.rotate([model.radius[0], 0], alpa, [0, 0]);
                        point = makerjs.point.add(point, [model.origin[0], -model.origin[1]]);
                        sPoints.push(point);
                    }                    
                } else if (model.myKey == "bootsform") {
                    sPoints = sPoints.concat([
                        makerjs.point.add([model.origin[0], -model.origin[1]], [model.radius[0]/2, model.radius[1]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [0, model.radius[2]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [-model.radius[0]/2, model.radius[1]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [-model.radius[0]/2, -model.radius[1]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [0, -model.radius[2]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [model.radius[0]/2, -model.radius[1]/2]),
                    ]);
                } else if (model.myKey == "bootsform_a") {
                    sPoints = sPoints.concat([
                        makerjs.point.add([model.origin[0], -model.origin[1]], [model.radius[0]/2, model.radius[1]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [0, model.radius[2]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [-model.radius[0]/2, model.radius[1]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [-model.radius[0]/2, -model.radius[1]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [0, -model.radius[2]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [model.radius[0]/2, -model.radius[1]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [-model.radius[3]/2, 0]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [model.radius[3]/2, 0]),
                    ]);                    
                } else if (model.myKey == "oval2") {
                    sPoints = sPoints.concat([
                        makerjs.point.add([model.origin[0], -model.origin[1]], [model.radius[0]/2, 0]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [model.radius[2]/2, model.radius[1]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [-model.radius[2]/2, model.radius[1]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [-model.radius[0]/2, 0]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [model.radius[2]/2, -model.radius[1]/2]),
                        makerjs.point.add([model.origin[0], -model.origin[1]], [-model.radius[2]/2, -model.radius[1]/2]),
                    ]);
                } else if (model.myKey == "draw") {
                    sPoints = model.sPoints || [];
                } else if (model.myKey == 'text') {
                    var rectofArea = makerjs.measure.modelExtents(model);
                    sPoints.push([rectofArea.center[0], -rectofArea.center[1]]);
                }
                if (flag) {
                    console.log(sPoints);
                }
                model.sPoints = sPoints;
                foilModels.models[key] = model;
                for(var i = 0; i < sPoints.length; i++) {
                    var mm = MakerJsPlayground.pointers.getViewPoints(sPoints[i]);
                    var selector = null;
                    var sel = `${key}_${i}`;
                    var flag = $.contains($("#TF-drawing")[0], $("." + sel)[0]);
                    
                    if (flag) {
                        selector = $("#TF-drawing ." + sel);
                    } else {
                        selector = $("#selector").clone();
                        selector.removeAttr("id");
                        selector.attr('key', key).attr('p-index', i);
                        selector.addClass(sel).addClass(key + "_");
                        selector.css("visibility", "visible");
                        if (model.myKey == 'text' && i > 0) {
                            selector.addClass("text-selector");
                        } else {
                            selector.addClass("selector");
                        }
                    }
                    // var cPoint = makerjs.point.scale(sPoints[i], MakerJsPlayground.viewScale);
                    selector.css('top', mm[1]);
                    selector.css('left', mm[0]);
                    selector.css("backgroundColor", model.selected? "fuchsia" : "black");
                    if (!flag)
                        $("#selector").parent().append(selector);                    
                }
            }
        });
        $('.selector').on('pointerdown', function(e) {
            e.preventDefault();
            var key = $(e.target).attr('key');
            var pIndex = $(e.target).attr("p-index");
            var model = foilModels.models[key];
            var rIndex = 0;
            if (model.myKey == "oval") {
                rIndex = [0, 0, 1, 0, 1][parseInt(pIndex)];                                
            } else if (model.myKey == "rect" || model.myKey == "r_rect" || model.myKey == "oval1") {
                rIndex = [0, 0, 1, 0, 1][parseInt(pIndex)];
            }
            
            MakerJsPlayground.pointers.selected = true;
            MakerJsPlayground.pointers.selectedModel = {
                key: key,
                model: model,
                rIndex: rIndex,
                pIndex: parseInt(pIndex)
            };
            MakerJsPlayground.pointers.viewPointerDown(e);
            model.selected = true;
            model.layer = "orange";
            MakerJsPlayground.renderWithModels(foilModels);
            return true;
        });

        $('.selector').on('pointerup', function(e) {
            MakerJsPlayground.pointers.viewPointerUp(e);
            var key = Object.keys(foilModels.models).find(key => (foilModels.models[key].selected));
            if (key) {
                var area = calculateAreaPerShape(key);
                calculateArea(area, foilModels.models[key].myKey);
            }            
        });

        $('.text-selector').on('dblclick', function(e) {
            // MakerJsPlayground.pointers.editText(e);
            if (!customDrawing && !measureStatus) {
                var models = foilModels.models;
                var keys = Object.keys(models);
                for(var i = keys.length - 1; i >= 0; i--) {
                    if (keys[i] != 'background') {
                        var model = models[keys[i]];
                        if (model.myKey == 'text') {
                            // if (makerjs.measure.isPointEqual(pointRelative.fromDrawingOrigin, model.origin, 5)) {
                                model.selected = true;
                                model.selected = true;
                                model.layer = "orange";                                
                                textEditor.find('#fontSize').val(model.fontSize);
                                textEditor.find('#text').val(model.text);
                                textEditor.dialog("open");
                                MakerJsPlayground.renderWithModels(foilModels);
                                break;
                            // }
                        }
                    }
                }
            }
        });        
    }

    function renderDimensions() {
        var objs = $(".dimension-number");
        var p = makerjs.point;
        for(var i = 0; i < objs.length; i++) {
            var obj = objs[i];
            var pp = JSON.parse($(obj).attr("point"));
            var fromView = p.add(p.add(viewOrigin, viewPanOffset), p.scale(pp, MakerJsPlayground.viewScale));
            $(obj).css("top", fromView[1] - 20);
            $(obj).css("left", fromView[0]);
        }

        var angs = $(".dimension-angle");
        for(var i = 0; i < angs.length; i++) {
            var obj = angs[i];
            var pp = JSON.parse($(obj).attr("point"));
            var fromView = p.add(p.add(viewOrigin, viewPanOffset), p.scale(pp, MakerJsPlayground.viewScale));
            $(obj).css("top", fromView[1]);
            $(obj).css("left", fromView[0]);
        }

        if (!measureStatus) {
            objs = jQuery(".measure-number");
            for(var i = 0; i < objs.length; i++) {
                var obj = objs[i];
                var pp = JSON.parse($(obj).attr("point"));
                var fromView = p.add(p.add(viewOrigin, viewPanOffset), p.scale(pp, MakerJsPlayground.viewScale));
                $(obj).css("top", fromView[1]);
                $(obj).css("left", fromView[0]);
            }
        }
    }

    /**
     * getting dimensions of each model
     * @param {obj} model 
     */
    function getDimensions(model) {
        var paths = {};
        if (["triangle", "hexagon", "pentagon"].indexOf(model.myKey) >= 0) {
            var point1 = model.sPoints[1];
            var point2 = model.sPoints[2];
            if (model.myKey == "rect") {
                point1 = model.sPoints[3];
            } else if (model.myKey == "hexagon" || model.myKey == "pentagon") {
                point1 = model.sPoints[2];
                point2 = model.sPoints[3];
            }
            paths = drawDimension(0, point1, point2, [0, 20]);
            if (model.myKey == 'triangle' && model.orgRadius) {
                $(".dimension-number").html(Number(model.orgRadius).toFixed(2) + ' ' + units);
            }
        } else if (model.myKey == "rect") {
            paths = drawDimension(0, model.sPoints[3], model.sPoints[2], [0, 20]);
            paths = Object.assign(paths, drawDimension(1, model.sPoints[3], model.sPoints[4], [20, 0], true));
        } else if (model.myKey == "r_rect") {
            var offset = [0, 30];
            var vOffset = [-30, 0];
            // if (model.radius[1]/2 - model.radius[2] < 30) {
            //     offset = makerjs.point.add([0, 20], [0, model.radius[1]/2]);
            // }
            // if (model.radius[0]/2 - model.radius[2] < 30) {
            //     var offsetX = Math.abs(model.sPoints[2][0] - model.sPoints[3][0])/2
            //     vOffset = makerjs.point.add([20, 0], [offsetX, 0]);
            // }
            paths = drawDimension(0, model.sPoints[1], model.sPoints[3], offset);
            var vPaths = drawDimension(1, model.sPoints[2], model.sPoints[4], vOffset, true);
            paths = Object.assign(paths, vPaths);
            var rPoint = makerjs.point.add(model.sPoints[0], [-model.radius[0]/2 + model.radius[2], -model.radius[1]/2 + model.radius[2]]);
            var rPaths = drawRDimension(2, rPoint, model.radius[2], 225);
            paths = Object.assign(paths, rPaths);
            var trPoint = makerjs.point.add(model.sPoints[0], [model.radius[0]/2 - model.radius[3], -model.radius[1]/2 + model.radius[3]]);
            var trPaths = drawRDimension(3, trPoint, model.radius[3], -45, 'tr');
            paths = Object.assign(paths, trPaths);

            var brPoint = makerjs.point.add(model.sPoints[0], [model.radius[0]/2 - model.radius[4], model.radius[1]/2 - model.radius[4]]);
            var brPaths = drawRDimension(4, brPoint, model.radius[4], 45, 'br');
            paths = Object.assign(paths, brPaths);

            var blPoint = makerjs.point.add(model.sPoints[0], [-model.radius[0]/2 + model.radius[5], model.radius[1]/2 - model.radius[5]]);
            var blPaths = drawRDimension(5, blPoint, model.radius[5], 135, 'bl');
            paths = Object.assign(paths, blPaths);

        } else if (model.myKey == "circle" || model.myKey == "oval" || model.myKey == "oval1") {
            if (model.myKey == "oval1")
                paths = drawRDimension(0, model.sPoints[0], model.radius[0]/2, 0);
            else
                paths = drawRDimension(0, model.sPoints[0], model.radius[0], 0);

            if (model.myKey == "oval" || model.myKey == "oval1") {
                paths = Object.assign(paths, drawRDimension(1, model.sPoints[0], model.myKey == "oval"?model.radius[1]:model.radius[1]/2, 90, "rb"));
            }
        } else if (model.myKey == "oval2") {
            var offset = [0, 20];
            var vOffset = [-20, 0];
            offset = makerjs.point.add(offset, [0, model.radius[1]/2]);
            vOffset = makerjs.point.subtract(vOffset, [model.radius[0]/2, 0]);
            paths = drawRDimension(0, model.sPoints[0], model.radius[0]/2, 0, "ar", true);
            paths = Object.assign(paths, drawDimension(1, model.sPoints[2], model.sPoints[5], [-10, 0], true));
            paths = Object.assign(paths, drawDimension(2, model.sPoints[2], model.sPoints[3], [0, 20]));
        } else if (model.myKey == "bootsform") {
            var offset = [0, 18];
            var vOffset = [-18, 0];
            offset = makerjs.point.add(offset, [0, (model.radius[2] - model.radius[1])/2]);
            paths = drawDimension(0, model.sPoints[1], model.sPoints[3], offset);
            paths = Object.assign(paths, drawDimension(1, model.sPoints[1], model.sPoints[6], [18, 0], true));
            paths = Object.assign(paths, drawRDimension(2, model.sPoints[0], model.radius[2]/2, 90, "ra", true));
        } else if (model.myKey == "bootsform_a") {
            var offset = [0, 18];
            var vOffset = [-18, 0];
            // offset = makerjs.point.add(offset, [0, (model.radius[2] - model.radius[1])/2]);
            paths = drawDimension(0, model.sPoints[6], model.sPoints[4], [0, -20]);
            paths = Object.assign(paths, drawDimension(1, model.sPoints[3], model.sPoints[4], [-20, 0], true));
            paths = Object.assign(paths, drawRDimension(2, model.sPoints[0], model.radius[2]/2, 90, "rb", true));
            paths = Object.assign(paths, drawRDimension(3, model.sPoints[0], model.radius[3]/2, 0, "ra", true));
        } else if (model.myKey == 'draw') {
            for(var i = 1; i < model.sPoints.length; i++) {
                var prevP = model.sPoints[i-1];
                var currP = model.sPoints[i];
                var nextP = model.sPoints[0];
                if (i < model.sPoints.length - 1) nextP = model.sPoints[i + 1]
                var subP = makerjs.point.subtract(nextP, currP);
                var flag = subP[0] > 0;
                drawDimensionW(i, prevP, currP, 'db' + i, flag);
                paths = Object.assign(paths, drawAngle(i - 1, prevP, currP, nextP, 'ang_' + i));
            }
            drawDimensionW(i, model.sPoints[model.sPoints.length - 1], model.sPoints[0], 'db' + i, flag);
            paths = Object.assign(paths, drawAngle(i - 1, model.sPoints[model.sPoints.length - 1], model.sPoints[0], model.sPoints[1], 'ang_' + i));
        }
        Object.keys(paths).forEach(key => {
            paths[key].layer = "green";
        });
        addEditEvent();
        return paths;
    }

    function drawDimension(rIndex, point1, point2, offset, vertical = false, tkey = "") {
        var paths = {};
        var p = makerjs.point;
        var pa = makerjs.path;
        offset = makerjs.point.scale(offset, 1/MakerJsPlayground.viewScale);
        var xArrow = makerjs.point.scale([10, 0], 1/MakerJsPlayground.viewScale);
        var yArrow = makerjs.point.scale([0, 10], 1/MakerJsPlayground.viewScale);
        var offset1 = offset[1]>0? p.subtract(offset, yArrow): p.add(offset, yArrow);
        var key = "dh";
        if (vertical) {
            offset1 = offset[0] < 0? p.add(offset, xArrow): p.subtract(offset, xArrow);
            key = "dv";
        }
        if (tkey.length > 0) key = tkey;        

        paths[key + "1"] = new makerjs.paths.Line(point1, p.add(point1, offset));
        paths[key + "2"] = new makerjs.paths.Line(point2, p.add(point2, offset));
        paths[key + "3"] = new makerjs.paths.Line(p.add(point1, offset1), p.add(point2, offset1));
        // if (!vertical) {
            paths[key + "1"] = pa.mirror(paths[key + "1"], false, true);
            paths[key + "2"] = pa.mirror(paths[key + "2"], false, true);
            paths[key + "3"] = pa.mirror(paths[key + "3"], false, true);
        // }
        
        var int1 = pa.intersection(paths[key + "1"], paths[key + "3"]);
        if (int1) {
            paths[key + "4"] = pa.rotate(new makerjs.paths.Line(int1.intersectionPoints[0], p.add(int1.intersectionPoints[0], yArrow)), vertical? -45: 135, int1.intersectionPoints[0]);
            paths[key + "5"] = pa.rotate(new makerjs.paths.Line(int1.intersectionPoints[0], p.add(int1.intersectionPoints[0], yArrow)), 45, int1.intersectionPoints[0]);
        }
        var int2 = pa.intersection(paths[key + "2"], paths[key + "3"]);
        if (int2) {
            paths[key + "6"] = pa.rotate(new makerjs.paths.Line(int2.intersectionPoints[0], p.add(int2.intersectionPoints[0], yArrow)), -135, int2.intersectionPoints[0]);
            paths[key + "7"] = pa.rotate(new makerjs.paths.Line(int2.intersectionPoints[0], p.add(int2.intersectionPoints[0], yArrow)), vertical? 135: -45, int2.intersectionPoints[0]);
        }
        
        var dimPoint = p.average(int1.intersectionPoints[0], int2.intersectionPoints[0]);
        dimPoint = p.mirror(dimPoint, false, true);
        if (vertical) {
            dimPoint = offset[0] < 0 ? p.add(dimPoint, [-10 , -10]): p.add(dimPoint, [3, 5]);
        }
        else
            dimPoint = p.subtract(dimPoint, [5 , 10]);
        var fromView = p.add(p.add(viewOrigin, viewPanOffset), p.scale(dimPoint, MakerJsPlayground.viewScale));
        
        var dim = makerjs.measure.pointDistance(point1, point2);
        if (units == 'cm') dim = dim/10;
        dim = Math.round(dim * 100)/100;
        var dDiv = document.createElement("div");
        $(dDiv).addClass("dimension-number");
        $(dDiv).css("top", fromView[1]);
        $(dDiv).css("left", fromView[0]);
        $(dDiv).html(Number(dim).toFixed(2) + ' ' + units);
        $(dDiv).attr("point", JSON.stringify(dimPoint)).attr("rIndex", rIndex);
        $("#view-params").append(dDiv);
        return paths;
    }

    function drawDimensionW(rIndex, point1, point2) {
        var paths = {};
        var p = makerjs.point;
        var distance = makerjs.measure.pointDistance(point1, point2);
        point1 = p.mirror(point1, false, true);
        point2 = p.mirror(point2, false, true);
        
        var dimPoint = p.average(point1, point2);
        dimPoint = p.mirror(dimPoint, false, true);
        var fromView = p.add(p.add(viewOrigin, viewPanOffset), p.scale(dimPoint, MakerJsPlayground.viewScale));
        if (units == 'cm') distance = distance/10;
        var dim = Math.round(distance * 100)/100;
        var dDiv = document.createElement("div");
        $(dDiv).addClass("dimension-number");
        $(dDiv).css("top", fromView[1]-20);
        $(dDiv).css("left", fromView[0]);
        $(dDiv).html(Number(dim).toFixed(2) + ' ' + units);
        $(dDiv).attr("point", JSON.stringify(dimPoint)).attr("rIndex", rIndex);
        $("#view-params").append(dDiv);
        return paths;
    }

    function drawAngle(rIndex, prevP, curP, nextP, key) {
        var p = makerjs.point;
        var delta = p.subtract(curP, prevP);
        var deltaA = Math.atan2(-delta[1], delta[0]);
        var delta2 = p.subtract(nextP, curP);
        var deltaB = Math.atan2(-delta2[1], delta2[0]);
        var theta = 180 - Math.abs((deltaB - deltaA) * 180/ Math.PI);
        if (theta < 0) theta = Math.abs(theta);
        var paths = {};
        var oriP = p.mirror(curP, false, true);
        var db = deltaB * 180/ Math.PI;
        if (db < 0) db = 360 + db;
        paths[key] = new makerjs.paths.Arc(oriP, 10, db, db + theta);
        dimPoint = p.rotate(p.add(oriP, [8, 0]), db + theta/2, oriP);
        dimPoint = p.mirror(dimPoint, false, true);
        var fromView = p.add(p.add(viewOrigin, viewPanOffset), p.scale(dimPoint, MakerJsPlayground.viewScale));
        var dDiv = document.createElement("div");
        $(dDiv).addClass("dimension-angle");
        $(dDiv).css("top", fromView[1]);
        $(dDiv).css("left", fromView[0]);
        $(dDiv).html(Math.round(theta)+ ' &#176;');
        $(dDiv).attr("point", JSON.stringify(dimPoint)).attr("rIndex", rIndex);
        $("#view-params").append(dDiv);        
        return paths;
    }

    function drawRDimension(rIndex, point, radius, radial, key = "r", flag = false) {
        var paths = {};
        var p = makerjs.point;
        var pa = makerjs.path;
        var rPoint = p.add(point, [radius, 0]);
        var lPoint = flag? p.subtract(point, [radius, 0]): point;
        
        var xArrow = makerjs.point.scale([10, 10], 1/MakerJsPlayground.viewScale);
        var yArrow = makerjs.point.scale([10, 15], 1/MakerJsPlayground.viewScale);
        var x03 = makerjs.point.scale([0, 10], 1/MakerJsPlayground.viewScale);
        var dPoint = p.subtract(p.average(lPoint, rPoint), key == "rb"? xArrow : yArrow);
        if (flag) dPoint = p.subtract(point, key == "rb"? makerjs.point.scale([-15, 10], 1/MakerJsPlayground.viewScale) : makerjs.point.scale([25, 10], 1/MakerJsPlayground.viewScale));
        paths[key + "1"] = new makerjs.paths.Line(lPoint, rPoint);
        paths[key + "2"] = pa.rotate(new makerjs.paths.Line(rPoint, p.add(rPoint, x03)), 135, rPoint);
        paths[key + "3"] = pa.rotate(new makerjs.paths.Line(rPoint, p.add(rPoint, x03)), 45, rPoint);
        paths[key + "1"] = pa.mirror(pa.rotate(paths[key + "1"], radial, point), false, true);
        paths[key + "2"] = pa.mirror(pa.rotate(paths[key + "2"], radial, point), false, true);
        paths[key + "3"] = pa.mirror(pa.rotate(paths[key + "3"], radial, point), false, true);
        if (flag) {
            paths[key + "4"] = pa.rotate(new makerjs.paths.Line(lPoint, p.add(lPoint, x03)), -45, lPoint);
            paths[key + "5"] = pa.rotate(new makerjs.paths.Line(lPoint, p.add(lPoint, x03)), -135, lPoint);
            paths[key + "4"] = pa.mirror(pa.rotate(paths[key + "4"], radial, point), false, true);
            paths[key + "5"] = pa.mirror(pa.rotate(paths[key + "5"], radial, point), false, true);        
        }

        if (key != 'r')
            dPoint = p.rotate(dPoint, radial + 90, point);
        else
            dPoint = p.rotate(dPoint, radial, point);
        var fromView = p.add(p.add(viewOrigin, viewPanOffset), p.scale(dPoint, MakerJsPlayground.viewScale));
        dim = Math.round(flag? 2 * radius * 100: radius * 100)/100;
        if (units == 'cm') dim = dim/10;
        var dDiv = document.createElement("div");
        $(dDiv).addClass("dimension-number");
        $(dDiv).css("top", fromView[1] - 20);
        $(dDiv).css("left", fromView[0]);
        $(dDiv).html(Number(dim).toFixed(2) + ' ' + units);
        $(dDiv).attr("point", JSON.stringify(dPoint)).attr("rIndex", rIndex);
        $("#view-params").append(dDiv);
        return paths;
    }

    function calculateAreaTotal() {
        var price = 0;
        var uConvertion = Math.pow(10, 6);
        var models = foilModels.models;
        var keys = Object.keys(models);
        var areaTotal = 0;
        return new Promise(function(resolve, reject) {
            keys.forEach(key => {
                if (key == 'background') return;
                var area = MakerJsPlayground.calculateAreaPerShape(key);
                var shape = shape_list.find(item => (item.id == models[key].myKey));
                var shape_price = 0;
                if (shape) {
                    if(price_calculation == "normal")
                        shape_price = (Number(shape.sqm_price) * Number(area.value)).toFixed(2);
                    else if(price_calculation == "baseprice")
                        shape_price = (Number(shape.base_price) + shape.sqm_price * Number(area.value)).toFixed(2);
                    else if(price_calculation == "edge")
                    {
                        shape_price = (Number(shape.base_price) + Number(shape.edge_price) * area.edge + shape.sqm_price * Number(area.value)).toFixed(2);
                    }
                }
                price += parseFloat(shape_price);
                areaTotal += Number(area.value);
            });
            resolve(price, Number(areaTotal).toFixed(3));
        });
    }
    MakerJsPlayground.calculateAreaTotal = calculateAreaTotal;

    function calculateAreaPerShape(shapeKey) {
        var model = foilModels.models[shapeKey];
        var key = model.myKey;
        var uConvertion = Math.pow(10, 6);
        var edge_count = 0;
        var area = 0;
        if ( ['triangle', 'hexagon', 'pentagon'].indexOf(key) >= 0) {
            var n = [3, 5, 6][['triangle', 'hexagon', 'pentagon'].indexOf(key)];
            area = Math.pow(model.radius[0], 2) * n * Math.sin(2 * Math.PI/n)/2;
            edge_count = n;
        } else if (key == 'rect') {
            area = model.radius[0] * model.radius[1];
            edge_count = 4;
        } else if (['r_rect'].indexOf(key) >= 0) {
            area = model.radius[0] * model.radius[1];
            area -= Math.pow(model.radius[2], 2) * (4 - Math.PI);
            if (key == 'r_rect')
                edge_count = 4;
        } else if (key == 'oval1') {
            area = (model.radius[0] - model.radius[1]) * model.radius[1];
            area += Math.pow(model.radius[1]/2, 2) * Math.PI;            
        } else if (['circle', 'oval'].indexOf(key) >= 0) {
            area = Math.PI * model.radius[0] * model.radius[1];            
        } else if (key == 'oval2') {
            var a = (model.radius[0] - model.radius[2])/2;
            var b = model.radius[1]/2;
            area = Math.PI * a * b;
            area += model.radius[1] * model.radius[2];
        } else if (key == 'bootsform') {
            var a = calcER(model.radius);
            var b = model.radius[2]/2;
            var aa = model.radius[0]/2;
            area = 4 * (b/a) * (aa * Math.sqrt(Math.pow(a, 2) - Math.pow(aa, 2))/2 + a * a * Math.asin(aa/a)/2);                            
        } else if (key == 'bootsform_a') {
            var a = calcER(model.radius);
            var b = model.radius[2]/2;
            var aa = model.radius[0]/2;
            area = 4 * (b/a) * (aa * Math.sqrt(Math.pow(a, 2) - Math.pow(aa, 2))/2 + a * a * Math.asin(aa/a)/2); 
            
            var bB = calcER([model.radius[1], model.radius[0], model.radius[3]]);
            var bA = model.radius[3]/2;
            var area1 = (bB/bA) * (bA * bA * Math.asin(bA/bA)/2); 
            area1 -= (bB/bA) * (aa * Math.sqrt(Math.pow(bA, 2) - Math.pow(aa, 2))/2 + bA * bA * Math.asin(aa/bA)/2);
            area += 4 * area1;
        } else {
            var height = [];
            var width = [];
            var temp = makerjs.measure.modelExtents(model);
            if (temp) {
                height.push(temp.high[1]);
                height.push(temp.low[1]);
                width.push(temp.high[0]);
                width.push(temp.low[0]);
                var minWidth = Math.min(...width);
                var maxWidth = Math.max(...width);
                var minHeight = Math.min(...height);
                var maxHeight = Math.max(...height);

                var pich = Math.pow(10, 0);
                var uArea = Math.pow(pich, 2);
                
                for (var i = minWidth; i <= maxWidth; i = i + pich) {
                    for (var j = minHeight; j<= maxHeight; j= j + pich) {
                        if (makerjs.measure.isPointInsideModel([i, j], model)) {
                            area += uArea;
                            break;
                        }
                    }
                }
            }            
        }
        area = area/ uConvertion;
        return {
            value: Number(area).toFixed(3),
            edge: edge_count
        }
    }
    MakerJsPlayground.calculateAreaPerShape = calculateAreaPerShape;

    function isSmallDevice() {
        return document.body.clientWidth < 540;
    }
    MakerJsPlayground.isSmallDevice = isSmallDevice;
    function onWindowResize() {
        fitOnScreen();
        render();
    }
    MakerJsPlayground.onWindowResize = onWindowResize;
    //execution

    MakerJsPlayground.onload = function() {
        view = document.getElementById('view');
        paramsDiv = document.getElementById('params');
        measurementDiv = document.getElementById('measurement');
        checkShowGrid = document.getElementById('check-show-origin');
        viewSvgContainer = document.getElementById('view-svg-container');
        gridPattern = document.getElementById('gridPattern');
        crosshairs = document.getElementById('crosshairs');
        gridPatternFill = document.getElementById('gridPatternFill');
        margin = [viewSvgContainer.offsetLeft, viewSvgContainer.offsetTop];
        gridPattern.setAttribute('x', margin[0].toString());
        gridPattern.setAttribute('y', margin[1].toString());
        // document.body.classList.add('wait');
        // MakerJsPlayground.querystringParams = new QueryStringParams();
        // MakerJsPlayground.useWorkerThreads = !MakerJsPlayground.querystringParams['noworker'];        
    };    
})(MakerJsPlayground || (MakerJsPlayground = {}));