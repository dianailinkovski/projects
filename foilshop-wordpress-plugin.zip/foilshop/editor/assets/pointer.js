var Pointer;
(function (Pointer) {
    Pointer.wheelZoomDelta = 0.1;
    Pointer.clickDistance = 2;
    function distanceBetweenCurrent2Points(all) {
        if (!all[0].current || !all[1].current) {
            return null;
        }
        return makerjs.measure.pointDistance(all[0].current.fromCanvas, all[1].current.fromCanvas);
    }
    function average(all, fromCanvas) {
        if (all.length == 0)
            return null;
        var x = 0;
        var y = 0;
        for (var i = 0; i < all.length; i++) {
            var p = all[i].current;
            var point = fromCanvas ? p.fromCanvas : p.fromDrawingOrigin;
            x += point[0];
            y += point[1];
        }
        return [x / all.length, y / all.length];
    }
    var Manager = /** @class */ (function () {
        function Manager(view, pointersSelector, margin, getZoom, setZoom, onClick, onReset) {
            var _this = this;
            this.view = view;
            this.pointersSelector = pointersSelector;
            this.margin = margin;
            this.getZoom = getZoom;
            this.setZoom = setZoom;
            this.onClick = onClick;
            this.onReset = onReset;
            this.initialAveragePointFromDrawingOrigin = null;
            this.previousAveragePointFromCanvas = null;
            this.wheelTimeout = 250;
            this.down = {};
            this.selected = false;
            this.selectedModel = null;
            view.addEventListener('wheel', function (e) { _this.viewWheel(e); });
            view.addEventListener('pointerdown', function (e) { _this.viewPointerDown(e); });
            view.addEventListener('pointermove', function (e) { _this.viewPointerMove(e); });
            view.addEventListener('pointerup', function (e) { _this.viewPointerUp(e); });
            document.getElementById("TF-drawing").addEventListener('dblclick', function(e) { _this.editText(e)});
            document.getElementById("TF-background").addEventListener('dblclick', function(e) { _this.editText(e)});
            //listen to touchend on entire document since we do not always get a pointerup event, as when pointer is released outside of view
            document.addEventListener('touchend', function (e) {
                if (e.touches.length)
                    return;
                _this.reset();
            });
            document.addEventListener('mouseup', function (e) { _this.reset(); });
            document.addEventListener('MSPointerUp', function (e) { _this.reset(); });
        }
        Manager.prototype.getPointRelative = function (ev) {
            var p = makerjs.point;
            var panZoom = this.getZoom();
            var fromCanvas = p.subtract([ev.pageX, ev.pageY], Pointer.pageOffset(this.view));
            var fromView = p.subtract(fromCanvas, this.margin);
            var pannedOrigin = p.add(panZoom.origin, panZoom.pan);
            var fromDrawingOrigin = p.scale(p.subtract(fromView, pannedOrigin), 1 / panZoom.zoom);
            return {
                fromCanvas: fromCanvas,
                fromDrawingOrigin: fromDrawingOrigin,
                panZoom: panZoom
            };
        };
        Manager.prototype.getViewPoints = function(point) {
            var p = makerjs.point;
            var panZoom = this.getZoom();
            var pannedOrigin = p.add(panZoom.origin, panZoom.pan);
            var fromView = p.add(p.scale(point, panZoom.zoom), pannedOrigin);
            fromView = p.subtract(fromView, [5, 5]);
            return fromView;
        };
        Manager.prototype.reset = function () {
            document.body.classList.remove('pointing');
            this.erase();
            this.down = {};
            this.count = 0;
            this.onReset();
        };
        Manager.prototype.asArray = function () {
            var result = [];
            for (var id in this.down) {
                result.push(this.down[id]);
            }
            return result;
        };
        Manager.prototype.erase = function () {
            var oldNode = document.querySelector(this.pointersSelector);
            var domPointers = oldNode.cloneNode(false);
            oldNode.parentNode.replaceChild(domPointers, oldNode);
            return domPointers;
        };
        Manager.prototype.drawPointer = function (ns, point, id, isCrossHair) {
            function createElement(tagName, attrs) {
                var el = document.createElementNS(ns, tagName);
                for (var attrName in attrs) {
                    var value = attrs[attrName];
                    el.setAttributeNS(null, attrName, value);
                }
                return el;
            }
            function createCircle(circleId, cx, cy, r) {
                return createElement('circle', {
                    "id": circleId,
                    "cx": cx,
                    "cy": cy,
                    "r": r
                });
            }
            function createLine(lineId, x1, y1, x2, y2) {
                return createElement('line', {
                    "id": lineId,
                    "x1": x1,
                    "y1": y1,
                    "x2": x2,
                    "y2": y2
                });
            }
            var g = createElement('g', { "id": id });
            if (isCrossHair) {
                var x = createLine('x', point[0], 0, point[0], '100%');
                var y = createLine('y', 0, point[1], '100%', point[1]);
                if (this.selected) {
                    $(x).css("stroke", "#f2711c");
                    $(y).css("stroke", "#f2711c");
                }
                    
                g.appendChild(x);
                g.appendChild(y);
            }
            else {
                var c = createCircle('c', point[0], point[1], 35);
                g.appendChild(c);
            }
            return g;
        };
        Manager.prototype.draw = function (pointers) {
            //erase all pointers
            var domPointers = this.erase();
            var ns = domPointers.getAttribute('xmlns');
            for (var i = 0; i < pointers.length; i++) {
                var pointer = pointers[i];
                // domPointers.appendChild(this.drawPointer(ns, pointer.current.fromCanvas, 'pointer' + i, pointers.length == 1));
            }
            if (pointers.length == 2) {
                // domPointers.appendChild(this.drawPointer(ns, this.previousAveragePointFromCanvas, 'pointer' + i, true));
            }
            document.body.classList.add('pointing');
        };
        Manager.prototype.isWithinMargin = function (p) {
            if (!makerjs.measure.isBetween(p.fromCanvas[0], this.margin[0], this.view.offsetWidth - this.margin[0], false))
                return false;
            if (!makerjs.measure.isBetween(p.fromCanvas[1], this.margin[1], this.view.offsetHeight - this.margin[1], false))
                return false;
            return true;
        };

        Manager.prototype.clearSelectors = function () {
            var keys = Object.keys(foilModels.models);
            for(var i = 0; i < keys.length; i++) {
                var key = keys[i];
                if (key != "background") {
                    foilModels.models[key].selected = false;
                    foilModels.models[key].layer = "black";
                }
            }
            MakerJsPlayground.renderWithModels(foilModels);
        };

        Manager.prototype.viewPointerDown = function (e) {
            clearTimeout(this.wheelTimer);
            var pointRelative = this.getPointRelative(e);
            
            if (!this.isWithinMargin(pointRelative))
                return;
            e.preventDefault();
            e.stopPropagation();
            var pointer = {
                id: e.pointerId,
                type: e.pointerType,
                initial: pointRelative,
                previous: pointRelative,
                current: pointRelative,
                srcElement: e.srcElement
            };
            this.down[pointer.id] = pointer;
            this.count++;
            this.isClick = this.count == 1;
            
            if (measureStatus) {
               this.selected = false;
               this.selectedModel = null;
               measurePoints[0] = pointRelative;
            } else if (customDrawing) {
                var keys = Object.keys(foilModels.models);
                var model = foilModels.models[keys[keys.length - 1]];
                if (model.myKey == "draw") {
                    var flag = true;
                    if (model.sPoints.length > 0) {
                        flag = makerjs.measure.isPointDistinct(pointRelative.fromDrawingOrigin, [model.sPoints[0]], 2.5);
                    }
                    if (flag){
                        if (model.sPoints.length > 0)
                            model.sPoints[model.sPoints.length - 1] = pointRelative.fromDrawingOrigin;
                        else
                            model.sPoints.push(pointRelative.fromDrawingOrigin);
                        model.finished = false;
                    } else {
                        model.sPoints.pop();
                        customDrawing = false;
                        model.finished = true;
                    }
                    this.selected = true;
                    this.selectedModel = {
                        key: keys[keys.length - 1],   
                        model: model,
                        rIndex: -1,
                        pIndex: model.sPoints.length
                    };
                }
            } else {
                this.clearSelectors();
            }
            this.draw([pointer]);
            // switch (this.count) {
            //     case 1:
            //         this.draw([pointer]);
            //         break;
            //     case 2:
            //         var all = this.asArray();
            //         this.initialZoom = pointRelative.panZoom.zoom;
            //         this.initialDistance = distanceBetweenCurrent2Points(all);
            //         this.initialAveragePointFromDrawingOrigin = average(all, false);
            //         this.previousAveragePointFromCanvas = average(all, true);
            //         this.draw(all);
            //         break;
            //     default:
            //         this.erase();
            //         break;
            // }
        };
        Manager.prototype.viewPointerMove = function (e) {
            var pointer = this.down[e.pointerId];
            var pointRelative = this.getPointRelative(e);
            if (customDrawing && this.selected) {
                var model = this.selectedModel.model;
                if (model.sPoints.length < this.selectedModel.pIndex) {
                    model.sPoints.push(pointRelative.fromDrawingOrigin);
                } else {
                    model.sPoints[this.selectedModel.pIndex] = pointRelative.fromDrawingOrigin;
                }
                var newModel = reRenderModels(model);
                if (!newModel) {
                    this.selected = false;
                    e.stopPropagation();
                    e.preventDefault();
                    return;
                }
                foilModels.models[this.selectedModel.key] = newModel;
                MakerJsPlayground.renderWithModels(foilModels);
                return;
            }
            if (!pointer)
                return;
            clearTimeout(this.wheelTimer);
            
            e.stopPropagation();
            e.preventDefault();
            pointer.previous = pointer.current;
            pointer.current = pointRelative;
            var panZoom = pointer.current.panZoom;
            var p = makerjs.point;
            var panDelta;
            var newPan = panZoom.pan;
            
            panDelta = p.subtract(pointer.current.fromCanvas, pointer.previous.fromCanvas);
            newPan = p.add(panZoom.pan, panDelta);
            this.draw([pointer]);
            
            if (measureStatus) {
                measurePoints[1] = pointRelative;
                var path = new makerjs.paths.Line(measurePoints[0].fromDrawingOrigin, measurePoints[1].fromDrawingOrigin);
                path = makerjs.path.mirror(path, false, true);
                path.layer = "silver";
                foilModels.paths["measure"] = path;
                foilModels.paths.measure.points = measurePoints;
                MakerJsPlayground.renderWithModels(foilModels);
            } else if (this.selected) {
                var model = this.selectedModel.model;
                var newModel = JSON.parse(JSON.stringify(model));
                const oldRadius = newModel.radius;
                var delta = p.subtract(pointer.current.fromDrawingOrigin, pointer.previous.fromDrawingOrigin);
                if (this.selectedModel.pIndex == 0) {
                    if (['draw'].indexOf(model.myKey) < 0) {
                        newModel.origin = makerjs.point.add(newModel.origin, [delta[0], -delta[1]]);
                    } else {
                        newModel.sPoints[this.selectedModel.pIndex] = pointer.current.fromDrawingOrigin;
                        var temp = reRenderModels(newModel);
                        if (temp)
                            newModel = temp;
                    }
                } else {
                    if (model.myKey == "circle") {
                        model.radius[0] += delta[0];
                        model.radius[1] += delta[0];
                        model.radius = model.radius.map(r => (Math.abs(r)));
                    } else if (model.myKey == "hexagon" || model.myKey == "pentagon") {
                        var curR = Math.sqrt(Math.pow(pointer.current.fromDrawingOrigin[0], 2) + Math.pow(pointer.current.fromDrawingOrigin[1], 2));
                        var preR = Math.sqrt(Math.pow(pointer.previous.fromDrawingOrigin[0], 2) + Math.pow(pointer.previous.fromDrawingOrigin[1], 2));
                        var radius = curR - preR;
                        model.radius[0] += radius;
                        model.radius = model.radius.map(r => (Math.abs(r)));
                    } else if (model.myKey == "oval") {
                        var sign = 1;
                        if (this.selectedModel.pIndex == 2 || this.selectedModel.pIndex == 3)
                            sign = -1;
                        model.radius[this.selectedModel.rIndex] += sign * delta[this.selectedModel.rIndex];
                        model.radius = model.radius.map(r => (Math.abs(r)));
                    } else if (model.myKey == "rect") {
                        var xSign = 1;
                        var ySign = 1;
                        if (this.selectedModel.pIndex == 1 || this.selectedModel.pIndex == 2) {
                            xSign = -1;                            
                        }
                            
                        if (this.selectedModel.pIndex == 1 || this.selectedModel.pIndex == 4) {
                            ySign = -1;                            
                        }

                        if (this.selectedModel.pIndex == 1 || this.selectedModel.pIndex == 2) {
                            model.origin = makerjs.point.add(model.origin, [delta[0], 0]); 
                        }

                        if (this.selectedModel.pIndex == 2 || this.selectedModel.pIndex == 3) {
                            model.origin = makerjs.point.add(model.origin, [0, -delta[1]]); 
                        }
                        
                        model.radius[0] += xSign * delta[0];
                        model.radius[1] += ySign * delta[1];  
                        model.radius = model.radius.map(r => (Math.abs(r)));                      
                    } else if (model.myKey == "r_rect" || model.myKey == "oval1") {
                        var sign = 1;
                        if (this.selectedModel.pIndex == 3 || this.selectedModel.pIndex == 4) {
                            sign = -1;                            
                        }

                        if (model.myKey == "oval1") {
                            if (this.selectedModel.pIndex == 3) {
                                model.origin = makerjs.point.add(model.origin, [delta[0], 0]);
                                model.radius[this.selectedModel.rIndex] += 2 * sign * delta[this.selectedModel.rIndex];
                            } else {
                                model.radius[this.selectedModel.rIndex] += sign * delta[this.selectedModel.rIndex];
                            }
    
                            if (this.selectedModel.pIndex == 2) {
                                model.origin = makerjs.point.add(model.origin, [0, -delta[1]]);
                            }
                            
                        } else {
                            model.radius[this.selectedModel.rIndex] += 2 * sign * delta[this.selectedModel.rIndex];
                        }
                        
                        model.radius = model.radius.map(r => (Math.abs(r)));
                        if (model.myKey == 'oval1') {
                            if (model.radius[0] <= model.radius[2]) {
                                model.radius[2] = model.radius[0]/4;
                            }
                            if (model.radius[1] <= model.radius[2]) {
                                model.radius[2] = model.radius[1]/4;
                            }
                        } else {
                            var maxR = Math.max(...model.radius.slice(2));
                            if (model.radius[0] < 2*maxR || model.radius[1] < 2*maxR) {
                                model.radius = oldRadius;
                            }
                        }
                        
                        console.log(model.radius);
                    } else if (model.myKey == "triangle") {
                        var curR = Math.sqrt(Math.pow(pointer.current.fromDrawingOrigin[0], 2) + Math.pow(pointer.current.fromDrawingOrigin[1], 2));
                        var preR = Math.sqrt(Math.pow(pointer.previous.fromDrawingOrigin[0], 2) + Math.pow(pointer.previous.fromDrawingOrigin[1], 2));
                        var radius = curR - preR;
                        model.radius[0] += radius;
                        model.radius = model.radius.map(r => (Math.abs(r)));
                    } else if (model.myKey.indexOf("bootsform") >= 0) {
                        var xsign = 1;
                        var ysign = 1;                    
                        if ([1, 3, 4, 6].indexOf(this.selectedModel.pIndex) >= 0) {
                            if ([3, 4].indexOf(this.selectedModel.pIndex) >= 0) xsign = -1;
                            if ([4, 6].indexOf(this.selectedModel.pIndex) >= 0) ysign = -1;
                            model.radius[0] += 2 * xsign * delta[0];
                            model.radius[1] += 2 * ysign * delta[1];
                        } else if ([2, 5].indexOf(this.selectedModel.pIndex) >= 0) {
                            if (this.selectedModel.pIndex == 5) xsign = -1;
                            model.radius[2] += xsign * 2 * delta[1];
                        } else {
                            if (this.selectedModel.pIndex == 7) xsign = -1;
                            model.radius[3] += xsign * 2 * delta[0];
                        }
                        model.radius = model.radius.map(r => (Math.abs(r)));
                        if (model.radius[1] >= model.radius[2]) {
                            model.radius[1] = model.radius[2] - 10;
                        }
    
                        if (model.myKey == "bootsform_a" && model.radius[0] >= model.radius[3])
                            model.radius[0] = model.radius[3] - 10;
                    } else if (model.myKey == "oval2") {
                        var xsign = 1;
                        var ysign = 1;
                        if ([2, 3, 5, 6].indexOf(this.selectedModel.pIndex) >= 0) {
                            if ([3, 6].indexOf(this.selectedModel.pIndex) >= 0) xsign = -1;
                            if ([6, 5].indexOf(this.selectedModel.pIndex) >= 0) ysign = -1;
                            model.radius[2] += 2 * xsign * delta[0];
                            model.radius[1] += 2 * ysign * delta[1];
                        } else {
                            if (this.selectedModel.pIndex == 4) xsign = -1;
                            model.radius[0] += xsign * 2 * delta[0];
                        }  
                        model.radius = model.radius.map(r => (Math.abs(r)));                  
                    } else if (model.myKey == 'draw') {
                        model.sPoints[this.selectedModel.pIndex] = pointer.current.fromDrawingOrigin;
                    }
                    // console.log(model);
                    var temp = reRenderModels(model);
                    if (temp) {
                        newModel = temp;
                    } else {
                        this.selected = false;
                        foilModels.models[this.selectedModel.key].selected = false;
                        foilModels.models[this.selectedModel.key] = newModel;
                        MakerJsPlayground.renderWithModels(foilModels,true);        
                        return;
                    }
                }
                foilModels.models[this.selectedModel.key] = newModel;
                this.selectedModel.model = newModel;
                MakerJsPlayground.renderWithModels(foilModels);
            } else {                
                panZoom.pan = newPan;
                this.setZoom(panZoom);
            }
        };
        Manager.prototype.viewPointerUp = function (e) {
            clearTimeout(this.wheelTimer);
            if (this.selected) {
                addHistory();
            }

            if (!customDrawing) {
                this.selected = false;
                this.selectedModel = null;
            }
            
            var pointer = this.down[e.pointerId];
            if (pointer) {
                e.stopPropagation();
                e.preventDefault();
                delete this.down[e.pointerId];
                this.count--;
                if (this.count == 0) {
                    if (this.isClick) {
                        var clickTravel = makerjs.measure.pointDistance(pointer.initial.fromCanvas, pointer.current.fromCanvas);
                        if (clickTravel <= Pointer.clickDistance) {
                            this.onClick(pointer.srcElement);
                        }
                    }
                    this.reset();
                }
                else {
                    this.draw(this.asArray());
                }
            }
        };
        Manager.prototype.scaleCenterPoint = function (panZoom, newZoom, centerPointFromDrawingOrigin) {
            var p = makerjs.point;
            var previousZoom = panZoom.zoom;
            var zoomDiff = newZoom / previousZoom;
            var previousScaledCenter = p.scale(centerPointFromDrawingOrigin, previousZoom);
            var currentScaledCenter = p.scale(previousScaledCenter, zoomDiff);
            var centerPointDiff = p.subtract(previousScaledCenter, currentScaledCenter);
            panZoom.zoom = newZoom;
            panZoom.pan = p.add(panZoom.pan, centerPointDiff);
        };
        Manager.prototype.viewWheel = function (e) {
            var _this = this;
            this.isClick = false;
            var pointRelative = this.getPointRelative(e);
            if (!this.isWithinMargin(pointRelative))
                return;
            e.preventDefault();
            var pointer = {
                id: 0,
                type: 'wheel',
                initial: pointRelative,
                previous: pointRelative,
                current: pointRelative,
                srcElement: e.srcElement
            };
            var sign = (e.wheelDelta || e['deltaY']) > 0 ? 1 : -1;
            var newZoom = pointRelative.panZoom.zoom * (1 + sign * Pointer.wheelZoomDelta);
            this.scaleCenterPoint(pointRelative.panZoom, newZoom, pointRelative.fromDrawingOrigin);
            var keys = Object.keys(foilModels.models);
            var maxWidths = [];
            for(var i = 0; i < keys.length; i++) {
                var mm = makerjs.measure.modelExtents(foilModels.models[keys[i]]);
                var maxVal = Math.max(mm.width, mm.height);
                foilModels.models[keys[i]].showFlag = maxVal * pointRelative.panZoom.zoom >= 50;
                maxWidths.push(maxVal * pointRelative.panZoom.zoom);
            }
            var maxW = Math.max(...maxWidths); 
            
            if (maxW < 50 || maxW > 1500) {
                MakerJsPlayground.renderWithModels(foilModels);
                return;
            }
            this.setZoom(pointRelative.panZoom);
            this.draw([pointer]);
            clearTimeout(this.wheelTimer);
            this.wheelTimer = setTimeout(function () {
                _this.erase();
            }, this.wheelTimeout);
        };
        Manager.prototype.editText = function (e) {
            // clearTimeout(this.wheelTimer);
            // var pointRelative = this.getPointRelative(e);
            
            // if (!this.isWithinMargin(pointRelative))
            //     return;
            // e.preventDefault();
            // e.stopPropagation();

            if (!customDrawing && !measureStatus) {
                var models = foilModels.models;
                var keys = Object.keys(models);
                for(var i = keys.length - 1; i >= 0; i--) {
                    if (keys[i] != 'background') {
                        var model = models[keys[i]];
                        if (model.myKey == 'text') {
                            // if (makerjs.measure.isPointEqual(pointRelative.fromDrawingOrigin, model.origin, 5)) {
                                model.selected = true;
                                model.selected = true;
                                model.layer = "orange";
                                MakerJsPlayground.renderWithModels(foilModels);
                                textEditor.find('#fontSize').val(model.fontSize);
                                textEditor.find('#text').val(model.text);
                                textEditor.dialog("open");
                                break;
                            // }
                        }
                    }
                }
            }
        };
        return Manager;
    }());
    Pointer.Manager = Manager;
    // Find out where an element is on the page
    // From http://www.quirksmode.org/js/findpos.html
    function pageOffset(el) {
        var curleft = 0, curtop = 0;
        if (el.offsetParent) {
            do {
                curleft += el.offsetLeft;
                curtop += el.offsetTop;
            } while (el = el.offsetParent);
        }
        return [curleft, curtop];
    }
    Pointer.pageOffset = pageOffset;
})(Pointer || (Pointer = {}));
//# sourceMappingURL=pointer.js.map