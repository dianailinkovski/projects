var server_url = plugin_dir_url + "editor/server.php";
var shape_preview_url = plugin_dir_url + "editor/assets/images/";
var shape_list = [];
var FREEDRAW_ID = 1000;
var freedrawing = false;
var length_measuring = 0;
var measuring_group = null;
var selected_item = null;
var stage;
var layer;
var scaleBy = 1.04;
var dimension_unit = 'mm';
var active_key = 0;
var dimension_step = 5;
var pane_width = 3000;
var pane_height = 3000;
let stage_status = [[]];
var stage_index = 0;
var product_price = 0;
jQuery(document).ready(function(){
	jQuery(".woocommerce_order_items .display_meta tbody tr td p").on("click", function(){
		layer.removeChildren();
		layer.draw();	
		stage_status = [[]];
		var shape_data = jQuery(this).text().split("&&")[0];
		shape_data = shape_data.split("@@");
		for (var i = 0; i < shape_data.length; i++) {
			shape_data[i] = shape_data[i].replace(/\\"/g, '"');
		}
		stage_status.push(shape_data);
		stage_index = 1;
		reloadStatus(shape_data);
		document.getElementById('TF-wrapper').classList.remove('hidden');
	})
		
	max_width = max_width == "" ? "" : JSON.parse(max_width.replace(/\*/g, '"')); 
	max_height = max_height == "" ? "" : JSON.parse(max_height.replace(/\*/g, '"')); 
	min_width = min_width == "" ? "" : JSON.parse(min_width.replace(/\*/g, '"')); 
	min_height = min_height == "" ? "" : JSON.parse(min_height.replace(/\*/g, '"')); 
	var width = jQuery("#TF-drawing").width();
	var height = jQuery("#TF-drawing").height();
	var layout_centerX = width / 2;
  	var layout_centerY = height / 2;
	stage = new Konva.Stage({
		container: 'TF-drawing',
		width: width,
		height: height,
		draggable: true
	});
	layer = new Konva.Layer();
  	stage.add(layer); 
  	stage.on('wheel', e => {
        e.evt.preventDefault();
        var oldScale = stage.scaleX();

        var mousePointTo = {
          x: stage.getPointerPosition().x / oldScale - stage.x() / oldScale,
          y: stage.getPointerPosition().y / oldScale - stage.y() / oldScale
        };

        var newScale = e.evt.deltaY > 0 ? oldScale * scaleBy : oldScale / scaleBy;
        stage.scale({ x: newScale, y: newScale });

        var newPos = {
          x:
            -(mousePointTo.x - stage.getPointerPosition().x / newScale) *
            newScale,
          y:
            -(mousePointTo.y - stage.getPointerPosition().y / newScale) *
            newScale
        };
        stage.position(newPos);
        stage.batchDraw();
        stage.find('Text').setAttr("fontSize", 16 / newScale);
  	});
  	setShapeList();
  	jQuery("#TF-wrapper").css("opacity","1");
  	jQuery("#TF-wrapper").addClass(visibleClass);
  	jQuery(document).bind("keyup", function(e) {
  		active_key = 0;
  		jQuery("input[type='number']").attr("step",1);
  	});
  	jQuery(document).bind("keydown", function(e) {
        switch(e.which)
        {
        	case 46:
        		removeShape();
        		break;
        	case 17:
        		jQuery("input[type='number']").attr("step",dimension_step);
        		break;
        }
        active_key = e.which;
    });
	jQuery("body").on("click", ".vltTDT-patternBar-patternGroup", function(){
		freedrawing = false;
		stage.find('Transformer').destroy();
		resetRulerState();
		jQuery("input.shape_input").remove();

		stage.scale({ x: 1, y: 1 });
        var newPos = {
          x: 0,
          y: 0
        };
        stage.position(newPos);
        stage.batchDraw();

		var selected_shape_id = jQuery(this).attr("shape_id");
		var selected_shape = shape_list.find(x=>x.id == selected_shape_id);
		var adding_shape;
		if(selected_shape.shape_type == "polygon")
		{
			if(selected_shape.name == "Draw shape")
			{
				adding_shape = new Konva.Group({
			        draggable: true,
			        name: 'polygon',
			        subname:selected_shape.name,
			        class: 'shape_group',
			        base_price: selected_shape.base_price,
			        sqm_price: selected_shape.sqm_price,
			        edge_price: selected_shape.edge_price,
			        min_width: min_width == "" ? selected_shape.min_width : Number(min_width[selected_shape.name]),
			        min_height: min_height == "" ? selected_shape.min_height : Number(min_height[selected_shape.name]),
			        max_width: max_width == "" ? selected_shape.max_width : Number(max_width[selected_shape.name]),
			        max_height: max_height == "" ? selected_shape.max_height : Number(max_height[selected_shape.name])
		      	});
		      	var polygon_lines = new Konva.Line({
			        points: [],
			        closed: true,
			        fill: 'lightgrey',
			        stroke: 'black',
			        strokeWidth: 2,
			        name: 'polygon_lines',
			        class: 'group_item'
		      	});
		      	adding_shape.add(polygon_lines);	
		      	var shape_area = new Konva.Text({
			        x: -1000,
			        y: -1000,
			        text: "",
			        fontSize: 16,
			        fill: 'grey',
			        name: 'shape_area',
			        class: 'group_item'
		      	});
		      	adding_shape.add(shape_area);	
			}
			else
			{
				var polygon_setting = JSON.parse(selected_shape.default_setting);
				
		      	adding_shape = new Konva.Group({
			        draggable: true,
			        name: 'polygon',
			        subname: selected_shape.name,
			        class: 'shape_group',
			        base_price: selected_shape.base_price,
			        sqm_price: selected_shape.sqm_price,
			        edge_price: selected_shape.edge_price,
			        min_width: min_width == "" ? selected_shape.min_width : Number(min_width[selected_shape.name]),
			        min_height: min_height == "" ? selected_shape.min_height : Number(min_height[selected_shape.name]),
			        max_width: max_width == "" ? selected_shape.max_width : Number(max_width[selected_shape.name]),
			        max_height: max_height == "" ? selected_shape.max_height : Number(max_height[selected_shape.name]),
			        centerX: layout_centerX,
			        centerY: layout_centerY,
			        n: polygon_setting.n
		      	});
		      	var shape_points = [];
		      	var angle_value = (polygon_setting.n - 2) * 180 / polygon_setting.n;
		      	var radius = polygon_setting.length / 2 / Math.cos(angle_value / 2 * Math.PI / 180);
		      	for (var i = 0; i < polygon_setting.n; i++) {
		      		if(selected_shape.name == "Triangle")
		      		{
		      			shape_points.push(layout_centerX + radius * Math.cos(2 * Math.PI * i / polygon_setting.n - Math.PI / 2));
						shape_points.push(layout_centerY + radius * Math.sin(2 * Math.PI * i / polygon_setting.n - Math.PI / 2));
		      		}
		      		else if(selected_shape.name == "Pentagon")
		      		{
		      			shape_points.push(layout_centerX + radius * Math.cos(2 * Math.PI * i / polygon_setting.n - Math.PI / 3));
						shape_points.push(layout_centerY + radius * Math.sin(2 * Math.PI * i / polygon_setting.n - Math.PI / 3));
		      		}
		      		else if(selected_shape.name == "Hexagon")
		      		{
		      			shape_points.push(layout_centerX + radius * Math.cos(2 * Math.PI * i / polygon_setting.n - Math.PI * (angle_value - 90) / 2 / 180));
						shape_points.push(layout_centerY + radius * Math.sin(2 * Math.PI * i / polygon_setting.n - Math.PI * (angle_value - 90) / 2 / 180));
		      		}
				}
				var polygon_lines = new Konva.Line({
			        points: shape_points,
			        closed: true,
			        fill: 'lightgrey',
			        stroke: 'black',
			        strokeWidth: 2,
			        name: 'polygon_lines',
			        class: 'group_item'
		      	});
		      	adding_shape.add(polygon_lines);	

		      	var start = {x:shape_points[0], y:shape_points[1]};
		      	var second = {x:shape_points[2], y:shape_points[3]};
		      	
		      	var vertex = new Konva.Circle({
			        x: start.x,
			        y: start.y,
			        radius: 6,
			        fill: 'blue',
			        stroke: 'black',
			        strokeWidth: 2,
			        draggable: true,
			        opacity: 0.3,
			        name: selected_shape.name + '_vertex',
			        class: 'group_item',
			        dragBoundFunc: function(pos) {
			        	resetRegularPolygon(adding_shape);
						layer.draw();
		          		return {
			            	x: pos.x,
			            	y: pos.y
		          		};
			        }
		      	});
		      	vertex.on('dragstart', function() {
		      		this.hide();
					stage.find('Transformer').destroy();
					layer.draw();
		        });
		        vertex.on('dragend', function() {
		        	resetRegularPolygon(adding_shape);
		        	this.show();
		        	layer.draw();
		        });
		      	vertex.on('mouseover', function() {
					this.strokeWidth(4);
					this.opacity(1);
					layer.draw();
		        });
		        vertex.on('mouseout', function() {
					this.strokeWidth(2);
					this.opacity(0.3);
					layer.draw();
				});
				adding_shape.add(vertex);

				var length = new Konva.Text({
			        x: start.x + (second.x - start.x) / 2 + 10,
			        y: start.y + (second.y - start.y) / 2,
			        text: polygon_setting.length + dimension_unit,
			        fontSize: 16,
			        fill: 'grey',
			        name: 'polygon_length',
			        class: 'group_item'
		      	});
		      	length.on('dblclick dbltap', (e) => {
		      		if(length_measuring != 0)
		      			return;
			        var textPosition = e.target.getAbsolutePosition();
					var stageBox = stage.container().getBoundingClientRect();
					var areaPosition = {
			          x: stageBox.left + textPosition.x,
			          y: stageBox.top + textPosition.y
			        };
					var textarea = document.createElement('input');
					textarea.classList.add("shape_input");
					textarea.setAttribute("type","number");
					document.body.appendChild(textarea);
					textarea.value = e.target.text().replace(dimension_unit,"");
			        textarea.style.position = 'fixed';
			        textarea.style.top = areaPosition.y + 'px';
			        textarea.style.left = areaPosition.x + 'px';
			        textarea.style.width = e.target.width();
			        textarea.focus();
			        textarea.addEventListener('keydown', function(e) {
			          if (e.keyCode === 13) {
			          	if(textarea.value == "")
			          	{
			          		alert("Enter a value.");
			          		return;
			          	}
			          	stage.find('Transformer').destroy();
			            document.body.removeChild(textarea);
			            resetRegularPolygonByLength(adding_shape,Number(textarea.value));
			            layer.draw(); 
			          }
			        });
		      	});
		      	adding_shape.add(length);

		      	var angle_x = start.x;
		      	var angle_y = start.y;
		      	if(selected_shape.name == "Triangle")
		      	{
		      		angle_x = start.x - 10;
		      		angle_y = start.y + 20;
		      	}
		      	else if(selected_shape.name == "Pentagon")
		      	{
		      		angle_x = start.x - 25;
		      		angle_y = start.y + 20;	
		      	}
		      	else if(selected_shape.name == "Hexagon")
		      	{
		      		angle_x = start.x - 40;
		      		angle_y = start.y + 5;		
		      	}
		      	var angle = new Konva.Text({
			        x: angle_x,
			        y: angle_y,
			        text: angle_value + '°',
			        fontSize: 16,
			        fill: 'black',
			        name: 'polygon_angle',
			        class: 'group_item'
		      	});
		      	adding_shape.add(angle);

		      	var shape_area = new Konva.Text({
			        x: layout_centerX,
			        y: layout_centerY,
			        text: "",
			        fontSize: 16,
			        fill: 'grey',
			        name: 'shape_area',
			        class: 'group_item'
		      	});
		      	adding_shape.add(shape_area);	
			}		
		}
		else if(selected_shape.shape_type == "text")
		{
			adding_shape = new Konva.Group({
		        draggable: true,
		        name: selected_shape.shape_type,
		        class: 'text_group'
	      	})
			var text_setting = JSON.parse(selected_shape.default_setting);
			text_setting.fill = "black";
			text_setting.text = "TEXT HERE";
			text_setting.fontFamily = "Calibri";
			text_setting.fontSize = 22;
			text_setting.x = layout_centerX;
			text_setting.y = layout_centerY;
			var text_field = new Konva.Text(text_setting);
	      	text_field.on('dblclick dbltap', () => {
	      		if(length_measuring != 0)
	      			return;
		        var textPosition = text_field.getAbsolutePosition();
				var stageBox = stage.container().getBoundingClientRect();
				var areaPosition = {
		          x: stageBox.left + textPosition.x,
		          y: stageBox.top + textPosition.y
		        };
				var textarea = document.createElement('input');
				textarea.classList.add("shape_input");
				document.body.appendChild(textarea);
				textarea.style.position = 'fixed';
		        textarea.style.top = areaPosition.y + 'px';
		        textarea.style.left = areaPosition.x + 'px';
		        textarea.style.width = text_field.width();
		        textarea.focus();
		        textarea.addEventListener('keydown', function(e) {
		          if (e.keyCode === 13) {
		          	if(textarea.value == "")
		          	{
		          		alert("Enter a value.");
		          		return;
		          	}
		          	stage.find('Transformer').destroy();
		            document.body.removeChild(textarea);
		            text_field.text(textarea.value);
		            layer.draw();
		            saveStatus();
		          }
		        });
	      	});
	      	adding_shape.add(text_field);
		}
		else
		{
			var shape_setting = JSON.parse(selected_shape.default_setting);
			shape_setting.stroke = "black";
			shape_setting.fill = "lightgrey";
			shape_setting.strokeWidth = 2;
			shape_setting.x = layout_centerX;
			shape_setting.y = layout_centerY;
			shape_setting.class = "group_item";
			adding_shape = new Konva.Group({
		        draggable: true,
		        name: selected_shape.shape_type,
		        class: 'shape_group',
		        base_price: selected_shape.base_price,
		        sqm_price: selected_shape.sqm_price,
		        edge_price: selected_shape.edge_price,
		        min_width: min_width == "" ? selected_shape.min_width : Number(min_width[selected_shape.name]),
		        min_height: min_height == "" ? selected_shape.min_height : Number(min_height[selected_shape.name]),
		        max_width: max_width == "" ? selected_shape.max_width : Number(max_width[selected_shape.name]),
		        max_height: max_height == "" ? selected_shape.max_height : Number(max_height[selected_shape.name])
	      	})
	      	switch(selected_shape.shape_type)
	      	{
	      		case 'circle':
	      			var circle = new Konva.Circle(shape_setting);
	      			adding_shape.add(circle);
	      			var diameter_line = new Konva.Line({
				        points: [shape_setting.x,shape_setting.y,shape_setting.x + shape_setting.radius,shape_setting.y],
				        stroke: 'grey',
				        strokeWidth: 2,
				        lineCap: 'round',
				        lineJoin: 'round',
				        dash: [5, 10],
				        name: 'circle_line',
				        class: 'group_item'
			      	});
					adding_shape.add(diameter_line);
					var diameter_length = new Konva.Text({
				        x: shape_setting.x + shape_setting.radius / 2,
				        y: shape_setting.y,
				        text: shape_setting.radius + dimension_unit,
				        fontSize: 16,
				        fill: 'grey',
				        name: 'circle_length',
				        class: 'group_item'
			      	});
			      	diameter_length.on('dblclick dbltap', () => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = diameter_length.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = diameter_length.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = diameter_length.width();
				        textarea.focus();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetCircleByDiameter(adding_shape,Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	adding_shape.add(diameter_length);
			      	var vertex = new Konva.Circle({
				        x: shape_setting.x + shape_setting.radius,
				        y: shape_setting.y,
				        radius: 6,
				        fill: 'blue',
				        stroke: 'black',
				        strokeWidth: 2,
				        draggable: true,
				        opacity: 0.3,
				        name: 'circle_vertex',
				        class: 'group_item',
				        dragBoundFunc: function(pos) {
				        	resetCircle(adding_shape);
							layer.draw();
			          		return {
				            	x: pos.x,
				            	y: pos.y
			          		};
				        }
			      	});
			      	vertex.on('dragstart', function() {
						stage.find('Transformer').destroy();
						layer.draw();
			        });
			        vertex.on('dragend', function() {
						resetCircle(adding_shape);
						layer.draw();
			        });
			      	vertex.on('mouseover', function() {
						this.strokeWidth(4);
						this.opacity(1);
						layer.draw();
			        });
			        vertex.on('mouseout', function() {
						this.strokeWidth(2);
						this.opacity(0.3);
						layer.draw();
					});
					adding_shape.add(vertex);
					var shape_area = new Konva.Text({
				        x: shape_setting.x - 30,
				        y: shape_setting.y + 10,
				        text: "",
				        fontSize: 16,
				        fill: 'grey',
				        name: 'shape_area',
				        class: 'group_item'
			      	});
			      	adding_shape.add(shape_area);
	      			break;
	      		case 'rectangle':
	      			shape_setting.x = layout_centerX - shape_setting.width / 2;
	      			shape_setting.y = layout_centerY - shape_setting.height / 2;
	      			var rectangle = new Konva.Rect(shape_setting);
	      			adding_shape.add(rectangle);
	      			var r_w = new Konva.Text({
				        x: shape_setting.x + shape_setting.width / 2,
				        y: shape_setting.y,
				        text: shape_setting.width + dimension_unit,
				        fontSize: 16,
				        fill: 'grey',
				        name: 'rect_width',
				        class: 'group_item'
			      	});
			      	r_w.on('dblclick dbltap', () => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = r_w.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = r_w.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = r_w.width();
				        textarea.focus();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetRectangleByWH(adding_shape,'width',Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	adding_shape.add(r_w);
			      	var r_h = new Konva.Text({
				        x: shape_setting.x,
				        y: shape_setting.y + shape_setting.height / 2,
				        text: shape_setting.height + dimension_unit,
				        fontSize: 16,
				        fill: 'grey',
				        name: 'rect_height',
				        class: 'group_item'
			      	});
			      	r_h.on('dblclick dbltap', () => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = r_h.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = r_h.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = r_h.width();
				        textarea.focus();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetRectangleByWH(adding_shape,'height',Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	adding_shape.add(r_h);
			      	var vertex = new Konva.Circle({
				        x: shape_setting.x + shape_setting.width,
				        y: shape_setting.y + shape_setting.height,
				        radius: 6,
				        fill: 'blue',
				        stroke: 'black',
				        strokeWidth: 2,
				        draggable: true,
				        opacity: 0.3,
				        name: 'rect_vertex',
				        class: 'group_item',
				        dragBoundFunc: function(pos) {
				        	resetRectangle(adding_shape);
							layer.draw();
			          		return {
				            	x: pos.x,
				            	y: pos.y
			          		};
				        }
			      	});
			      	vertex.on('dragstart', function() {
			      		this.hide();
			      		stage.find('Transformer').destroy();
						layer.draw();
			        });
			        vertex.on('dragend', function() {
			        	resetRectangle(adding_shape);
			        	this.show();
			        	layer.draw();
			        });
			      	vertex.on('mouseover', function() {
						this.strokeWidth(4);
						this.opacity(1);
						layer.draw();
			        });
			        vertex.on('mouseout', function() {
						this.strokeWidth(2);
						this.opacity(0.3);
						layer.draw();
					});
					adding_shape.add(vertex);
					var shape_area = new Konva.Text({
				        x: shape_setting.x + shape_setting.width / 2,
				        y: shape_setting.y + shape_setting.height / 2,
				        text: "",
				        fontSize: 16,
				        fill: 'grey',
				        name: 'shape_area',
				        class: 'group_item'
			      	});
			      	adding_shape.add(shape_area);
	      			break;
	      		case 'roundrect':
	      			shape_setting.x = layout_centerX - shape_setting.width / 2;
	      			shape_setting.y = layout_centerY - shape_setting.height / 2;
	      			var roundrect = new Konva.Rect(shape_setting);
	      			adding_shape.add(roundrect);
	      			var r_w = new Konva.Text({
				        x: shape_setting.x + shape_setting.width / 2,
				        y: shape_setting.y,
				        text: shape_setting.width + dimension_unit,
				        fontSize: 16,
				        fill: 'grey',
				        name: 'roundrect_width',
				        class: 'group_item'
			      	});
			      	r_w.on('dblclick dbltap', () => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = r_w.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = r_w.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = r_w.width();
				        textarea.focus();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetRoundRectByWH(adding_shape,'width',Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	adding_shape.add(r_w);
			      	var r_h = new Konva.Text({
				        x: shape_setting.x,
				        y: shape_setting.y + shape_setting.height / 2,
				        text: shape_setting.height + dimension_unit,
				        fontSize: 16,
				        fill: 'grey',
				        name: 'roundrect_height',
				        class: 'group_item'
			      	});
			      	r_h.on('dblclick dbltap', () => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = r_h.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = r_h.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = r_h.width();
				        textarea.focus();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetRoundRectByWH(adding_shape,'height',Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	adding_shape.add(r_h);
			      	var rect_points = [shape_setting.x, shape_setting.y, shape_setting.x+shape_setting.width, shape_setting.y, shape_setting.x+shape_setting.width, shape_setting.y+shape_setting.height, shape_setting.x, shape_setting.y+shape_setting.height];
			      	for (var i = 0; i < rect_points.length; i+=2) {
			      		var tx = rect_points[i];
			      		var ty = rect_points[i+1];
			      		if(i == 0)
						{
							tx+=20;
							ty+=20;
						}
						else if(i/2==1)
						{
							tx-=30;
							ty+=25;
						}
						else if(i/2==2)
						{
							tx-=35;
							ty-=25;
						}
						else if(i/2==3)
						{
							tx+=25;
							ty-=25;
						}
			      		var corner_radius = new Konva.Text({
					        x: tx,
					        y: ty,
					        text: shape_setting.cornerRadius + dimension_unit,
					        fontSize: 16,
					        fill: 'grey',
					        name: 'roundrect_radius',
					        class: 'group_item'
				      	});
				      	corner_radius.on('dblclick dbltap', (e) => {
				      		if(length_measuring != 0)
				      			return;
					        var textPosition = e.target.getAbsolutePosition();
							var stageBox = stage.container().getBoundingClientRect();
							var areaPosition = {
					          x: stageBox.left + textPosition.x,
					          y: stageBox.top + textPosition.y
					        };
							var textarea = document.createElement('input');
							textarea.classList.add("shape_input");
							textarea.setAttribute("type","number");
							document.body.appendChild(textarea);
							textarea.value = corner_radius.text().replace(dimension_unit,"");
					        textarea.style.position = 'fixed';
					        textarea.style.top = areaPosition.y + 'px';
					        textarea.style.left = areaPosition.x + 'px';
					        textarea.style.width = corner_radius.width();
					        textarea.focus();
					        textarea.addEventListener('keydown', function(e) {
					          if (e.keyCode === 13) {
					          	if(textarea.value == "")
					          	{
					          		alert("Enter a value.");
					          		return;
					          	}
					          	stage.find('Transformer').destroy();
					            document.body.removeChild(textarea);
					            resetRoundRectByRadius(adding_shape,Number(textarea.value));
					            layer.draw();
					          }
					        });
				      	});
				      	adding_shape.add(corner_radius);
			      		var vertex = new Konva.Circle({
					        x: rect_points[i],
					        y: rect_points[i+1],
					        radius: 6,
					        fill: 'blue',
					        stroke: 'black',
					        strokeWidth: 2,
					        draggable: true,
					        opacity: 0.3,
					        name: 'roundrect_vertex',
					        class: 'group_item',
					        index: i/2,
					        dragBoundFunc: function(pos) {
					        	resetRoundRect(adding_shape,this);
								layer.draw();
				          		return {
					            	x: pos.x,
					            	y: pos.y
				          		};
					        }
				      	});
				      	vertex.on('dragstart', function() {
				      		stage.find('Transformer').destroy();
							layer.draw();
				        });
				        vertex.on('dragend', function() {
				      		resetRoundRect(adding_shape,this);
							layer.draw();
				        });
				      	vertex.on('mouseover', function() {
							this.strokeWidth(4);
							this.opacity(1);
							layer.draw();
				        });
				        vertex.on('mouseout', function() {
							this.strokeWidth(2);
							this.opacity(0.3);
							layer.draw();
						});
						adding_shape.add(vertex);
					}
					var shape_area = new Konva.Text({
				        x: shape_setting.x + shape_setting.width / 2,
				        y: shape_setting.y + shape_setting.height / 2,
				        text: "",
				        fontSize: 16,
				        fill: 'grey',
				        name: 'shape_area',
				        class: 'group_item'
			      	});
			      	adding_shape.add(shape_area);
	      			break;
      			case 'oval':
	      			var oval = new Konva.Ellipse(shape_setting);
	      			adding_shape.add(oval);
	      			var dx_line = new Konva.Line({
				        points: [shape_setting.x,shape_setting.y,shape_setting.x + shape_setting.radiusX,shape_setting.y],
				        stroke: 'grey',
				        strokeWidth: 2,
				        lineCap: 'round',
				        lineJoin: 'round',
				        dash: [5, 10],
				        name: 'oval_xline',
				        class: 'group_item'
			      	});
					adding_shape.add(dx_line);
					var dy_line = new Konva.Line({
				        points: [shape_setting.x,shape_setting.y,shape_setting.x,shape_setting.y - shape_setting.radiusY],
				        stroke: 'grey',
				        strokeWidth: 2,
				        lineCap: 'round',
				        lineJoin: 'round',
				        dash: [5, 10],
				        name: 'oval_yline',
				        class: 'group_item'
			      	});
					adding_shape.add(dy_line);
					var dx_length = new Konva.Text({
				        x: shape_setting.x + shape_setting.radiusX / 2,
				        y: shape_setting.y,
				        text: shape_setting.radiusX + dimension_unit,
				        fontSize: 16,
				        fill: 'grey',
				        name: 'oval_xlength',
				        class: 'group_item'
			      	});
			      	dx_length.on('dblclick dbltap', () => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = dx_length.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = dx_length.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = dx_length.width();
				        textarea.focus();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetOvalByRadius(adding_shape,'x',Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	adding_shape.add(dx_length);
			      	var dy_length = new Konva.Text({
				        x: shape_setting.x,
				        y: shape_setting.y - shape_setting.radiusY / 2,
				        text: shape_setting.radiusY + dimension_unit,
				        fontSize: 16,
				        fill: 'grey',
				        name: 'oval_ylength',
				        class: 'group_item'
			      	});
			      	dy_length.on('dblclick dbltap', () => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = dy_length.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = dy_length.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = dy_length.width();
				        textarea.focus();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetOvalByRadius(adding_shape,'y',Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	adding_shape.add(dy_length);
			      	var vertex = new Konva.Circle({
				        x: shape_setting.x + shape_setting.radiusX,
				        y: shape_setting.y + shape_setting.radiusY,
				        radius: 6,
				        fill: 'blue',
				        stroke: 'black',
				        strokeWidth: 2,
				        draggable: true,
				        opacity: 0.3,
				        name: 'oval_vertex',
				        class: 'group_item',
				        dragBoundFunc: function(pos) {
				        	resetOval(adding_shape);
							layer.draw();
			          		return {
				            	x: pos.x,
				            	y: pos.y
			          		};
				        }
			      	});
			      	vertex.on('dragstart', function() {
						stage.find('Transformer').destroy();
						layer.draw();
			        });
			        vertex.on('dragend', function() {
						resetOval(adding_shape);
						layer.draw();
			        });
			      	vertex.on('mouseover', function() {
						this.strokeWidth(4);
						this.opacity(1);
						layer.draw();
			        });
			        vertex.on('mouseout', function() {
						this.strokeWidth(2);
						this.opacity(0.3);
						layer.draw();
					});
					adding_shape.add(vertex);
					var shape_area = new Konva.Text({
				        x: shape_setting.x - 30,
				        y: shape_setting.y + 10,
				        text: "",
				        fontSize: 16,
				        fill: 'grey',
				        name: 'shape_area',
				        class: 'group_item'
			      	});
			      	adding_shape.add(shape_area);
	      			break;
	      	}
		}
		if(adding_shape != null)
		{
			adding_shape.on('mouseover', function() {
				document.body.style.cursor = 'pointer';
			});
			adding_shape.on('mouseout', function() {
				document.body.style.cursor = 'default';
			});
			adding_shape.on('dragend', function() {
				saveStatus();
			});
			adding_shape.on('transformend', function() {
		        saveStatus();
	      	});
			layer.add(adding_shape);
			if(selected_shape_id == FREEDRAW_ID)
				freedrawing = true;
			if(selected_shape.shape_type != "text")
				calculatePrice(adding_shape);
		}
		layer.draw();
		saveStatus();
	})	
	jQuery("body").on("click", "#TF-statusbar button", function(){
		jQuery("input.shape_input").remove();
		var action = jQuery(this).attr("action");
		switch(action)
		{
			case 'redo':
				if(stage_index >= stage_status.length - 1)
					return;
				reloadStatus(stage_status[stage_index + 1]);
				stage_index++;
				break;
			case 'undo':
				if(stage_index < 1)
					return;
				reloadStatus(stage_status[stage_index - 1]);
				stage_index--;
				break;
			case 'export':
				var shapes = layer.getChildren(function(node){
					return node.getAttr("class") == "shape_group";
				});
				if(shapes.length == 0)
				{
					alert("There is no shape to export.");
					return;
				}
				var confirm = window.confirm("Do you want to export design as DXF?");
				if(!confirm)
					return;
				var minX = 10000;
				var minY = 10000;
				var maxX = -10000;
				var maxY = -10000;
				var upload_data = [];
				for (var i = 0; i < shapes.length; i++) {
					var shape_rect = shapes[i].getClientRect();
					var shape_data = {
						props:  shapes[i].attrs, 
						attrs:  shapes[i].getChildren()[0].attrs, 
						center: [shape_rect.x + shape_rect.width/2, shape_rect.y + shape_rect.height/2]
					};
					upload_data.push(shape_data);
					if(minX > shape_rect.x)
						minX = shape_rect.x;
					if(minY > shape_rect.y)
						minY = shape_rect.y;
					if(maxX < shape_rect.x + shape_rect.width)
						maxX = shape_rect.x + shape_rect.width;
					if(maxY < shape_rect.y + shape_rect.height)
						maxY = shape_rect.y + shape_rect.height;
				}
				var limit_width = dimension_unit == "mm" ? pane_width : pane_width / 10;
				var limit_height = dimension_unit == "mm" ? pane_height : pane_height / 10;
				if(((maxX - minX)/stage.scaleX() > limit_width)||((maxY - minY)/stage.scaleY() > limit_height))
				{
					var confirm = window.confirm("The maximum size of the foil is " + pane_width + "×" + pane_height + "mm. If you continue, you will lose overflow part.");
					if(!confirm)
						return;
				}
				jQuery.ajax({
			        url: server_url,
			        async: false,
			        data: {"request":"export", data:JSON.stringify(upload_data), dimension_unit:dimension_unit},
			        type: 'post',
			        dataType: 'json',
			        success: function(data) {
			        	if(data["result"] == "success")
			         	{
			         		var anchor = document.createElement('a');
							anchor.href = plugin_dir_url + "editor/" + data["export_url"];
							anchor.target = '_blank';
							var d = new Date,
						    dformat = [d.getFullYear(),
						               d.getMonth()+1,
						               d.getDate()].join('_')+'_'+
						              [d.getHours(),
						               d.getMinutes(),
						               d.getSeconds()].join('_');
							anchor.download = "foil-" + dformat + ".dxf";
							anchor.click();
			         	}
			         	else
			         		alert("It is failed to export.");
			        }
			    });   
				break;
			case 'clearall':
				if(layer.getChildren().length < 1)
					return;
				var confirm = window.confirm("Do you want to remove all shapes?");
				if(!confirm)
					return;
				layer.removeChildren();
				layer.draw();
				saveStatus();
				break;
			case 'clear':
				removeShape();
				break;
			case 'measurelength':
				if(jQuery("#ruler").hasClass("fa-ruler-horizontal"))
				{
					stage.find('Transformer').destroy();
					freedrawing = false;
					length_measuring = 1;
					jQuery("#TF-drawing").addClass("measuring");
					jQuery("#ruler").removeClass("fa-ruler-horizontal");
					jQuery("#ruler").addClass("fa-hand-pointer");
					var shapes = layer.getChildren();
					for (var i = 0; i < shapes.length; i++) {
						if(shapes[i].attrs["draggable"] != undefined)
							shapes[i].setAttr("draggable",false);
						var children = shapes[i].getChildren();
						for (var j = 0; j < children.length; j++) {
							if(children[j].attrs["draggable"] != undefined)
								children[j].setAttr("draggable",false);
						}
					}
					stage.scale({ x: 1, y: 1 });
			        var newPos = {
			          x: 0,
			          y: 0
			        };
			        stage.position(newPos);
			        stage.batchDraw();
					layer.draw();
					jQuery("#ruler").next().html("Draw");
				}
				else
				{
					resetRulerState();	
				}
				break;
		}
	})
	jQuery("body").on("click", "#add-basket", function(){
		alert("Your product is added into cart.");
	});
	jQuery("body").on("click", "#dimension-unit", function(){
		dimension_unit = jQuery(this).val();
		resetStageDimension();
	});
	stage.on('mousemove touchmove', function(e) {
		if(length_measuring == 2)
		{
			var x = e.type == "mousemove" ? e.evt.layerX : e.currentTarget.pointerPos.x;
			var y = e.type == "mousemove" ? e.evt.layerY : e.currentTarget.pointerPos.y;
			var measuring_line = measuring_group.getChildren()[0];
			var measuring_length = measuring_group.getChildren()[1];
			measuring_line.attrs.points[2] = x;
			measuring_line.attrs.points[3] = y;
			var startX = measuring_line.attrs.points[0];
			var startY = measuring_line.attrs.points[1];
			var endX = x;
			var endY = y;
			var length_text = parseInt(Math.hypot(endX - startX, endY - startY));
			measuring_length.setAttr('x',startX + (endX - startX) / 2);
			measuring_length.setAttr('y',startY + (endY - startY) / 2);
			measuring_length.setAttr('text',length_text + dimension_unit);
			layer.draw();
		}
	});
	stage.on('mousedown touchstart', function(e) {
		if(length_measuring == 1)
		{
			var x = e.type == "mousemove" ? e.evt.layerX : e.currentTarget.pointerPos.x;
			var y = e.type == "mousemove" ? e.evt.layerY : e.currentTarget.pointerPos.y;
			measuring_group = new Konva.Group({
		        class: 'measure'
		    })
			var measuring_line = new Konva.Line({
		        points: [x,y,x,y],
		        stroke: 'grey',
		        strokeWidth: 2,
		        lineCap: 'round',
		        lineJoin: 'round',
		        dash: [5, 10],
		        class: 'transform_disable'
	      	});
			measuring_group.add(measuring_line);
			var measuring_length = new Konva.Text({
		        x: -100,
		        y: -100,
		        text: '',
		        fontSize: 16,
		        fill: 'grey',
		        class: 'transform_disable'
	      	});
	      	measuring_group.add(measuring_length);
			layer.add(measuring_group);
			layer.draw();
			length_measuring = 2;
		}
	});
	stage.on('mouseup touchend', function(e) {
		if(length_measuring == 2)
		{
			length_measuring = 1;
			saveStatus();
		}
	});
	stage.on('click tap', function(e) {
		jQuery("input.shape_input").remove();
		if(e.target === stage) {
			stage.find('Transformer').destroy();
			if(freedrawing)
			{
				var polygon_array = layer.getChildren(function(node){
			   		return node.hasName('polygon');
				});
				var drawing_polygon = polygon_array[polygon_array.length - 1];
				if(drawing_polygon != null)
				{
					var x = e.type == "click" ? e.evt.layerX : e.currentTarget.pointerPos.x;
					var y = e.type == "click" ? e.evt.layerY : e.currentTarget.pointerPos.y;
					var p_vertexs = drawing_polygon.getChildren(function(node){
				   		return node.hasName('polygon_vertex');
					});
					var minX = x;
					var minY = y;
					var maxX = x;
					var maxY = y;
					for (var i = 0; i < p_vertexs.length; i++) {
						var v = p_vertexs[i];
						var vx = v.getAttr('x');
						var vy = v.getAttr('y');
						if(minX > vx)
							minX = vx;
						if(minY > vy)
							minY = vy;
						if(maxX < vx)
							maxX = vx;
						if(maxY < vy)
							maxY = vy;
					}
					if((maxX - minX > drawing_polygon.attrs.max_width)||(maxY - minY > drawing_polygon.attrs.max_height))
						return;
					var vertex = new Konva.Circle({
				        x: x,
				        y: y,
				        radius: 6,
				        fill: 'blue',
				        stroke: 'black',
				        strokeWidth: 2,
				        draggable: true,
				        opacity: 0.3,
				        name: 'polygon_vertex',
				        class: 'group_item',
				        dragBoundFunc: function(pos) {
				        	resetDrawingPolygon(drawing_polygon);
							layer.draw();
			          		return {
				            	x: pos.x,
				            	y: pos.y
			          		};
				        }
			      	});
			      	vertex.on('dragstart', function() {
						stage.find('Transformer').destroy();
						layer.draw();
			        });
			        vertex.on('dragend', function() {
						resetDrawingPolygon(drawing_polygon);
						layer.draw();
			        });
			        vertex.on('mouseover', function() {
						this.strokeWidth(4);
						this.opacity(1);
						layer.draw();
			        });
			        vertex.on('mouseout', function() {
						this.strokeWidth(2);
						this.opacity(0.3);
						layer.draw();
					});
					drawing_polygon.add(vertex);
					resetDrawingPolygon(drawing_polygon);
					saveStatus();
				}
			}
			layer.draw();
			return;
        }
        selected_item = null;
		stage.find('Transformer').destroy();
		var tr = new Konva.Transformer({
        	keepRatio: true, 
        	enabledAnchors: []
        });
		if(e.target.attrs.name == "polygon_vertex")
		{
			selected_item = e.target;
			e.target.getParent().add(tr);
		}
		else
		{
			selected_item = e.target.getParent();
			layer.add(tr);
			if(e.target.attrs['class'] == "group_item")
				calculatePrice(selected_item);
		}
		tr.attachTo(selected_item);
        layer.draw();
  	});
})
function saveStatus()
{
	var status = [];
	var dxf_string = "";
	var items = layer.getChildren();
	for (var i = 0; i < items.length; i++) {
		status.push(items[i].toJSON());
		if(i == items.length - 1)
			dxf_string = dxf_string + items[i].toJSON();
		else
			dxf_string = dxf_string + items[i].toJSON() + "@@";
	} 
	if(stage_status.length == 10)
		stage_status.shift();
	stage_status.push(status);
	stage_index = stage_status.length - 1;
	jQuery("#cfwc-title-field").val(dxf_string + "&&" + product_price.toFixed(2));
}
function reloadStatus(status)
{
	layer.removeChildren();
	for (var i = 0; i < status.length; i++) {
		var item = Konva.Node.create(status[i]);
		layer.add(item);
	}
	var all = layer.getChildren();
	for (var i = 0; i < all.length; i++) {
		var shape = all[i];
		if(shape.attrs.name == "polygon")
		{
			if(shape.attrs.subname == "Draw shape")
			{
				var p_vertexs = shape.getChildren(function(node){
			   		return node.hasName('polygon_vertex');
				});
				for (var j = 0; j < p_vertexs.length; j++) {
					var vertex = p_vertexs[j];
					vertex.dragBoundFunc(function(pos){
						resetDrawingPolygon(this.getParent());
						layer.draw();
		          		return {
			            	x: pos.x,
			            	y: pos.y
		          		};
					});
					vertex.on('dragstart', function() {
						stage.find('Transformer').destroy();
						layer.draw();
			        });
			        vertex.on('dragend', function() {
						resetDrawingPolygon(this.getParent());
						layer.draw();
			        });
			      	vertex.on('mouseover', function() {
						this.strokeWidth(4);
						this.opacity(1);
						layer.draw();
			        });
			        vertex.on('mouseout', function() {
						this.strokeWidth(2);
						this.opacity(0.3);
						layer.draw();
					});
				}	
			}
			else
			{
				var vertex = shape.getChildren(function(node){
			   		return node.hasName(shape.attrs.subname + '_vertex');
				});
				vertex[0].dragBoundFunc(function(pos){
					resetRegularPolygon(this.getParent());
					layer.draw();
	          		return {
		            	x: pos.x,
		            	y: pos.y
	          		};
				});
				vertex[0].on('dragstart', function() {
		      		this.hide();
					stage.find('Transformer').destroy();
					layer.draw();
		        });
		        vertex[0].on('dragend', function() {
		        	resetRegularPolygon(this.getParent());
		        	this.show();
		        	layer.draw();
				});
		      	vertex[0].on('mouseover', function() {
					this.strokeWidth(4);
					this.opacity(1);
					layer.draw();
		        });
		        vertex[0].on('mouseout', function() {
					this.strokeWidth(2);
					this.opacity(0.3);
					layer.draw();
				});
				
		        var length = shape.getChildren(function(node){
			   		return node.hasName('polygon_length');
				});
				length[0].on('dblclick dbltap', (e) => {
		      		if(length_measuring != 0)
		      			return;
			        var textPosition = e.target.getAbsolutePosition();
					var stageBox = stage.container().getBoundingClientRect();
					var areaPosition = {
			          x: stageBox.left + textPosition.x,
			          y: stageBox.top + textPosition.y
			        };
					var textarea = document.createElement('input');
					textarea.classList.add("shape_input");
					textarea.setAttribute("type","number");
					document.body.appendChild(textarea);
					textarea.value = e.target.text().replace(dimension_unit,"");
			        textarea.style.position = 'fixed';
			        textarea.style.top = areaPosition.y + 'px';
			        textarea.style.left = areaPosition.x + 'px';
			        textarea.style.width = e.target.width();
			        textarea.focus();
			        var t = e.target.getParent();
			        textarea.addEventListener('keydown', function(e) {
			          if (e.keyCode === 13) {
			          	if(textarea.value == "")
			          	{
			          		alert("Enter a value.");
			          		return;
			          	}
			          	stage.find('Transformer').destroy();
			            document.body.removeChild(textarea);
			            resetRegularPolygonByLength(t,Number(textarea.value));
			            layer.draw(); 
			          }
			        });
		      	});	
			}		
		}
		else if(shape.attrs.name == "text")
		{
			var text_field = shape.getChildren()[0];
			text_field.on('dblclick dbltap', (e) => {
	      		if(length_measuring != 0)
	      			return;
		        var textPosition = e.target.getAbsolutePosition();
				var stageBox = stage.container().getBoundingClientRect();
				var areaPosition = {
		          x: stageBox.left + textPosition.x,
		          y: stageBox.top + textPosition.y
		        };
				var textarea = document.createElement('input');
				textarea.classList.add("shape_input");
				document.body.appendChild(textarea);
				textarea.style.position = 'fixed';
		        textarea.style.top = areaPosition.y + 'px';
		        textarea.style.left = areaPosition.x + 'px';
		        textarea.style.width = e.target.width();
		        textarea.focus();
		        var t = e.target;
		        textarea.addEventListener('keydown', function(e) {
		          if (e.keyCode === 13) {
		          	if(textarea.value == "")
		          	{
		          		alert("Enter a value.");
		          		return;
		          	}
		          	stage.find('Transformer').destroy();
		            document.body.removeChild(textarea);
		            t.text(textarea.value);
		            saveStatus();
		            layer.draw();
		          }
		        });
	      	});
		}
		else
		{
			switch(shape.attrs.name)
	      	{
	      		case 'circle':
	      			var diameter_length = shape.getChildren(function(node){
				   		return node.hasName('circle_length');
					});
	      			diameter_length[0].on('dblclick dbltap', (e) => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = e.target.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = e.target.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = e.target.width();
				        textarea.focus();
				        var t = e.target.getParent();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetCircleByDiameter(t,Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	var vertex = shape.getChildren(function(node){
				   		return node.hasName('circle_vertex');
					});
					vertex[0].dragBoundFunc(function(pos){
						resetCircle(this.getParent());
						layer.draw();
		          		return {
			            	x: pos.x,
			            	y: pos.y
		          		};
					});
			      	vertex[0].on('dragstart', function() {
						stage.find('Transformer').destroy();
						layer.draw();
			        });
			        vertex[0].on('dragend', function() {
						resetCircle(this.getParent());
						layer.draw();
			        });
			      	vertex[0].on('mouseover', function() {
						this.strokeWidth(4);
						this.opacity(1);
						layer.draw();
			        });
			        vertex[0].on('mouseout', function() {
						this.strokeWidth(2);
						this.opacity(0.3);
						layer.draw();
					});
	      			break;
	      		case 'rectangle':
	      			var r_w = shape.getChildren(function(node){
				   		return node.hasName('rect_width');
					});
	      			r_w[0].on('dblclick dbltap', (e) => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = e.target.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = e.target.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = e.target.width();
				        textarea.focus();
				        var t = e.target.getParent();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetRectangleByWH(t,'width',Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	
	      			var r_h = shape.getChildren(function(node){
				   		return node.hasName('rect_height');
					});
			      	r_h[0].on('dblclick dbltap', (e) => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = e.target.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = e.target.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = e.target.width();
				        textarea.focus();
				        var t = e.target.getParent();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetRectangleByWH(t,'height',Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	
			      	var vertex = shape.getChildren(function(node){
				   		return node.hasName('rect_vertex');
					});
					vertex[0].dragBoundFunc(function(pos){
						resetRectangle(this.getParent());
						layer.draw();
		          		return {
			            	x: pos.x,
			            	y: pos.y
		          		};
					});
			      	vertex[0].on('dragstart', function() {
			      		this.hide();
			      		stage.find('Transformer').destroy();
						layer.draw();
			        });
			        vertex[0].on('dragend', function() {
			        	resetRectangle(this.getParent());
			        	this.show();
			        	layer.draw();
			        });
			      	vertex[0].on('mouseover', function() {
						this.strokeWidth(4);
						this.opacity(1);
						layer.draw();
			        });
			        vertex[0].on('mouseout', function() {
						this.strokeWidth(2);
						this.opacity(0.3);
						layer.draw();
					});
	      			break;
	      		case 'roundrect':
	      			var r_w = shape.getChildren(function(node){
				   		return node.hasName('roundrect_width');
					});
	      			r_w[0].on('dblclick dbltap', (e) => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = e.target.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = e.target.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = e.target.width();
				        textarea.focus();
				        var t = e.target.getParent();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetRoundRectByWH(t,'width',Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	var r_h = shape.getChildren(function(node){
				   		return node.hasName('roundrect_height');
					});
			      	r_h[0].on('dblclick dbltap', (e) => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = e.target.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = e.target.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = e.target.width();
				        textarea.focus();
				        var t = e.target.getParent();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetRoundRectByWH(t,'height',Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	var corner_radius = shape.getChildren(function(node){
				   		return node.hasName('roundrect_radius');
					});
			      	for (var j = 0; j < corner_radius.length; j++) {
			      		var cr = corner_radius[j];
			      		cr.on('dblclick dbltap', (e) => {
				      		if(length_measuring != 0)
				      			return;
					        var textPosition = e.target.getAbsolutePosition();
							var stageBox = stage.container().getBoundingClientRect();
							var areaPosition = {
					          x: stageBox.left + textPosition.x,
					          y: stageBox.top + textPosition.y
					        };
							var textarea = document.createElement('input');
							textarea.classList.add("shape_input");
							textarea.setAttribute("type","number");
							document.body.appendChild(textarea);
							textarea.value = e.target.text().replace(dimension_unit,"");
					        textarea.style.position = 'fixed';
					        textarea.style.top = areaPosition.y + 'px';
					        textarea.style.left = areaPosition.x + 'px';
					        textarea.style.width = e.target.width();
					        textarea.focus();
					        var t = e.target.getParent();
					        textarea.addEventListener('keydown', function(e) {
					          if (e.keyCode === 13) {
					          	if(textarea.value == "")
					          	{
					          		alert("Enter a value.");
					          		return;
					          	}
					          	stage.find('Transformer').destroy();
					            document.body.removeChild(textarea);
					            resetRoundRectByRadius(t,Number(textarea.value));
					            layer.draw();
					          }
					        });
				      	});
			      	}
			      	var r_vertex = shape.getChildren(function(node){
				   		return node.hasName('roundrect_vertex');
					});
			      	for (var j = 0; j < r_vertex.length; j++) {
			      		var vertex = r_vertex[j];
			      		vertex.dragBoundFunc(function(pos){
							resetRoundRect(this.getParent(),this);
							layer.draw();
			          		return {
				            	x: pos.x,
				            	y: pos.y
			          		};
						});
						vertex.on('dragstart', function() {
				      		stage.find('Transformer').destroy();
							layer.draw();
				        });
				        vertex.on('dragend', function() {
				      		resetRoundRect(this.getParent(),this);
							layer.draw();
				        });
				      	vertex.on('mouseover', function() {
							this.strokeWidth(4);
							this.opacity(1);
							layer.draw();
				        });
				        vertex.on('mouseout', function() {
							this.strokeWidth(2);
							this.opacity(0.3);
							layer.draw();
						});
			      	}
			      	break;
      			case 'oval':
	      			var dx_length = shape.getChildren(function(node){
				   		return node.hasName('oval_xlength');
					});
	      			dx_length[0].on('dblclick dbltap', (e) => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = e.target.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = e.target.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = e.target.width();
				        textarea.focus();
				        var t = e.target.getParent();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetOvalByRadius(t,'x',Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	var dy_length = shape.getChildren(function(node){
				   		return node.hasName('oval_ylength');
					});
			      	dy_length[0].on('dblclick dbltap', (e) => {
			      		if(length_measuring != 0)
			      			return;
				        var textPosition = e.target.getAbsolutePosition();
						var stageBox = stage.container().getBoundingClientRect();
						var areaPosition = {
				          x: stageBox.left + textPosition.x,
				          y: stageBox.top + textPosition.y
				        };
						var textarea = document.createElement('input');
						textarea.classList.add("shape_input");
						textarea.setAttribute("type","number");
						document.body.appendChild(textarea);
						textarea.value = e.target.text().replace(dimension_unit,"");
				        textarea.style.position = 'fixed';
				        textarea.style.top = areaPosition.y + 'px';
				        textarea.style.left = areaPosition.x + 'px';
				        textarea.style.width = e.target.width();
				        textarea.focus();
				        var t = e.target.getParent();
				        textarea.addEventListener('keydown', function(e) {
				          if (e.keyCode === 13) {
				          	if(textarea.value == "")
				          	{
				          		alert("Enter a value.");
				          		return;
				          	}
				          	stage.find('Transformer').destroy();
				            document.body.removeChild(textarea);
				            resetOvalByRadius(t,'y',Number(textarea.value));
				            layer.draw();
				          }
				        });
			      	});
			      	var vertex = shape.getChildren(function(node){
				   		return node.hasName('oval_vertex');
					});
					vertex[0].dragBoundFunc(function(pos){
						resetOval(this.getParent());
						layer.draw();
		          		return {
			            	x: pos.x,
			            	y: pos.y
		          		};
					});
			      	vertex[0].on('dragstart', function() {
						stage.find('Transformer').destroy();
						layer.draw();
			        });
			        vertex[0].on('dragend', function() {
						resetOval(this.getParent());
						layer.draw();
			        });
			      	vertex[0].on('mouseover', function() {
						this.strokeWidth(4);
						this.opacity(1);
						layer.draw();
			        });
			        vertex[0].on('mouseout', function() {
						this.strokeWidth(2);
						this.opacity(0.3);
						layer.draw();
					});
	      			break;
	      	}
		}
		shape.on('mouseover', function() {
			document.body.style.cursor = 'pointer';
		});
		shape.on('mouseout', function() {
			document.body.style.cursor = 'default';
		});
		shape.on('dragend', function() {
			saveStatus();
		});
		shape.on('transformend', function() {
	        saveStatus();
      	});
	}
	resetStageDimension();
}
function removeShape()
{
	if(stage.find('Transformer').length == 0)
		return;
	if(selected_item != null)
	{
		var parent = selected_item.getParent();
		selected_item.destroy();
		stage.find('Transformer').destroy();
		if(selected_item.attrs.name == "polygon_vertex")
		{
			if(parent.getChildren().length == 4)
				parent.destroy();
			else
				resetDrawingPolygon(parent);	
		}
		layer.draw();
		saveStatus();
	}
}
function resetStageDimension()
{
	var all = layer.getChildren();
	for (var i = 0; i < all.length; i++) {
		var shape = all[i];
		if(shape.getAttr("class") == "measure")
		{
			var measuring_length = shape.getChildren()[1];
			var text = measuring_length.getAttr("text");
			measuring_length.setAttr("text", parseFloat(text) + dimension_unit);
		}
		else
		{
			if(shape.getAttr("name") == "polygon")
			{
				switch(shape.getAttr("subname"))
				{
					case 'Draw shape':
						resetDrawingPolygon(shape);
						break;
					default:
						resetRegularPolygon(shape);
						break;
				}
			}
			else
			{
				switch(shape.getAttr("name"))
				{
					case 'rectangle':
						resetRectangle(shape);
						break;
					case 'roundrect':
						var r_vertex = shape.getChildren(function(node){
					   		return node.hasName('roundrect_vertex');
						});
						resetRoundRect(shape, r_vertex[0]);
						break;
					case 'circle':
						resetCircle(shape);
						break;
					case 'oval':
						resetOval(shape);
						break;
				}
			}
		}
	}
	layer.draw();
}
function calculatePrice(shape)
{
	jQuery("#TF-other .base-price .value").html(shape.attrs.base_price);
	var area = 0;	
	var edge_count = 0;
	switch(shape.attrs.name)
	{
		case 'polygon':
			var g_polygon = shape.getChildren(function(node){
		   		return node.hasName('polygon_lines');
			});
			area = calcPolygonArea(g_polygon[0].attrs.points);
			edge_count = g_polygon[0].attrs.points.length / 2;
			break;
		case 'rectangle':
			var r_rect = shape.getChildren();
			area = Math.abs(r_rect[0].attrs.width * r_rect[0].attrs.height);
			edge_count = 4;
			break;
		case 'roundrect':
			var b_rect = shape.getChildren();
			area = b_rect[0].attrs.width * b_rect[0].attrs.height - (4 - 3.141592) * (b_rect[0].attrs.cornerRadius * b_rect[0].attrs.cornerRadius);
			edge_count = 4;
			break;
		case 'circle':
			var c_circle = shape.getChildren();
			area = 3.141592 * Math.pow(c_circle[0].attrs.radius, 2);
			break;
		case 'oval':
			var oval = shape.getChildren();
			area = 3.141592 * oval[0].attrs.radiusX * oval[0].attrs.radiusY;
			break;
	}
	var shape_area = shape.getChildren(function(node){
   		return node.hasName('shape_area');
	});
	var displayed_area = "";
	if(dimension_unit == "mm")
	{
		displayed_area = (area / 10 / 10).toFixed(2) + "c㎡";
		area = area / 1000 / 1000;
	}
	else if(dimension_unit == "cm")
	{
		displayed_area = (area / 100 / 100).toFixed(2) + "㎡";
		area = area / 100 / 100;
	}
	shape_area[0].setAttr("text",displayed_area);
	
	jQuery("#TF-other .area .value").html(area.toFixed(2));
	var price = 0;
	if(price_calculation == "normal")
		price = (Number(shape.attrs.sqm_price) * Number(area)).toFixed(2);
	else if(price_calculation == "baseprice")
		price = (Number(shape.attrs.base_price) + shape.attrs.sqm_price * Number(area)).toFixed(2);
	else if(price_calculation == "edge")
	{
		price = (Number(shape.attrs.edge_price) * edge_count + shape.attrs.sqm_price * Number(area)).toFixed(2);
	}
	jQuery("#TF-other .shape-price .value").html(price);	
	shape.attrs["price"] = Number(price);
	var shapes = layer.getChildren(function(node){
		return node.getAttr("class") == "shape_group";
	});
	product_price = 0;
	for (var i = 0; i < shapes.length; i++) {
		product_price += shapes[i].attrs.price;
	}
	jQuery("#TF-other .total .value").html(product_price.toFixed(2));	
}
function resetDrawingPolygon(polygon)
{
	var p_lines = polygon.getChildren(function(node){
   		return node.hasName('polygon_lines');
	});
	var p_vertexs = polygon.getChildren(function(node){
   		return node.hasName('polygon_vertex');
	});
	var newpoints = [];
	var minX = 10000;
	var minY = 10000;
	var maxX = -10000;
	var maxY = -10000;
	for (var i = 0; i < p_vertexs.length; i++) {
		var v = p_vertexs[i];
		var x = v.getAttr('x');
		var y = v.getAttr('y');
		newpoints.push(x);
		newpoints.push(y);
		if(minX > x)
			minX = x;
		if(minY > y)
			minY = y;
		if(maxX < x)
			maxX = x;
		if(maxY < y)
			maxY = y;
	}
	var limit_width = dimension_unit == "mm" ? polygon.attrs.max_width : polygon.attrs.max_width / 10;
	var limit_height = dimension_unit == "mm" ? polygon.attrs.max_height : polygon.attrs.max_height / 10;
	if((maxX - minX > limit_width)||(maxY - minY > limit_height))	//Shape Limitation
	{
		var oldpoints = p_lines[0].attrs.points;
		for (var i = 0; i < oldpoints.length / 2; i++) 
		{
			p_vertexs[i].setAttr("x",oldpoints[i*2]);
			p_vertexs[i].setAttr("y",oldpoints[i*2+1]);
		}
		return false;
	}
	p_lines.setAttr('points',newpoints);
	var p_lengths = polygon.getChildren(function(node){
   		return node.hasName('polygon_length');
	});
	for (var i = 0; i < p_lengths.length; i++) {
		p_lengths[i].remove();
	}
	var p_angles = polygon.getChildren(function(node){
   		return node.hasName('polygon_angle');
	});
	for (var i = 0; i < p_angles.length; i++) {
		p_angles[i].remove();
	}
	for (var i = 0; i < newpoints.length; i+=2) {
  		var start = {x:0, y:0};
      	var end = {x:0, y:0};
      	if(i == newpoints.length - 2)
      	{
      		start.x = newpoints[newpoints.length - 2];
      		start.y = newpoints[newpoints.length - 1];
      		end.x = newpoints[0];
      		end.y = newpoints[1];
      	}
      	else
      	{
      		start.x = newpoints[i];
      		start.y = newpoints[i + 1];
      		end.x = newpoints[i+2];
      		end.y = newpoints[i+3];
      	}
      	var length_text = Math.hypot(end.x - start.x, end.y - start.y);
  		var length = new Konva.Text({
	        x: start.x + (end.x - start.x) / 2,
	        y: start.y + (end.y - start.y) / 2,
	        text: length_text.toFixed(1) + dimension_unit,
	        fontSize: 16,
	        fill: 'grey',
	        index: i/2,
	        name: 'polygon_length',
	        class: 'group_item'
      	});
      	length.on('dblclick dbltap', (e) => {
      		if(length_measuring != 0)
      			return;
	        var textPosition = e.target.getAbsolutePosition();
			var stageBox = stage.container().getBoundingClientRect();
			var areaPosition = {
	          x: stageBox.left + textPosition.x,
	          y: stageBox.top + textPosition.y
	        };
			var textarea = document.createElement('input');
			textarea.classList.add("shape_input");
			textarea.setAttribute("type","number");
			document.body.appendChild(textarea);
			textarea.value = e.target.text().replace(dimension_unit,"");
	        textarea.style.position = 'fixed';
	        textarea.style.top = areaPosition.y + 'px';
	        textarea.style.left = areaPosition.x + 'px';
	        textarea.style.width = e.target.width();
	        textarea.focus();
	        var selected_length = e.target;
	        textarea.addEventListener('keydown', function(e) {
	          if (e.keyCode === 13) {
	          	if(textarea.value == "")
	          	{
	          		alert("Enter a value.");
	          		return;
	          	}
	          	stage.find('Transformer').destroy();
	            document.body.removeChild(textarea);
	            resetDrawingPolygonByLength(polygon,selected_length,Number(textarea.value));
	            layer.draw(); 
	          }
	        });
      	});
      	polygon.add(length);
      	
      	if(newpoints.length >= 6)
      	{	
      		if(i == 0)
      			var angle_text = find_angle({x:newpoints[newpoints.length-2], y:newpoints[newpoints.length-1]}, {x:newpoints[0], y:newpoints[1]}, {x:newpoints[2], y:newpoints[3]});
      		else if(i == newpoints.length - 2)
      			var angle_text = find_angle({x:newpoints[i-2], y:newpoints[i-1]}, {x:newpoints[i], y:newpoints[i+1]}, {x:newpoints[0], y:newpoints[1]});
      		else
      			var angle_text = find_angle({x:newpoints[i-2], y:newpoints[i-1]}, {x:newpoints[i], y:newpoints[i+1]}, {x:newpoints[i+2], y:newpoints[i+3]});
      		var angle = new Konva.Text({
		        x: newpoints[i] + 10,
		        y: newpoints[i+1] + 10,
		        text: angle_text + ' °',
		        fontSize: 16,
		        fill: 'black',
		        name: 'polygon_angle',
		        index: i/2,
		        class: 'group_item'
	      	});
	      	angle.on('dblclick dbltap', (e) => {
	      		if(length_measuring != 0)
	      			return;
		        var textPosition = e.target.getAbsolutePosition();
				var stageBox = stage.container().getBoundingClientRect();
				var areaPosition = {
		          x: stageBox.left + textPosition.x,
		          y: stageBox.top + textPosition.y
		        };
				var textarea = document.createElement('input');
				textarea.classList.add("shape_input");
				textarea.setAttribute("type","number");
				document.body.appendChild(textarea);
				textarea.value = Number(e.target.text().split(" ")[0]);
		        textarea.style.position = 'fixed';
		        textarea.style.top = areaPosition.y + 'px';
		        textarea.style.left = areaPosition.x + 'px';
		        textarea.style.width = e.target.width();
		        textarea.focus();
		        var selected_angle = e.target;
		        textarea.addEventListener('keydown', function(e) {
		          if (e.keyCode === 13) {
		          	if(textarea.value == "")
		          	{
		          		alert("Enter a value.");
		          		return;
		          	}
		          	stage.find('Transformer').destroy();
		            document.body.removeChild(textarea);
		            resetDrawingPolygonByAngle(polygon,selected_angle, - Number(textarea.value) + Number(selected_angle.text().split(" ")[0]));
		            layer.draw(); 
		          }
		        });
	      	});
	      	polygon.add(angle); 	
      	}
  	}
  	p_vertexs.moveToTop();
  	var shape_area = polygon.getChildren(function(node){
   		return node.hasName('shape_area');
	});
	shape_area[0].setAttr("x", minX + (maxX - minX) / 2);
	shape_area[0].setAttr("y", minY + (maxY - minY) / 2);
	calculatePrice(polygon);
	return true;
}
function resetDrawingPolygonByAngle(polygon, selected_angle, angle_value)
{
	var current_index = selected_angle.getAttr("index");
	var p_lines = polygon.getChildren(function(node){
   		return node.hasName('polygon_lines');
	});
	var points = p_lines[0].attrs.points;
	var startX = points[current_index*2];
	var startY = points[current_index*2+1];
	var next_index = current_index + 1;
	if(current_index == points.length / 2 - 1)
		next_index = 0;
	var endX = points[next_index*2];
	var endY = points[next_index*2+1];

	var x = startX + (endX-startX)*Math.cos(angle_value * Math.PI / 180) - (endY-startY)*Math.sin(angle_value * Math.PI / 180);
	var y = startY + (endX-startX)*Math.sin(angle_value * Math.PI / 180) + (endY-startY)*Math.cos(angle_value * Math.PI / 180);

	var p_vertexs = polygon.getChildren(function(node){
   		return node.hasName('polygon_vertex');
	});
	p_vertexs[next_index].setAttr("x",x);
	p_vertexs[next_index].setAttr("y",y);
	if(resetDrawingPolygon(polygon))
		saveStatus();
}
function resetDrawingPolygonByLength(polygon, selected_length, value)
{
	var current_index = selected_length.getAttr("index");
	var p_lines = polygon.getChildren(function(node){
   		return node.hasName('polygon_lines');
	});
	var points = p_lines[0].attrs.points;
	var startX = points[current_index*2];
	var startY = points[current_index*2+1];
	var next_index = current_index + 1;
	if(current_index == points.length / 2 - 1)
		next_index = 0;
	var endX = points[next_index*2];
	var endY = points[next_index*2+1];
	var l = Math.hypot(endX - startX, endY - startY);
	var x = value * (endX - startX) / l + startX;
	var y = value * (endY - startY) / l + startY;
	var p_vertexs = polygon.getChildren(function(node){
   		return node.hasName('polygon_vertex');
	});
	p_vertexs[next_index].setAttr("x",x);
	p_vertexs[next_index].setAttr("y",y);
	if(resetDrawingPolygon(polygon))
		saveStatus();
}
function resetRegularPolygon(polygon)
{
	var polygon_lines = polygon.getChildren(function(node){
   		return node.hasName("polygon_lines");
	});
	var vertex = polygon.getChildren(function(node){
   		return node.hasName(polygon.getAttr("subname") + "_vertex");
	});
	var length = polygon.getChildren(function(node){
   		return node.hasName("polygon_length");
	});
	var angle = polygon.getChildren(function(node){
   		return node.hasName("polygon_angle");
	});
	var centerX = polygon.getAttr("centerX");
	var centerY = polygon.getAttr("centerY");
	var radius = Math.hypot(centerX - vertex[0].getAttr("x"), centerY - vertex[0].getAttr("y"));
	var limit_width = dimension_unit == "mm" ? polygon.attrs.max_width : polygon.attrs.max_width / 10;
	if(radius * 2 > limit_width)	//Shape Limitation
	{
		vertex[0].setAttr("x",polygon_lines[0].attrs.points[0]);
		vertex[0].setAttr("y",polygon_lines[0].attrs.points[1]);
		return;
	}
	var n = polygon.getAttr("n");
	var newPoints = [];
  	var angle_value = (n - 2) * 180 / n;
  	for (var i = 0; i < n; i++) {
		if(polygon.attrs.subname == "Triangle")
  		{
  			newPoints.push(centerX + radius * Math.cos(2 * Math.PI * i / n - Math.PI / 2));
			newPoints.push(centerY + radius * Math.sin(2 * Math.PI * i / n - Math.PI / 2));
  		}
  		else if(polygon.attrs.subname == "Pentagon")
  		{
  			newPoints.push(centerX + radius * Math.cos(2 * Math.PI * i / n - Math.PI / 3));
			newPoints.push(centerY + radius * Math.sin(2 * Math.PI * i / n - Math.PI / 3));
  		}
  		else if(polygon.attrs.subname == "Hexagon")
  		{
  			newPoints.push(centerX + radius * Math.cos(2 * Math.PI * i / n - Math.PI * (angle_value - 90) / 2 / 180));
			newPoints.push(centerY + radius * Math.sin(2 * Math.PI * i / n - Math.PI * (angle_value - 90) / 2 / 180));
		}
	}
	polygon_lines.setAttr("points",newPoints);

	var start = {x:newPoints[0], y:newPoints[1]};
  	var second = {x:newPoints[2], y:newPoints[3]};
  	vertex[0].setAttr("x",start.x);
	vertex[0].setAttr("y",start.y);

	var length_text = Math.hypot(second.x - start.x, second.y - start.y);
	length.setAttr("text", length_text.toFixed(1) + dimension_unit);
	length.setAttr("x", start.x + (second.x - start.x) / 2 + 10);
	length.setAttr("y", start.y + (second.y - start.y) / 2);
	
	var angle_x = start.x;
  	var angle_y = start.y;
  	if(polygon.attrs.subname == "Triangle")
  	{
  		angle_x = start.x - 10;
  		angle_y = start.y + 20;
  	}
  	else if(polygon.attrs.subname == "Pentagon")
  	{
  		angle_x = start.x - 25;
  		angle_y = start.y + 20;	
  	}
  	else if(polygon.attrs.subname == "Hexagon")
  	{
  		angle_x = start.x - 40;
  		angle_y = start.y + 5;		
  	}
  	angle.setAttr("x", angle_x);
	angle.setAttr("y", angle_y);
	calculatePrice(polygon);
}
function resetRegularPolygonByLength(polygon, value)
{
	var n = polygon.getAttr("n");
	var newPoints = [];
  	var angle_value = (n - 2) * 180 / n;
  	var radius = value / 2 / Math.cos(angle_value / 2 * Math.PI / 180);
  	var limit_width = dimension_unit == "mm" ? polygon.attrs.max_width : polygon.attrs.max_width / 10;
  	if(radius * 2 > limit_width)	//Shape Limitation
		return;
	for (var i = 0; i < n; i++) {
		if(polygon.attrs.subname == "Triangle")
  		{
  			newPoints.push(polygon.getAttr("centerX") + radius * Math.cos(2 * Math.PI * i / n - Math.PI / 2));
			newPoints.push(polygon.getAttr("centerY") + radius * Math.sin(2 * Math.PI * i / n - Math.PI / 2));
  		}
  		else if(polygon.attrs.subname == "Pentagon")
  		{
  			newPoints.push(polygon.getAttr("centerX") + radius * Math.cos(2 * Math.PI * i / n - Math.PI / 3));
			newPoints.push(polygon.getAttr("centerY") + radius * Math.sin(2 * Math.PI * i / n - Math.PI / 3));
  		}
  		else if(polygon.attrs.subname == "Hexagon")
  		{
  			newPoints.push(polygon.getAttr("centerX") + radius * Math.cos(2 * Math.PI * i / n - Math.PI * (angle_value - 90) / 2 / 180));
			newPoints.push(polygon.getAttr("centerY") + radius * Math.sin(2 * Math.PI * i / n - Math.PI * (angle_value - 90) / 2 / 180));
		}
	}
	var polygon_lines = polygon.getChildren(function(node){
   		return node.hasName("polygon_lines");
	});
	polygon_lines.setAttr("points",newPoints);
	var vertex = polygon.getChildren(function(node){
   		return node.hasName(polygon.getAttr("subname") + "_vertex");
	});
	vertex.setAttr("x", newPoints[0]);
	vertex.setAttr("y", newPoints[1]);
	var length = polygon.getChildren(function(node){
   		return node.hasName("polygon_length");
	});
	length.setAttr("x", newPoints[0] + (newPoints[2] - newPoints[0]) / 2 + 10);
	length.setAttr("y", newPoints[1] + (newPoints[3] - newPoints[1]) / 2);
	length.setAttr("text", value + dimension_unit);
	var angle = polygon.getChildren(function(node){
   		return node.hasName("polygon_angle");
	});
	var angle_x = newPoints[0];
  	var angle_y = newPoints[1];
  	if(polygon.attrs.subname == "Triangle")
  	{
  		angle_x = newPoints[0] - 10;
  		angle_y = newPoints[1] + 20;
  	}
  	else if(polygon.attrs.subname == "Pentagon")
  	{
  		angle_x = newPoints[0] - 25;
  		angle_y = newPoints[1] + 20;	
  	}
  	else if(polygon.attrs.subname == "Hexagon")
  	{
  		angle_x = newPoints[0] - 40;
  		angle_y = newPoints[1] + 5;		
  	}
  	angle.setAttr("x", angle_x);
	angle.setAttr("y", angle_y);
	saveStatus();
	calculatePrice(polygon);
}
function resetCircle(circle)
{
	var c_vertex = circle.getChildren(function(node){
   		return node.hasName('circle_vertex');
	});
	var c_line = circle.getChildren(function(node){
   		return node.hasName('circle_line');
	});
	var c_circle = circle.getChildren();
	var diameter = parseInt(Math.hypot(c_vertex[0].getAttr("x") - c_circle[0].getAttr("x"), c_vertex[0].getAttr("y") - c_circle[0].getAttr("y")));
	var limit_width = dimension_unit == "mm" ? circle.attrs.max_width : circle.attrs.max_width / 10;
	if(diameter * 2 > limit_width)	//Shape Limitation
	{
		c_vertex[0].setAttr("x",c_line[0].attrs.points[2]);
		c_vertex[0].setAttr("y",c_line[0].attrs.points[3]);
		return;
	}
	var c_length = circle.getChildren(function(node){
   		return node.hasName('circle_length');
	});
	c_line[0].attrs.points[2] = c_vertex[0].getAttr("x");
	c_line[0].attrs.points[3] = c_vertex[0].getAttr("y");
	c_length[0].setAttr("x", c_line[0].attrs.points[0] + (c_line[0].attrs.points[2] - c_line[0].attrs.points[0]) / 2);
	c_length[0].setAttr("y", c_line[0].attrs.points[1] + (c_line[0].attrs.points[3] - c_line[0].attrs.points[1]) / 2);
	c_length[0].setAttr("text", diameter + dimension_unit);
	c_circle[0].setAttr("radius",diameter);
	calculatePrice(circle);
}
function resetCircleByDiameter(circle,diameter)
{
	var limit_width = dimension_unit == "mm" ? circle.attrs.max_width : circle.attrs.max_width / 10;
	if(diameter * 2 > limit_width)	//Shape Limitation
		return;
	var c_circle = circle.getChildren();
	c_circle[0].setAttr("radius",diameter);
	var x = c_circle[0].getAttr("x");
	var y = c_circle[0].getAttr("y");
	var c_vertex = circle.getChildren(function(node){
   		return node.hasName('circle_vertex');
	});
	c_vertex[0].setAttr("x", x + diameter);
	c_vertex[0].setAttr("y", y);
	var c_line = circle.getChildren(function(node){
   		return node.hasName('circle_line');
	});
	c_line[0].attrs.points[2] = x + diameter;
	c_line[0].attrs.points[3] = y;
	var c_length = circle.getChildren(function(node){
   		return node.hasName('circle_length');
	});
	c_length[0].setAttr("x", x + diameter / 2);
	c_length[0].setAttr("y", y);
	c_length[0].setAttr("text", diameter + dimension_unit);
	saveStatus();
	calculatePrice(circle);
}
function resetOval(oval)
{
	var vertex = oval.getChildren(function(node){
   		return node.hasName('oval_vertex');
	});
	var xline = oval.getChildren(function(node){
   		return node.hasName('oval_xline');
	});
	var yline = oval.getChildren(function(node){
   		return node.hasName('oval_yline');
	});
	var xlength = oval.getChildren(function(node){
   		return node.hasName('oval_xlength');
	});
	var ylength = oval.getChildren(function(node){
   		return node.hasName('oval_ylength');
	});
	var c_oval = oval.getChildren();
	var dx = Math.abs(vertex[0].getAttr("x") - c_oval[0].getAttr("x"));
	var dy = Math.abs(vertex[0].getAttr("y") - c_oval[0].getAttr("y"));
	var limit_width = dimension_unit == "mm" ? oval.attrs.max_width : oval.attrs.max_width / 10;
	var limit_height = dimension_unit == "mm" ? oval.attrs.max_height : oval.attrs.max_height / 10;
	if((dx * 2 > limit_width)||(dy * 2 > limit_height))		//Shape Limitation
	{
		vertex[0].setAttr("x",c_oval[0].getAttr("x") + c_oval[0].getAttr("radiusX"));
		vertex[0].setAttr("y",c_oval[0].getAttr("y") + c_oval[0].getAttr("radiusY"));
		return;
	}
	xline[0].attrs.points[2] = vertex[0].getAttr("x");
	yline[0].attrs.points[3] = yline[0].attrs.points[1] - (vertex[0].getAttr("y") - yline[0].attrs.points[1]);
	xlength[0].setAttr("x", xline[0].attrs.points[0] + (xline[0].attrs.points[2] - xline[0].attrs.points[0]) / 2);
	xlength[0].setAttr("text", dx + dimension_unit);
	ylength[0].setAttr("y", yline[0].attrs.points[1] + (yline[0].attrs.points[3] - yline[0].attrs.points[1]) / 2);
	ylength[0].setAttr("text", dy + dimension_unit);

	c_oval[0].setAttr("radiusX",dx);
	c_oval[0].setAttr("radiusY",dy);
	/*
	var gap = c_oval[0].getAttr("gap");

	var grid_line = oval.getChildren(function(node){
   		return node.hasName('oval_gridline');
	});
	grid_line.remove();
	for (var i = 1; i < dx / gap; i++) {
		var offsetY = Math.sqrt(Math.pow(dy,2) - Math.pow(dy*(dx - gap*i)/dx,2));
		var grid_line = new Konva.Line({
	        points: [xline[0].attrs.points[0] - dx + gap * i, xline[0].attrs.points[1] + offsetY, xline[0].attrs.points[0] - dx + gap * i, xline[0].attrs.points[1] - offsetY],
	        stroke: 'grey',
	        strokeWidth: 1,
	        lineCap: 'round',
	        lineJoin: 'round',
	        dash: [5, 10],
	        name: 'oval_gridline',
	        class: 'group_item'
      	});
		oval.add(grid_line);
	}
	var gap_text = oval.getChildren(function(node){
   		return node.hasName('oval_gridlinegap');
	});
	gap_text[0].setAttr("x", xline[0].attrs.points[0] - dx + gap/2);
	gap_text[0].setAttr("y", xline[0].attrs.points[1]);
  	oval.add(gap_text);
  	*/
	calculatePrice(oval);
}
function resetOvalByRadius(oval,xy,value)
{
	var c_oval = oval.getChildren();
	var x = c_oval[0].getAttr("x");
	var y = c_oval[0].getAttr("y");
	//var gap = c_oval[0].getAttr("gap");
	var vertex = oval.getChildren(function(node){
   		return node.hasName('oval_vertex');
	});
	var xline = oval.getChildren(function(node){
   		return node.hasName('oval_xline');
	});
	var yline = oval.getChildren(function(node){
   		return node.hasName('oval_yline');
	});
	var xlength = oval.getChildren(function(node){
   		return node.hasName('oval_xlength');
	});
	var ylength = oval.getChildren(function(node){
   		return node.hasName('oval_ylength');
	});
	if(xy == "x")
	{
		var limit_width = dimension_unit == "mm" ? oval.attrs.max_width : oval.attrs.max_width / 10;
		if(value * 2 > limit_width)
			return;
		c_oval[0].setAttr("radiusX",value);
		vertex[0].setAttr("x", x + value);
		xline[0].attrs.points[2] = x + value;
		xlength[0].setAttr("x", x + value / 2);
		xlength[0].setAttr("text", value + dimension_unit);
		/*
		var grid_line = oval.getChildren(function(node){
	   		return node.hasName('oval_gridline');
		});
		grid_line.remove();
		var dy = c_oval[0].getAttr("radiusY");
		for (var i = 1; i < value / gap; i++) {
			var offsetY = Math.sqrt(Math.pow(dy,2) - Math.pow(dy*(value - gap*i)/value,2));
			var grid_line = new Konva.Line({
		        points: [x - value + gap * i, y + offsetY, x - value + gap * i, y - offsetY],
		        stroke: 'grey',
		        strokeWidth: 1,
		        lineCap: 'round',
		        lineJoin: 'round',
		        dash: [5, 10],
		        name: 'oval_gridline',
		        class: 'group_item'
	      	});
			oval.add(grid_line);
		}
		var gap_text = oval.getChildren(function(node){
	   		return node.hasName('oval_gridlinegap');
		});
		gap_text[0].setAttr("x", x - value + gap/2);
		gap_text[0].setAttr("y", y);
	  	oval.add(gap_text);
	  	*/
	}
	else
	{
		var limit_height = dimension_unit == "mm" ? oval.attrs.max_height : oval.attrs.max_height / 10;
		if(value * 2 > limit_height)	//Shape Limitation
			return;
		c_oval[0].setAttr("radiusY",value);
		vertex[0].setAttr("y", y + value);
		yline[0].attrs.points[3] = y - value;
		ylength[0].setAttr("y", y - value / 2);
		ylength[0].setAttr("text", value + dimension_unit);
		/*
		var grid_line = oval.getChildren(function(node){
	   		return node.hasName('oval_gridline');
		});
		grid_line.remove();
		var dx = c_oval[0].getAttr("radiusX");
		for (var i = 1; i < dx / gap; i++) {
			var offsetY = Math.sqrt(Math.pow(value,2) - Math.pow(value*(dx - gap*i)/dx,2));
			var grid_line = new Konva.Line({
		        points: [x - dx + gap * i, y + offsetY, x - dx + gap * i, y - offsetY],
		        stroke: 'grey',
		        strokeWidth: 1,
		        lineCap: 'round',
		        lineJoin: 'round',
		        dash: [5, 10],
		        name: 'oval_gridline',
		        class: 'group_item'
	      	});
			oval.add(grid_line);
		}
		var gap_text = oval.getChildren(function(node){
	   		return node.hasName('oval_gridlinegap');
		});
		gap_text[0].setAttr("x", x - dx + gap/2);
		gap_text[0].setAttr("y", y);
	  	oval.add(gap_text);
	  	*/
	}
	saveStatus();
	calculatePrice(oval);
}
function resetOvalByGap(oval,value)
{
	var c_oval = oval.getChildren();
	c_oval[0].setAttr("gap",value);
	var x = c_oval[0].getAttr("x");
	var y = c_oval[0].getAttr("y");
	var radiusX = c_oval[0].getAttr("radiusX");
	var radiusY = c_oval[0].getAttr("radiusY");
	var grid_line = oval.getChildren(function(node){
   		return node.hasName('oval_gridline');
	});
	grid_line.remove();
	for (var i = 1; i < radiusX / value; i++) {
		var offsetY = Math.sqrt(Math.pow(radiusY,2) - Math.pow(radiusY*(radiusX - value*i)/radiusX,2));
		var grid_line = new Konva.Line({
	        points: [x - radiusX + value * i, y + offsetY, x - radiusX + value * i, y - offsetY],
	        stroke: 'grey',
	        strokeWidth: 1,
	        lineCap: 'round',
	        lineJoin: 'round',
	        dash: [5, 10],
	        name: 'oval_gridline',
	        class: 'group_item'
      	});
		oval.add(grid_line);
	}
	var gap = oval.getChildren(function(node){
   		return node.hasName('oval_gridlinegap');
	});
	gap[0].setAttr("x", x - radiusX + value/2);
	gap[0].setAttr("text", value + dimension_unit);
  	calculatePrice(oval);
}
function resetRectangle(rectangle)
{
	var r_rect = rectangle.getChildren()[0];
	var r_vertex = rectangle.getChildren(function(node){
   		return node.hasName('rect_vertex');
	});
	var x = r_rect.getAttr("x");
	var y = r_rect.getAttr("y");
	var width = r_vertex[0].getAttr("x") - x;
	var height = r_vertex[0].getAttr("y") - y;
	if((Math.abs(width) < 1) || (Math.abs(height) < 1))
		return;
	if(active_key == 16)	//Drawing with SHIFT key
	{
		var ri = r_rect.getAttr("width") / r_rect.getAttr("height");
		var rs = width / height;
		if(Math.abs(rs) > Math.abs(ri))
			width = r_rect.getAttr("width") * height / r_rect.getAttr("height");
		else
			height = r_rect.getAttr("height") * width / r_rect.getAttr("width");
	}
	var limit_width = dimension_unit == "mm" ? rectangle.attrs.max_width : rectangle.attrs.max_width / 10;
	var limit_height = dimension_unit == "mm" ? rectangle.attrs.max_height : rectangle.attrs.max_height / 10;
	if((Math.abs(width) > limit_width)||(Math.abs(height) > limit_height))	//Shape Limitation
	{
		r_vertex[0].setAttr("x", x + r_rect.getAttr("width"));
		r_vertex[0].setAttr("y", y + r_rect.getAttr("height"));
		return;
	}
	r_rect.setAttr("width",width);
	r_rect.setAttr("height",height);
	r_vertex[0].setAttr("x", x + width);
	r_vertex[0].setAttr("y", y + height);
	var r_width = rectangle.getChildren(function(node){
   		return node.hasName('rect_width');
	});
	r_width[0].setAttr("text",Math.abs(parseInt(width)) + dimension_unit);
	r_width[0].setAttr("x",x + width/2);
	r_width[0].setAttr("y",y);
	var r_height = rectangle.getChildren(function(node){
   		return node.hasName('rect_height');
	});
	r_height[0].setAttr("text",Math.abs(parseInt(height)) + dimension_unit);
	r_height[0].setAttr("x",x);
	r_height[0].setAttr("y",y + height/2);
	var shape_area = rectangle.getChildren(function(node){
   		return node.hasName('shape_area');
	});
	shape_area[0].setAttr("x", x + width / 2);
	shape_area[0].setAttr("y", y + height / 2);
	calculatePrice(rectangle);
}
function resetRectangleByWH(rectangle,wh,value)
{
	var r_rect = rectangle.getChildren();
	var r_vertex = rectangle.getChildren(function(node){
   		return node.hasName('rect_vertex');
	});
	if(wh == 'width')
	{
		var limit_width = dimension_unit == "mm" ? rectangle.attrs.max_width : rectangle.attrs.max_width / 10;
		if(value > limit_width)	//Shape Limitation
			return;
		if(r_rect[0].getAttr("x") > r_vertex[0].getAttr("x"))
			value = -value;
		r_rect[0].setAttr("width",value);	
		var r_width = rectangle.getChildren(function(node){
	   		return node.hasName('rect_width');
		});
		r_width[0].setAttr("text",Math.abs(value)+dimension_unit);
		r_width[0].setAttr("x",r_rect[0].getAttr("x") + value/2);
		r_vertex[0].setAttr("x",r_rect[0].getAttr("x") + value);
	}
	else
	{
		var limit_height = dimension_unit == "mm" ? rectangle.attrs.max_height : rectangle.attrs.max_height / 10;
		if(value > limit_height)	//Shape Limitation
			return;
		if(r_rect[0].getAttr("y") > r_vertex[0].getAttr("y"))
			value = -value;
		r_rect[0].setAttr("height",value);
		var r_height = rectangle.getChildren(function(node){
	   		return node.hasName('rect_height');
		});
		r_height[0].setAttr("text",Math.abs(value)+dimension_unit);
		r_height[0].setAttr("y",r_rect[0].getAttr("y") + value/2);
		r_vertex[0].setAttr("y",r_rect[0].getAttr("y") + value);
	}
	var shape_area = rectangle.getChildren(function(node){
   		return node.hasName('shape_area');
	});
	shape_area[0].setAttr("x", r_rect[0].getAttr("x") + r_rect[0].getAttr("width") / 2);
	shape_area[0].setAttr("y", r_rect[0].getAttr("y") + r_rect[0].getAttr("height") / 2);
	saveStatus();
	calculatePrice(rectangle);
}
function resetRoundRect(roundrect, current_vertex)
{
	var current_index = current_vertex.getAttr("index");
	var opposite_index = current_index < 2 ? current_index + 2 : current_index - 2;
	var r_vertex = roundrect.getChildren(function(node){
   		return node.hasName('roundrect_vertex');
	});
	var x = Math.min(r_vertex[current_index].getAttr("x"), r_vertex[opposite_index].getAttr("x"));
	var y = Math.min(r_vertex[current_index].getAttr("y"), r_vertex[opposite_index].getAttr("y"));
	var width = Math.abs(r_vertex[current_index].getAttr("x") - r_vertex[opposite_index].getAttr("x"));
	var height = Math.abs(r_vertex[current_index].getAttr("y") - r_vertex[opposite_index].getAttr("y"));
	var r_rect = roundrect.getChildren();
	var limit_width = dimension_unit == "mm" ? roundrect.attrs.max_width : roundrect.attrs.max_width / 10;
	var limit_height = dimension_unit == "mm" ? roundrect.attrs.max_height : roundrect.attrs.max_height / 10;
	if((width > limit_width)||(height > limit_height))	//Shape Limitation
	{
		var x = r_rect[0].getAttr("x");
		var y = r_rect[0].getAttr("y");
		var width = r_rect[0].getAttr("width");
		var height = r_rect[0].getAttr("height");
		var rect_points = [x, y, x+width, y, x+width, y+height, x, y+height];
		for (var i = 0; i < rect_points.length / 2; i++) 
		{
			r_vertex[i].setAttr("x",rect_points[i*2]);
			r_vertex[i].setAttr("y",rect_points[i*2+1]);
		}
		return;
	}
	var rect_points = [x, y, x+width, y, x+width, y+height, x, y+height];
	r_rect[0].setAttr("x",x);
	r_rect[0].setAttr("y",y);
	r_rect[0].setAttr("width",width);
	r_rect[0].setAttr("height",height);
	var r_width = roundrect.getChildren(function(node){
   		return node.hasName('roundrect_width');
	});
	r_width[0].setAttr("text",parseInt(width)+dimension_unit);
	r_width[0].setAttr("x",x + width/2);
	r_width[0].setAttr("y",y);
	var r_height = roundrect.getChildren(function(node){
   		return node.hasName('roundrect_height');
	});
	r_height[0].setAttr("text",parseInt(height)+dimension_unit);
	r_height[0].setAttr("x",x);
	r_height[0].setAttr("y",y + height/2);
	var corner_radius = roundrect.getChildren(function(node){
   		return node.hasName('roundrect_radius');
	});
	for (var i = 0; i < rect_points.length / 2; i++) 
	{
		r_vertex[i].setAttr("x",rect_points[i*2]);
		r_vertex[i].setAttr("y",rect_points[i*2+1]);
		var tx = rect_points[i*2];
		var ty = rect_points[i*2+1];
		if(i == 0)
		{
			tx+=20;
			ty+=20;
		}
		else if(i==1)
		{
			tx-=30;
			ty+=25;
		}
		else if(i==2)
		{
			tx-=35;
			ty-=25;
		}
		else if(i==3)
		{
			tx+=25;
			ty-=25;
		}
		corner_radius[i].setAttr("x",tx);
		corner_radius[i].setAttr("y",ty);
		var ttt = parseFloat(corner_radius[i].getAttr("text"));
		corner_radius[i].setAttr("text",ttt + dimension_unit);
	}
	var shape_area = roundrect.getChildren(function(node){
   		return node.hasName('shape_area');
	});
	shape_area[0].setAttr("x", x + width / 2);
	shape_area[0].setAttr("y", y + height / 2);
	calculatePrice(roundrect);
}
function resetRoundRectByWH(roundrect,wh,value)
{
	var r_rect = roundrect.getChildren();
	var r_vertex = roundrect.getChildren(function(node){
   		return node.hasName('roundrect_vertex');
	});
	var corner_radius = roundrect.getChildren(function(node){
   		return node.hasName('roundrect_radius');
	});
	if(wh == 'width')
	{
		var limit_width = dimension_unit == "mm" ? roundrect.attrs.max_width : roundrect.attrs.max_width / 10;
		if(value > limit_width)	//Shape Limitation
			return;
		r_rect[0].setAttr("width",value);	
		var r_width = roundrect.getChildren(function(node){
	   		return node.hasName('roundrect_width');
		});
		r_width[0].setAttr("text",value+dimension_unit);
		r_width[0].setAttr("x",r_rect[0].getAttr("x") + value/2);
		r_vertex[1].setAttr("x",r_rect[0].getAttr("x") + value);
		r_vertex[2].setAttr("x",r_rect[0].getAttr("x") + value);
		corner_radius[1].setAttr("x",r_rect[0].getAttr("x") + value - 30);
		corner_radius[2].setAttr("x",r_rect[0].getAttr("x") + value - 35);
	}
	else
	{
		var limit_height = dimension_unit == "mm" ? roundrect.attrs.max_height : roundrect.attrs.max_height / 10;
		if(value > limit_height)	//Shape Limitation
			return;
		r_rect[0].setAttr("height",value);
		var r_height = roundrect.getChildren(function(node){
	   		return node.hasName('roundrect_height');
		});
		r_height[0].setAttr("text",value+dimension_unit);
		r_height[0].setAttr("y",r_rect[0].getAttr("y") + value/2);
		r_vertex[2].setAttr("y",r_rect[0].getAttr("y") + value);
		r_vertex[3].setAttr("y",r_rect[0].getAttr("y") + value);
		corner_radius[2].setAttr("y",r_rect[0].getAttr("y") + value - 25);
		corner_radius[3].setAttr("y",r_rect[0].getAttr("y") + value - 25);
	}
	var shape_area = roundrect.getChildren(function(node){
   		return node.hasName('shape_area');
	});
	shape_area[0].setAttr("x", r_rect[0].getAttr("x") + r_rect[0].getAttr("width") / 2);
	shape_area[0].setAttr("y", r_rect[0].getAttr("y") + r_rect[0].getAttr("height") / 2);
	saveStatus();
	calculatePrice(roundrect);
}
function resetRoundRectByRadius(roundrect,value)
{
	var r_rect = roundrect.getChildren();
	var corner_radius = roundrect.getChildren(function(node){
   		return node.hasName('roundrect_radius');
	});
	r_rect[0].setAttr("cornerRadius",value);	
	for (var i = 0; i < corner_radius.length; i++) {
		corner_radius[i].setAttr("text",value + dimension_unit);
	}
	saveStatus();
	calculatePrice(roundrect);
}
function setShapeList()
{
	jQuery("#pattern-list").html("");
	jQuery.ajax({
        url: server_url,
        async: false,
        data: {"request":"getshapedata"},
        type: 'post',
        dataType: 'json',
        success: function(result) {
        	pane_width = Number(result["pane_width"]);
        	pane_height = Number(result["pane_height"]);
         	if(available_shapes == "all")
         		shape_list = result["shape"];
         	else
         	{
         		available_shapes = available_shapes.split("#");
         		for (var i = 0; i < result["shape"].length; i++) {
         			if(available_shapes.indexOf(result["shape"][i].name) != -1)
         				shape_list.push(result["shape"][i]);
         		}
         	}
        }
    });   
    for (var i = 0; i < shape_list.length; i++) {
    	var shape = shape_list[i];
    	var shape_group = jQuery('<div class="vltTDT-patternBar-patternGroup" shape_id="' + shape.id + '">');
    	var shape_name = jQuery('<h3 title="'+shape.name+'">'+shape.name+'</h3>');
    	var shape_body = jQuery('<div class="vltTDT-patternBar-pattern"></div>');
    	var shape_preview = jQuery('<div class="shape"></div>');
    	shape_preview.css("background-image","url("+ shape_preview_url + shape.preview+")")
    	shape_body.append(shape_preview);
    	shape_group.append(shape_name);
    	shape_group.append(shape_body);
    	jQuery("#pattern-list").append(shape_group);
    }
}
function resetRulerState()
{
	length_measuring = 0;
	jQuery("#TF-drawing").removeClass("measuring");
	jQuery("#ruler").addClass("fa-ruler-horizontal");
	jQuery("#ruler").removeClass("fa-hand-pointer");
	var shapes = layer.getChildren();
	for (var i = 0; i < shapes.length; i++) {
		if(shapes[i].attrs["draggable"] != undefined)
			shapes[i].setAttr("draggable",true);
		var children = shapes[i].getChildren();
		for (var j = 0; j < children.length; j++) {
			if(children[j].attrs["draggable"] != undefined)
				children[j].setAttr("draggable",true);
		}
	}
	jQuery("#ruler").next().html("Measure");
}
function find_angle(A,B,C) {
    var AB = Math.sqrt(Math.pow(B.x-A.x,2)+ Math.pow(B.y-A.y,2));    
    var BC = Math.sqrt(Math.pow(B.x-C.x,2)+ Math.pow(B.y-C.y,2)); 
    var AC = Math.sqrt(Math.pow(C.x-A.x,2)+ Math.pow(C.y-A.y,2));
    return Math.round(Math.acos((BC*BC+AB*AB-AC*AC) / (2*BC*AB)) * (180 / Math.PI));   
}
function calcPolygonArea(vertices) {
    var total = 0;

    for (var i = 0, l = vertices.length; i < l; i+=2) {
      var addX = vertices[i];
      var addY = vertices[i == vertices.length - 2 ? 0 : i + 3];
      var subX = vertices[i == vertices.length - 2 ? 0 : i + 2];
      var subY = vertices[i+1];

      total += (addX * addY * 0.5);
      total -= (subX * subY * 0.5);
    }
    return Math.abs(total);
}
function log(e)
{
	console.log(e);
}