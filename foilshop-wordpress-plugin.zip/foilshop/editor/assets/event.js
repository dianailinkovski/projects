function eventInitialize() {
  $(".vltTDT-patternBar-patternGroup").click(function(event) {
		var key = $(this).attr("shape_id");
		customDrawing = key == "draw";
    drawModel(key);
  });

  jQuery("body").on("click", "#TF-statusbar button", function(){
		jQuery("input.shape_input").remove();
		var action = jQuery(this).attr("action");
		switch(action)
		{
			case 'redo':
				if(historyIndex >= foilHistorys.length - 1)
					return;
				historyIndex++;
				if (historyIndex > foilHistorys.length - 1) {
					historyIndex = foilHistorys.length - 1;
					$(".shape-action button[action='redo']").attr("disabled", true);
				}
				$(".shape-action button[action='undo']").attr("disabled", historyIndex < 1);
				foilModels = JSON.parse(JSON.stringify(foilHistorys[historyIndex]));
				MakerJsPlayground.renderWithModels(foilModels);
				break;
			case 'undo':
				if (historyIndex < 1)
					return;
				historyIndex--;
				if (historyIndex < 0) {
					historyIndex = 0;
					$(".shape-action button[action='undo']").attr("disabled", true);
				}
				$(".shape-action button[action='redo']").attr("disabled", historyIndex >= foilHistorys.length - 1);
				
				foilModels = JSON.parse(JSON.stringify(foilHistorys[historyIndex]));
				MakerJsPlayground.renderWithModels(foilModels);
				break;
			case 'export':
				var tmodels = JSON.parse(JSON.stringify(foilModels));
				delete tmodels.paths;
				var aModels = {};
				Object.keys(tmodels.models).forEach(key => {
					if (key != 'background') {
						var model = tmodels.models[key];
						model.layer = "VCUT";
						aModels[key] = model;
					}
				});
				tmodels.models = aModels;
				var dxfString = makerjs.exporter.toDXF(tmodels, {units: foilModels.units});
				var encoded = encodeURIComponent(dxfString);
        var uriPrefix = 'data:application/dxf,';
        var filename = 'my-drawing.dxf';
        var dataUri = uriPrefix + encoded;
        var aTag = document.createElement("a");
        jQuery(aTag).attr("href", dataUri).attr("download", filename);
        jQuery("body").append(aTag);
				aTag.click();
				jQuery(aTag).remove();				
				break;
			case 'clearall':
				foilModels.models = {};
				foilModels.paths = {};
        MakerJsPlayground.pointers.selected = false;
        MakerJsPlayground.pointers.selectedModel = null;
        MakerJsPlayground.renderWithModels(foilModels);
				$("#TF-background .selector").remove();
				foilHistorys = [];
				historyIndex = 0;
				jQuery(".shape-action button[action='undo']").attr("disabled", true);
				jQuery(".shape-action button[action='redo']").attr("disabled", true);
				jQuery("#TF-other .base-price .value").html('0');
				jQuery("#TF-other .shape-price .value").html('0');
				jQuery('#TF-other .area .value').html('0');
				jQuery('#TF-other .total .value').html('0');
				break;
			case 'clear':
				var newModels = {};
				var selected = "";
				Object.keys(foilModels.models).forEach(key => {
					if (!foilModels.models[key].selected) {
						newModels[key] = foilModels.models[key];
					} else {
						selected = key;
					}
				});
				foilModels.models = newModels;
				foilModels.paths = {};
				MakerJsPlayground.pointers.selected = false;
        MakerJsPlayground.pointers.selectedModel = null;
				MakerJsPlayground.renderWithModels(foilModels);
				if (selected.length > 0)
					$("#TF-background .selector." + selected + "_").remove();
				addHistory();
				jQuery("#TF-other .base-price .value").html('0');
				jQuery("#TF-other .shape-price .value").html('0');
				jQuery('#TF-other .area .value').html('0');
				// jQuery("")
				break;
			case 'measurelength':
				measureStatus = !measureStatus;
				if (measureStatus) {
					jQuery("#ruler").removeClass("fa-ruler-horizontal");
					jQuery("#ruler").addClass("fa-hand-pointer");
					measurePoints = [];
					MakerJsPlayground.pointers.selected = false;
					MakerJsPlayground.pointers.selectedModel = null;
					Object.keys(foilModels.models).forEach(key => {
						foilModels.models[key].selected = false;
						foilModels.models[key].layer = "black";
					});
					foilModels.paths = {};
					MakerJsPlayground.renderWithModels(foilModels);
				} else {
					jQuery("#ruler").removeClass("fa-hand-pointer");
					jQuery("#ruler").addClass("fa-ruler-horizontal");
					foilModels.paths = {};
					MakerJsPlayground.renderWithModels(foilModels);
					jQuery(".measure-number").remove();
				}				
				break;
			case 'area':
				calculateArea();
				break;
			case 'zoomin':
				zooming(true);
				break;
			case 'zoomout':
				zooming(false);
				break;
			case 'zoom':
				MakerJsPlayground.fitOnScreen();
				MakerJsPlayground.render();
				break;
		}
	});

	jQuery("#dimension-unit").change(function() {
		units = makerjs.unitType[jQuery(this).val()];
		MakerJsPlayground.renderWithModels(foilModels);
	});

	jQuery("body").on("click", "#add-basket", function(){
		// alert("Your product is added into cart.");
		$('form.cart button[name="add-to-cart"]').click();
	});
}

function addEditEvent() {
	jQuery("#TF-drawing .dimension-number").dblclick(function() {
		var rIndex = jQuery(this).attr("rindex");
		var val = jQuery(this).html();
		val = val.split(" ");
		var model = null;
		Object.keys(foilModels.models).forEach(key => {
			if (foilModels.models[key].selected) model = foilModels.models[key];
		});
		if (model) {
			dimensionEditor.dialog("open");
			dimensionEditor.find("#radius").val(val[0]);
			dimensionEditor.find(".units").html(units);
			dimensionEditor.rIndex = rIndex;
			dimensionEditor.angleFlag = false;
		}
	});

	jQuery("#TF-drawing .dimension-angle").dblclick(function() {
		var rIndex = jQuery(this).attr("rindex");
		var val = jQuery(this).html();
		val = val.split(" ");
		var model = null;
		Object.keys(foilModels.models).forEach(key => {
			if (foilModels.models[key].selected) model = foilModels.models[key];
		});
		if (model) {
			dimensionEditor.dialog("open");
			dimensionEditor.find("#radius").val(val[0]);
			dimensionEditor.find(".units").html('&#176;');
			dimensionEditor.rIndex = rIndex;
			dimensionEditor.angleFlag = true;
		}
	});
}

function calculateArea(area, key) {	
	var price = 0;
	var shape = shape_list.find(item => (item.id == key));
	if (shape) {
		if(price_calculation == "normal")
			price = (Number(shape.sqm_price) * Number(area.value)).toFixed(2);
		else if(price_calculation == "baseprice")
			price = (Number(shape.base_price) + shape.sqm_price * Number(area.value)).toFixed(2);
		else if(price_calculation == "edge")
		{
			price = (Number(shape.base_price) + Number(shape.edge_price) * area.edge + shape.sqm_price * Number(area.value)).toFixed(2);
		}
	}
	
	jQuery("#TF-other .base-price .value").html(shape.base_price);
	jQuery("#TF-other .shape-price .value").html(price);
	jQuery('#TF-other .area .value').html(area.value);

	MakerJsPlayground.calculateAreaTotal()
	.then(function(totalPrice) {
		jQuery('#TF-other .total .value').html(totalPrice.toFixed(2));
	});
}

function zooming (flag) {
	var panZoom = MakerJsPlayground.pointers.getZoom();
	console.log('origin', panZoom);
	if (flag) {
		panZoom.zoom = 1.1 * panZoom.zoom;
	} else {
		panZoom.zoom = 0.9 * panZoom.zoom;
	}
	MakerJsPlayground.pointers.setZoom(panZoom);
}

