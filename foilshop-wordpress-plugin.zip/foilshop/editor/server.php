<?php
	require_once('../../../../wp-load.php');
	global $thepostid, $post, $wpdb;
	$export_url = "export/foil.dxf";
 	//$pixel_mm = 3.779527559;
	$pixel_mm = 1;
	if(isset($_REQUEST["request"]))
	{
		$request = $_REQUEST["request"];
		if($request == "getshapedata")
		{
			$query = "select * from fd_shape where active=1 order by id";
			$result = $wpdb->get_results($query);
			$shape = array();
			foreach ( $result as $row )  
			{
				array_push($shape, $row);
			}
			$data = array("shape"=>$shape);
			$query = "select * from fd_setting";
			$result = $wpdb->get_results($query);
			foreach ( $result as $row )  
			{
				$data[$row->name] = $row->value;
			}

			echo json_encode($data);
		}
		if($request == "export")
		{
			include "dxf.php";
			$dimension_unit = $_REQUEST["dimension_unit"];
			if($dimension_unit == "cm")
				$pixel_mm = $pixel_mm * 10;
			$data = json_decode(str_replace('\"', '"', $_REQUEST["data"]));
			for ($i=0,$length = count($data); $i < $length; $i++) { 
				$shape = $data[$i];
				$offsetX = isset($shape->props->x) ? $pixel_mm * $shape->props->x : 0;
				$offsetY = isset($shape->props->y) ? $pixel_mm * $shape->props->y : 0;
				$dxf->setOffset($offsetX, $offsetY, 0);
				//$center = $shape->center;
				$center = [0, 0];
				$angle = isset($shape->props->rotation) ? deg2rad($shape->props->rotation) : deg2rad(0);

				if($shape->props->name == "polygon")
				{
					$points = $shape->attrs->points;
					for ($j=0; $j < count($points); $j++) { 
						$points[$j] = $pixel_mm * $points[$j];
					}
					array_push($points, $points[0], $points[1]);
					$dxf->addPolyline2d($points, $center, $angle);
				}
				else if($shape->props->name == "roundrect")
				{
					roundedCorner($pixel_mm * ($shape->attrs->x + $shape->attrs->cornerRadius), $pixel_mm * ($shape->attrs->y + $shape->attrs->height - $shape->attrs->cornerRadius), $pixel_mm * $shape->attrs->width, $pixel_mm * $shape->attrs->height, $pixel_mm * $shape->attrs->cornerRadius, $dxf, $center, $angle);
				}
				else if($shape->props->name == "rectangle")
				{
					drawRect($pixel_mm * $shape->attrs->x, $pixel_mm * $shape->attrs->y, $pixel_mm * $shape->attrs->width, $pixel_mm * $shape->attrs->height, $dxf, $center, $angle);
				}
				else if($shape->props->name == "circle")
				{
					$dxf->addCircle($pixel_mm * $shape->attrs->x, $pixel_mm * $shape->attrs->y, 0, $pixel_mm * $shape->attrs->radius, $center, $angle);
				}
				else if($shape->props->name == "oval")
				{
					$ratio = $shape->attrs->radiusY/$shape->attrs->radiusX;
					$dxf->addEllipse($pixel_mm * $shape->attrs->x, $pixel_mm * $shape->attrs->y, 0, $pixel_mm * $shape->attrs->radiusX, 0, 0, $ratio, 0.01, 2*M_PI, $center, $angle);
				}
			}
			if(file_put_contents($export_url, $dxf->getString()) == FALSE)
				echo json_encode(array("result"=>"failed"));
			else
				echo json_encode(array("result"=>"success","export_url"=>$export_url));
		} else if ($request == "get_dxf_data") {
			$item_id = $_REQUEST["item_id"];
			$custom= wc_get_order_item_meta( $item_id, 'DXF-Data', true );
			$dxf_data = explode('&&', $custom);
			echo json_encode(array("result" => "success", "dxf_data"=>$dxf_data[0]));
		}
	}
?>