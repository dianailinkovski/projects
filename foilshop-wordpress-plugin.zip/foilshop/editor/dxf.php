<?php
include "lib/Color.php";
include "lib/Creator.php";
include "lib/LineType.php";

use \adamasantares\dxf\Creator;
use \adamasantares\dxf\Color;
use \adamasantares\dxf\LineType;

$dxf = new Creator(Creator::MILLIMETERS);
$dxf->setLayer('VCUT', Color::rgb(0, 128, 0));

function roundedCorner($x, $y, $width, $length, $radius, $dxf, $center, $angle)
{
    //$dxf = new Creator(Creator::MILLIMETERS);
    $dxf->setLayer('VCUT', Color::rgb(0, 128, 0))
        ->addArc($x, $y, 0, $radius, 90, 180, $center, $angle)//ol
        ->addLine($x,$y + $radius,0, $x + $width-2*$radius,$y + $radius,0, $center, $angle)
        ->addArc($x + $width - 2*$radius, $y, 0, $radius, 0, 90, $center, $angle)//or
        ->addLine($x+$width-$radius, $y, 0, $x+$width-$radius, $y-($length - 2*$radius), 0, $center, $angle)
        ->addArc($x+$width - 2*$radius, $y-($length - 2*$radius), 0, $radius, 270, 0, $center, $angle)//ur
//
        ->addLine($x+$width - 2*$radius, $y-$length+$radius, 0, $x, $y-$length+$radius, 0, $center, $angle)
        ->addArc($x, $y-($length - 2*$radius), 0, $radius, 180, 270, $center, $angle)//ul
        ->addLine($x-$radius, $y, 0, $x-$radius, $y-($length - 2*$radius), 0, $center, $angle);
;
    return $dxf->getString();
}

function drawRect($x, $y, $width, $length, $dxf, $center, $angle)
{
    //$dxf = new Creator(Creator::MILLIMETERS);
    $dxf->setLayer('VCUT', Color::rgb(0, 128, 0))
        ->addPolyline2d([
            $x,
            $y,
            $x + $width,
            $y,
            $x+$width,
            $y,
            $x+$width,
            $y+$length,
            $x+$width,
            $y+$length,
            $x,
            $y+$length,
            $x,
            $y+$length,
            $x,
            $y
        ], $center, $angle);
    return $dxf->getString();
}
/*
function hexagon($length, $dxf){
    $halfLength = $length/2;
    $quarterLength = $length/4;

    $height = sqrt(3)*$halfLength;
    $halfHeight = $height/2;

    //$dxf = new Creator(Creator::MILLIMETERS);
    $dxf->setLayer('VCUT', Color::rgb(0, 128, 0))
        ->addLine($quarterLength,0,0, $quarterLength+$halfLength,0,0)
        ->addLine($quarterLength,-$height,0, $quarterLength+$halfLength,-$height,0)
        ->addLine(0, -$halfHeight,0,$quarterLength, 0,0)
        ->addLine(0, -$halfHeight,0,$quarterLength, -$height,0)

        ->addLine($quarterLength+$halfLength,0,0, $length,-$halfHeight,0)
        ->addLine($quarterLength+$halfLength,-$height,0, $length,-$halfHeight,0)
    ;
    return $dxf->getString();
}

function oval($length, $radius, $dxf){
    //$dxf = new Creator(Creator::MILLIMETERS);
    $dxf->setLayer('VCUT', Color::rgb(0, 128, 0))
        ->addLine($radius,$radius/2,0, $length-$radius, $radius/2,0)
        ->addLine($radius,-$radius-$radius/2,0, $length-$radius, -$radius-$radius/2,0)

        ->addArc($radius,-$radius/2,0,$radius,90,270)
        ->addArc($length-$radius,-$radius/2,0,$radius,270,90)
    ;
    return $dxf->getString();
}
*/
?>
